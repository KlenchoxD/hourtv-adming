import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

// SVG matching the official HourTV emblem and typography
const svgLogo = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="1200" height="800">
  <defs>
    <linearGradient id="redGlow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FF2A35" />
      <stop offset="50%" stop-color="#E50914" />
      <stop offset="100%" stop-color="#990000" />
    </linearGradient>
    <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FF3B30" />
      <stop offset="60%" stop-color="#E50914" />
      <stop offset="100%" stop-color="#B20710" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="6" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Circular Glowing Red Arc / Ring -->
  <circle cx="300" cy="200" r="160" fill="none" stroke="url(#ringGrad)" stroke-width="12" stroke-dasharray="820 180" stroke-linecap="round" transform="rotate(-40 300 200)" filter="url(#glow)" opacity="0.95" />
  <circle cx="300" cy="200" r="160" fill="none" stroke="#FF4D4D" stroke-width="3" stroke-dasharray="820 180" stroke-linecap="round" transform="rotate(-40 300 200)" opacity="0.8" />

  <!-- Main Wordmark: "Hour" with Embedded Play Triangle -->
  <g transform="skewX(-14)">
    <!-- H -->
    <!-- Left vertical bar of H -->
    <path d="M 185 130 L 215 130 L 215 240 L 185 240 Z" fill="#FFFFFF" />
    <!-- Right vertical bar of H -->
    <path d="M 238 130 L 268 130 L 268 240 L 238 240 Z" fill="#FFFFFF" />
    <!-- Top & Bottom connection bridges of H -->
    <rect x="215" y="130" width="23" height="22" fill="#FFFFFF" />
    <rect x="215" y="218" width="23" height="22" fill="#FFFFFF" />
    
    <!-- Red Play Triangle inside H crossbar -->
    <polygon points="216,162 216,208 244,185" fill="url(#redGlow)" />

    <!-- o -->
    <path d="M 305 160 C 285 160 272 176 272 201 C 272 226 285 242 305 242 C 325 242 338 226 338 201 C 338 176 325 160 305 160 Z M 305 182 C 314 182 318 190 318 201 C 318 212 314 220 305 220 C 296 220 292 212 292 201 C 292 190 296 182 305 182 Z" fill="#FFFFFF" />

    <!-- u -->
    <path d="M 348 162 L 372 162 L 372 214 C 372 220 376 224 382 224 C 388 224 392 220 392 214 L 392 162 L 416 162 L 416 216 C 416 233 403 242 385 242 C 367 242 348 233 348 216 Z" fill="#FFFFFF" />

    <!-- r -->
    <path d="M 426 162 L 449 162 L 449 178 C 454 167 465 161 476 161 L 476 185 C 463 185 450 190 450 205 L 450 240 L 426 240 Z" fill="#FFFFFF" />
  </g>

  <!-- Bottom Accent: Horizontal Bar + TV + Horizontal Bar -->
  <g transform="translate(0, 15)">
    <!-- Left Accent Line -->
    <rect x="200" y="276" width="60" height="5" rx="2.5" fill="url(#redGlow)" />
    
    <!-- TV in bold italic red -->
    <g transform="skewX(-14)">
      <!-- T -->
      <path d="M 285 264 L 322 264 L 322 274 L 309 274 L 309 296 L 297 296 L 297 274 L 285 274 Z" fill="url(#redGlow)" />
      <!-- V -->
      <path d="M 328 264 L 341 264 L 350 287 L 360 264 L 373 264 L 357 296 L 343 296 Z" fill="url(#redGlow)" />
    </g>

    <!-- Right Accent Line -->
    <rect x="360" y="276" width="60" height="5" rx="2.5" fill="url(#redGlow)" />
  </g>
</svg>
`;

async function generate() {
  const buffer = Buffer.from(svgLogo);
  
  // Ensure directories
  if (!fs.existsSync('public')) fs.mkdirSync('public', { recursive: true });
  if (!fs.existsSync('src/assets')) fs.mkdirSync('src/assets', { recursive: true });
  if (!fs.existsSync('assets')) fs.mkdirSync('assets', { recursive: true });

  await sharp(buffer)
    .png()
    .toFile('public/HourTV_Logo.png');

  await sharp(buffer)
    .png()
    .toFile('src/assets/HourTV_Logo.png');

  await sharp(buffer)
    .png()
    .toFile('assets/HourTV_Logo.png');

  console.log('HourTV_Logo.png generated successfully!');
}

generate().catch(console.error);
