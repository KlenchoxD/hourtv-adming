export const INITIAL_VISIBLE_ITEMS = 9;
export const PROGRESSIVE_BATCH_SIZE = 6;

const clampVisibleCount = (count, total) => Math.max(0, Math.min(count, total));

export const initialVisibleCount = (total) => clampVisibleCount(INITIAL_VISIBLE_ITEMS, total);

export const resetVisibleCount = (total) => initialVisibleCount(total);

export const nextVisibleCount = (current, total) => clampVisibleCount(
  current + PROGRESSIVE_BATCH_SIZE,
  total,
);

export const progressiveSlice = (items, visibleCount) => {
  const seen = new Set();
  const uniqueItems = [];

  for (const item of items) {
    if (!item?.id || seen.has(item.id)) continue;
    seen.add(item.id);
    uniqueItems.push(item);
  }

  return uniqueItems.slice(0, clampVisibleCount(visibleCount, uniqueItems.length));
};

export const normalizeSearchText = (value) => String(value ?? '')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLocaleLowerCase('es')
  .trim();

export const filterCatalog = (items, query) => {
  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return [...items];

  return items.filter((item) => {
    const searchableValues = [
      item.title,
      item.type,
      ...(Array.isArray(item.genres) ? item.genres : []),
      ...(Array.isArray(item.cast) ? item.cast.map((person) => person?.name) : []),
      item.technicalDetails?.director,
      item.synopsis,
    ];

    return searchableValues.some((value) => normalizeSearchText(value).includes(normalizedQuery));
  });
};
