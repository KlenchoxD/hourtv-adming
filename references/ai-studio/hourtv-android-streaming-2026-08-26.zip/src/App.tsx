import React, { useState } from 'react';
import {
  RouteId,
  MediaItem,
  Episode,
  TVChannel,
  UserProfile,
  SnackbarState,
  ViewportOption
} from './types';
import {
  MOCK_MEDIA_ITEMS,
  MOCK_TV_CHANNELS,
  INITIAL_USER_PROFILE
} from './data/mockData';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { AndroidFrame } from './components/common/AndroidFrame';
import {
  ReviewInspector,
  VIEWPORT_OPTIONS
} from './components/common/ReviewInspector';
import { Snackbar } from './components/common/Snackbar';
import {
  InitialLoadingState,
  ErrorView,
  OfflineView,
  ParentalPinModal
} from './components/common/SystemStates';

// Views
import { HomeView } from './views/HomeView';
import { SearchView } from './views/SearchView';
import { DetailsView } from './views/DetailsView';
import { LibraryView } from './views/LibraryView';
import { LiveTvView } from './views/LiveTvView';
import { ProfileView } from './views/ProfileView';
import { PlayerView } from './views/PlayerView';
import { AccessView } from './views/AccessView';
import { SystemStatesView } from './views/SystemStatesView';
import { OriginalsView } from './views/OriginalsView';
import { resolvePlaybackEpisode } from './playerBehavior';
import { useAppUpdate } from './hooks/useAppUpdate';
import { ProfileGate, ProfileDraft } from '../ProfileGate.tsx';
import {
  PROFILE_STORAGE_KEY,
  createProfile,
  deleteProfile,
  loadProfiles,
  serializeProfiles,
  updateProfile
} from '../profileBehavior.mjs';

const PROFILE_AVATAR_COLORS = [
  '#00C781',
  '#2D7FF9',
  '#F5A524',
  '#A855F7',
  '#14B8A6',
  '#E5484D',
  '#64748B',
  '#D97706'
];

const hydrateUserProfile = (profile: Partial<UserProfile>, index: number): UserProfile => ({
  ...INITIAL_USER_PROFILE,
  ...profile,
  id: profile.id ?? `profile-${index + 1}`,
  name: profile.name ?? `Perfil ${index + 1}`,
  avatarId: profile.avatarId ?? `avatar-${(index % 8) + 1}`,
  avatarColor: profile.avatarColor ?? PROFILE_AVATAR_COLORS[index % PROFILE_AVATAR_COLORS.length],
  isPrimary: index === 0,
  isKids: Boolean(profile.isKids)
});

const readStoredProfiles = (): UserProfile[] => {
  if (typeof window === 'undefined') return [];
  return loadProfiles(window.localStorage.getItem(PROFILE_STORAGE_KEY)).map(hydrateUserProfile);
};

export default function App() {
  // Navigation State
  const [currentRoute, setCurrentRoute] = useState<RouteId>('home');
  const [previousRoute, setPreviousRoute] = useState<RouteId>('home');

  // Active Content State
  const [mediaList, setMediaList] = useState<MediaItem[]>(MOCK_MEDIA_ITEMS);
  const [channelsList, setChannelsList] = useState<TVChannel[]>(MOCK_TV_CHANNELS);
  const [selectedMedia, setSelectedMedia] = useState<MediaItem>(MOCK_MEDIA_ITEMS[0]);
  const [activeEpisode, setActiveEpisode] = useState<Episode | undefined>(undefined);
  const [activeChannel, setActiveChannel] = useState<TVChannel>(MOCK_TV_CHANNELS[0]);
  const [profiles, setProfiles] = useState<UserProfile[]>(readStoredProfiles);
  const [userProfile, setUserProfile] = useState<UserProfile>(() => profiles[0] ?? INITIAL_USER_PROFILE);
  const [isProfileGateOpen, setIsProfileGateOpen] = useState<boolean>(true);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);

  // Snackbar Toast State
  const [snackbar, setSnackbar] = useState<SnackbarState | null>(null);

  // Review & Simulation State
  const [selectedViewport, setSelectedViewport] = useState<ViewportOption>(VIEWPORT_OPTIONS[0]);
  const [isSimulatedOffline, setIsSimulatedOffline] = useState<boolean>(false);
  const [isSimulatedLoading, setIsSimulatedLoading] = useState<boolean>(false);
  const [isSimulatedError, setIsSimulatedError] = useState<boolean>(false);
  const [isEmptyLibrary, setIsEmptyLibrary] = useState<boolean>(false);
  const [isParentalRestricted, setIsParentalRestricted] = useState<boolean>(false);
  const [isQaMode, setIsQaMode] = useState<boolean>(false);
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);
  const [pendingRestrictedAction, setPendingRestrictedAction] = useState<(() => void) | null>(null);

  // App Update Hook (separated check & state logic)
  const {
    updateInfo,
    isUpdating,
    updateProgress,
    hasPendingUpdate,
    checkUpdates,
    executeUpdate
  } = useAppUpdate();

  const showSnackbar = (message: string, actionLabel?: string, onAction?: () => void) => {
    setSnackbar({
      id: String(Date.now()),
      message,
      actionLabel,
      onAction
    });
  };

  const navigateTo = (route: RouteId) => {
    setPreviousRoute(currentRoute);
    setCurrentRoute(route);
  };

  const persistProfiles = (nextProfiles: UserProfile[]) => {
    setProfiles(nextProfiles);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(PROFILE_STORAGE_KEY, serializeProfiles(nextProfiles));
    }
  };

  const handleSelectProfile = (profile: UserProfile) => {
    setUserProfile(profile);
    setIsProfileGateOpen(false);
    setPreviousRoute('home');
    setCurrentRoute('home');
  };

  const handleCreateProfile = (draft: ProfileDraft) => {
    const createdProfiles = createProfile(profiles, draft)
      .map((profile: Partial<UserProfile>, index: number) => hydrateUserProfile(profile, index));
    const createdProfile = createdProfiles[createdProfiles.length - 1];
    persistProfiles(createdProfiles);
    handleSelectProfile(createdProfile);
  };

  const handleUpdateProfileIdentity = (profileId: string, draft: ProfileDraft) => {
    const updatedProfiles = updateProfile(profiles, profileId, draft)
      .map((profile: Partial<UserProfile>, index: number) => hydrateUserProfile(profile, index));
    persistProfiles(updatedProfiles);
    if (userProfile.id === profileId) {
      const active = updatedProfiles.find((profile) => profile.id === profileId);
      if (active) setUserProfile(active);
    }
  };

  const handleDeleteProfile = (profileId: string) => {
    const remainingProfiles = deleteProfile(profiles, profileId)
      .map((profile: Partial<UserProfile>, index: number) => hydrateUserProfile(profile, index));
    persistProfiles(remainingProfiles);
    if (userProfile.id === profileId && remainingProfiles[0]) setUserProfile(remainingProfiles[0]);
  };

  const handleUpdateUserProfile = (updatedProfile: UserProfile) => {
    persistProfiles(profiles.map((profile) => profile.id === updatedProfile.id ? updatedProfile : profile));
    setUserProfile(updatedProfile);
  };

  // Toggle My List
  const handleToggleMyList = (item: MediaItem) => {
    const nextList = mediaList.map((m) => {
      if (m.id === item.id) {
        const nextState = !m.isInMyList;
        return { ...m, isInMyList: nextState };
      }
      return m;
    });
    setMediaList(nextList);

    const isNowInList = !item.isInMyList;
    if (isNowInList) {
      showSnackbar(`"${item.title}" se añadió a Mi Lista.`);
    } else {
      showSnackbar(`"${item.title}" se quitó de Mi Lista.`, 'Deshacer', () => {
        setMediaList((prev) =>
          prev.map((m) => (m.id === item.id ? { ...m, isInMyList: true } : m))
        );
      });
    }

    if (selectedMedia.id === item.id) {
      setSelectedMedia((prev) => ({ ...prev, isInMyList: !prev.isInMyList }));
    }
  };

  // Select Media -> Details
  const handleSelectMedia = (item: MediaItem) => {
    setSelectedMedia(item);
    setActiveEpisode(item.episodes && item.episodes.length > 0 ? item.episodes[0] : undefined);
    navigateTo('details');
  };

  // Play Media -> Player (checks parental restriction)
  const handlePlayMedia = (item: MediaItem, episode?: Episode) => {
    const playbackEpisode = resolvePlaybackEpisode({
      isSeries: item.type === 'series',
      requestedEpisode: episode,
      episodes: item.episodes,
    });

    if (isParentalRestricted && item.ageRating === '18+') {
      setPendingRestrictedAction(() => () => {
        setSelectedMedia(item);
        setActiveEpisode(playbackEpisode);
        navigateTo('player');
      });
      setIsPinModalOpen(true);
      return;
    }

    setSelectedMedia(item);
    setActiveEpisode(playbackEpisode);
    navigateTo('player');
  };

  // Channel Selection
  const handleSelectChannel = (channel: TVChannel) => {
    setActiveChannel(channel);
  };

  const handleToggleFavoriteChannel = (channel: TVChannel) => {
    const nextChannels = channelsList.map((c) => {
      if (c.id === channel.id) {
        return { ...c, isFavorite: !c.isFavorite };
      }
      return c;
    });
    setChannelsList(nextChannels);
    const isNowFav = !channel.isFavorite;
    showSnackbar(
      isNowFav
        ? `Canal ${channel.channelNumber} "${channel.name}" guardado en Favoritos.`
        : `Canal ${channel.name} quitado de Favoritos.`
    );
  };

  // Reset Demo Data
  const handleResetDemoData = () => {
    setMediaList(MOCK_MEDIA_ITEMS);
    setChannelsList(MOCK_TV_CHANNELS);
    setUserProfile(profiles[0] ?? INITIAL_USER_PROFILE);
    setIsSimulatedOffline(false);
    setIsSimulatedLoading(false);
    setIsSimulatedError(false);
    setIsEmptyLibrary(false);
    setIsParentalRestricted(false);
    setIsLoggedIn(true);
    setIsProfileGateOpen(true);
    setCurrentRoute('home');
    showSnackbar('Datos de demostración restablecidos.');
  };

  // Calculate items in library
  const currentMyList = isEmptyLibrary ? [] : mediaList.filter((m) => m.isInMyList);

  // Render view inside Android frame
  const renderCurrentView = () => {
    if (isSimulatedLoading) {
      return <InitialLoadingState />;
    }

    if (isSimulatedError) {
      return (
        <ErrorView
          onRetry={() => {
            setIsSimulatedError(false);
            showSnackbar('Servidores de HourTV reconectados.');
          }}
        />
      );
    }

    if (isSimulatedOffline && currentRoute !== 'library' && currentRoute !== 'system_states') {
      return (
        <OfflineView
          onRetry={() => {
            setIsSimulatedOffline(false);
            showSnackbar('Conexión 5G/Wi-Fi reestablecida.');
          }}
          onGoToDownloads={() => navigateTo('library')}
        />
      );
    }

    switch (currentRoute) {
      case 'home':
        return (
          <HomeView
            mediaItems={mediaList}
            tvChannels={channelsList}
            onSelectMedia={handleSelectMedia}
            onPlayMedia={handlePlayMedia}
            onToggleMyList={handleToggleMyList}
            onNavigate={navigateTo}
            onSelectChannel={(ch) => {
              handleSelectChannel(ch);
              navigateTo('live_tv');
            }}
          />
        );

      case 'search':
        return (
          <SearchView
            mediaItems={mediaList}
            onSelectMedia={handleSelectMedia}
            onToggleMyList={handleToggleMyList}
          />
        );

      case 'details':
        return (
          <DetailsView
            item={selectedMedia}
            allMedia={mediaList}
            onBack={() => navigateTo(previousRoute === 'details' ? 'home' : previousRoute)}
            onPlayMedia={handlePlayMedia}
            onToggleMyList={handleToggleMyList}
            onSelectRelatedMedia={handleSelectMedia}
            onShowSnackbar={showSnackbar}
          />
        );

      case 'library':
        return (
          <LibraryView
            myList={currentMyList}
            allMedia={mediaList}
            onSelectMedia={handleSelectMedia}
            onPlayMedia={handlePlayMedia}
            onRemoveFromMyList={handleToggleMyList}
            onExploreCatalog={() => navigateTo('home')}
            onShowSnackbarWithUndo={(item) => {
              showSnackbar(`"${item.title}" eliminado de tu lista.`, 'Deshacer', () => {
                handleToggleMyList(item);
              });
            }}
          />
        );

      case 'live_tv':
        return (
          <LiveTvView
            channels={channelsList}
            activeChannel={activeChannel}
            onSelectChannel={handleSelectChannel}
            onToggleFavorite={handleToggleFavoriteChannel}
            adultContentEnabled={userProfile.parentalControlEnabled}
          />
        );

      case 'profile':
        return (
          <ProfileView
            userProfile={userProfile}
            profiles={profiles}
            updateInfo={updateInfo}
            isUpdating={isUpdating}
            updateProgress={updateProgress}
            onCheckUpdates={checkUpdates}
            onExecuteUpdate={executeUpdate}
            onUpdateProfile={handleUpdateUserProfile}
            onSwitchProfile={handleSelectProfile}
            onManageProfiles={() => setIsProfileGateOpen(true)}
            onLogout={() => {
              setIsLoggedIn(false);
              setIsProfileGateOpen(false);
              navigateTo('access');
            }}
            onShowSnackbar={showSnackbar}
          />
        );

      case 'player':
        return (
          <PlayerView
            item={selectedMedia}
            episode={activeEpisode}
            onBack={() => navigateTo('details')}
            onNextEpisode={() => {
              if (selectedMedia.episodes && selectedMedia.episodes.length > 1) {
                const currentIdx = selectedMedia.episodes.findIndex(
                  (ep) => ep.id === activeEpisode?.id
                );
                const nextEp = selectedMedia.episodes[(currentIdx + 1) % selectedMedia.episodes.length];
                setActiveEpisode(nextEp);
                showSnackbar(`Reproduciendo ${nextEp.title}`);
              }
            }}
            onShowSnackbar={showSnackbar}
          />
        );

      case 'access':
        return (
          <AccessView
            onLoginSuccess={() => {
              setIsLoggedIn(true);
              setIsProfileGateOpen(true);
              navigateTo('home');
            }}
            onShowSnackbar={showSnackbar}
          />
        );

      case 'system_states':
        return <SystemStatesView onShowSnackbar={showSnackbar} />;

      case 'originals':
        return (
          <OriginalsView
            mediaItems={mediaList}
            onBack={() => navigateTo(previousRoute === 'originals' ? 'home' : previousRoute)}
            onSelectMedia={handleSelectMedia}
            onToggleMyList={handleToggleMyList}
          />
        );

      default:
        return (
          <HomeView
            mediaItems={mediaList}
            tvChannels={channelsList}
            onSelectMedia={handleSelectMedia}
            onPlayMedia={handlePlayMedia}
            onToggleMyList={handleToggleMyList}
            onNavigate={navigateTo}
            onSelectChannel={handleSelectChannel}
          />
        );
    }
  };

  const isFullscreenPlayer = currentRoute === 'player';
  const showProfileGate = isLoggedIn && isProfileGateOpen;
  const showHeader = !showProfileGate && currentRoute === 'home' && !isSimulatedLoading;
  const showBottomNav = !showProfileGate && !isFullscreenPlayer && currentRoute !== 'access' && !isSimulatedLoading;

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F5] flex flex-col">
      {/* Internal QA tools stay collapsed during normal product review. */}
      {!showProfileGate && (isQaMode ? (
        <ReviewInspector
          currentRoute={currentRoute}
          onSelectRoute={navigateTo}
          selectedViewport={selectedViewport}
          onSelectViewport={setSelectedViewport}
          isSimulatedOffline={isSimulatedOffline}
          onToggleOffline={() => {
            const next = !isSimulatedOffline;
            setIsSimulatedOffline(next);
            showSnackbar(next ? 'Modo sin conexión activado' : 'Conexión restaurada');
          }}
          isSimulatedLoading={isSimulatedLoading}
          onToggleLoading={() => {
            const next = !isSimulatedLoading;
            setIsSimulatedLoading(next);
            showSnackbar(next ? 'Simulando carga inicial...' : 'Carga finalizada');
          }}
          isSimulatedError={isSimulatedError}
          onToggleError={() => {
            const next = !isSimulatedError;
            setIsSimulatedError(next);
            showSnackbar(next ? 'Simulando error 500...' : 'Error resuelto');
          }}
          isEmptyLibrary={isEmptyLibrary}
          onToggleEmptyLibrary={() => {
            const next = !isEmptyLibrary;
            setIsEmptyLibrary(next);
            showSnackbar(next ? 'Biblioteca vaciada' : 'Biblioteca con elementos');
          }}
          isParentalRestricted={isParentalRestricted}
          onToggleParental={() => {
            const next = !isParentalRestricted;
            setIsParentalRestricted(next);
            showSnackbar(next ? 'Restricción PIN +18 activada' : 'Restricción desactivada');
          }}
          onResetDemoData={handleResetDemoData}
          onCloseQaMode={() => setIsQaMode(false)}
        />
      ) : (
        <button
          type="button"
          onClick={() => setIsQaMode(true)}
          className="fixed left-2 top-2 z-[70] rounded-lg border border-[#27302C] bg-[#101412]/90 px-2.5 py-1.5 text-[11px] font-semibold text-[#A8ADAB] shadow-lg backdrop-blur-md transition-colors hover:border-[#00C781] hover:text-white"
          aria-label="Panel QA"
        >
          Panel QA
        </button>
      ))}

      {/* Main Device Frame Container */}
      <AndroidFrame viewport={selectedViewport} isLandscape={isFullscreenPlayer}>
        {/* App Header (if not player/access) */}
        {showHeader && (
          <Header
            currentRoute={currentRoute}
            onNavigate={navigateTo}
            userProfile={userProfile}
            isOffline={isSimulatedOffline}
            onOpenCastModal={() => showSnackbar('Dispositivos disponibles: Living Android TV 4K')}
            onOpenProfileMenu={() => navigateTo('profile')}
          />
        )}

        {/* View Content */}
        <main className="flex-1 flex flex-col">
          {showProfileGate ? (
            <ProfileGate
              profiles={profiles}
              activeProfileId={userProfile.id}
              onSelect={handleSelectProfile}
              onCreate={handleCreateProfile}
              onUpdate={handleUpdateProfileIdentity}
              onDelete={handleDeleteProfile}
            />
          ) : renderCurrentView()}
        </main>

        {/* Android Bottom Navigation */}
        {showBottomNav && (
          <BottomNav
            currentRoute={currentRoute}
            onNavigate={navigateTo}
            hasPendingUpdate={hasPendingUpdate}
          />
        )}

        {/* Global Android Toast / Snackbar */}
        <Snackbar snackbar={snackbar} onDismiss={() => setSnackbar(null)} />

        {/* Parental PIN Modal */}
        <ParentalPinModal
          isOpen={isPinModalOpen}
          onClose={() => {
            setIsPinModalOpen(false);
            setPendingRestrictedAction(null);
          }}
          onSuccess={() => {
            setIsPinModalOpen(false);
            if (pendingRestrictedAction) {
              pendingRestrictedAction();
              setPendingRestrictedAction(null);
            }
          }}
          titleName={selectedMedia?.title || 'Contenido Restringido'}
          correctPin={userProfile.parentalPin}
        />
      </AndroidFrame>
    </div>
  );
}

