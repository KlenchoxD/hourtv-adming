import { AppUpdateInfo } from '../types';

const STORAGE_KEY = 'hourtv_installed_version';
const DEFAULT_INITIAL_VERSION = '2.6.4';
const LATEST_RELEASE_VERSION = '2.6.5';
const LATEST_BUILD_NUMBER = 8420;

export const appUpdateService = {
  /**
   * Returns the current installed version stored in localStorage or default.
   */
  getInstalledVersion(): string {
    try {
      return localStorage.getItem(STORAGE_KEY) || DEFAULT_INITIAL_VERSION;
    } catch {
      return DEFAULT_INITIAL_VERSION;
    }
  },

  /**
   * Sets the installed version into persistent storage.
   */
  setInstalledVersion(version: string): void {
    try {
      localStorage.setItem(STORAGE_KEY, version);
    } catch {
      // ignore in sandboxed environments
    }
  },

  /**
   * Fetches latest update metadata and compares with the installed version.
   */
  async checkVersion(): Promise<AppUpdateInfo> {
    // Simulate lightweight network check
    await new Promise((resolve) => setTimeout(resolve, 350));

    const installed = this.getInstalledVersion();
    const hasUpdate = installed !== LATEST_RELEASE_VERSION;

    return {
      currentVersion: installed,
      latestVersion: LATEST_RELEASE_VERSION,
      buildNumber: hasUpdate ? LATEST_BUILD_NUMBER : 8402,
      releaseDate: '22 de Agosto, 2026',
      hasUpdate,
      releaseNotes: [
        'Optimización del búfer de reproducción 4K Ultra HD en redes móviles.',
        'Mejora de sincronización en subtítulos automáticos en vivo.',
        'Corrección de latencia en canales de TV en Vivo.',
        'Mayor estabilidad de interfaz y transiciones fluidas.'
      ],
      sizeMB: 28.4,
      status: 'idle'
    };
  },

  /**
   * Performs the update process step-by-step.
   */
  async applyUpdate(onProgress?: (progress: number) => void): Promise<string> {
    // Simulate smooth download progress
    for (let p = 10; p <= 90; p += 20) {
      await new Promise((r) => setTimeout(r, 200));
      onProgress?.(p);
    }
    
    // Simulate installation
    await new Promise((r) => setTimeout(r, 300));
    onProgress?.(100);

    // Save newly installed version
    this.setInstalledVersion(LATEST_RELEASE_VERSION);
    return LATEST_RELEASE_VERSION;
  },

  /**
   * Resets to previous version for testing / QA.
   */
  resetToPreviousVersion(): void {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }
};
