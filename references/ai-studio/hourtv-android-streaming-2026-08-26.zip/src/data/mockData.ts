import { MediaItem, TVChannel, UserProfile } from '../types';

export const INITIAL_USER_PROFILE: UserProfile = {
  id: 'usr_renata',
  name: 'Renata',
  avatarId: 'avatar-1',
  avatarColor: '#00C781',
  isPrimary: true,
  isKids: false,
  email: 'renata.m@hourtv.app',
  planName: 'HourTV Premium Ultra 4K',
  streamQualityPreference: '4K',
  audioLanguagePreference: 'Español (Latino) Dolby Atmos',
  subtitlePreference: 'Desactivados',
  parentalControlEnabled: false,
  parentalPin: '1234',
  parentalMaxAge: '18+',
  dataSaverCellular: false,
  notificationsEnabled: true,
};

export const PROFILES_LIST: UserProfile[] = [
  INITIAL_USER_PROFILE,
  {
    id: 'usr_mateo',
    name: 'Mateo',
    avatarId: 'avatar-2',
    avatarColor: '#3B82F6',
    isPrimary: false,
    isKids: false,
    email: 'mateo@hourtv.app',
    planName: 'HourTV Premium Ultra 4K',
    streamQualityPreference: 'Auto',
    audioLanguagePreference: 'Español (España)',
    subtitlePreference: 'Español',
    parentalControlEnabled: false,
    parentalPin: '0000',
    parentalMaxAge: '16+',
    dataSaverCellular: true,
    notificationsEnabled: false,
  },
  {
    id: 'usr_kids',
    name: 'HourTV Kids',
    avatarId: 'avatar-3',
    avatarColor: '#F59E0B',
    isPrimary: false,
    isKids: true,
    email: 'kids@hourtv.app',
    planName: 'HourTV Premium Ultra 4K',
    streamQualityPreference: '1080p',
    audioLanguagePreference: 'Español (Latino)',
    subtitlePreference: 'Desactivados',
    parentalControlEnabled: true,
    parentalPin: '1234',
    parentalMaxAge: 'TP',
    dataSaverCellular: false,
    notificationsEnabled: false,
  },
];

export const MOCK_MEDIA_ITEMS: MediaItem[] = [
  {
    id: 'el-ultimo-amanecer',
    title: 'El último amanecer',
    type: 'movie',
    year: 2026,
    ageRating: '16+',
    durationOrSeasons: '2 h 18 min',
    genres: ['Drama', 'Ciencia Ficción', 'Suspenso'],
    isOriginal: true,
    isTrending: true,
    matchScore: 98,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Un thriller de ciencia ficción sobre la última ciudad protegida que espera el regreso del sol tras un eclipse global de tres décadas. La capitana Elena Ruiz descubre que la radiación exterior esconde una verdad oculta por el consejo superior.',
    whyWatch: 'Una obra maestra visual galardonada por su diseño sonoro inmersivo y una fotografía crepuscular hipnótica.',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    ratingAverage: 9.4,
    releaseDateISO: '2026-03-12',
    isInMyList: true,
    progressPercentage: 65,
    cast: [
      { id: 'c1', name: 'Elena Ruiz', character: 'Comandante Ruiz', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop' },
      { id: 'c2', name: 'David Vance', character: 'Dr. Aaron Cole', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop' },
      { id: 'c3', name: 'Sara Moreau', character: 'Ministra Kael', avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=200&auto=format&fit=crop' },
      { id: 'c4', name: 'Marcus Bell', character: 'Piloto Jaxon', avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Carlos Montero',
      outlet: 'Cine & Visión Editorial',
      score: 96,
      summary: 'Impactante, tensa y con una atmósfera que redefine el género de ciencia ficción latinoamericano contemporáneo.',
      date: '15 de Mayo, 2026'
    },
    technicalDetails: {
      resolution: '3840 × 2160 (4K UHD Master Nativo)',
      hdrFormat: 'Dolby Vision Perfil 8.1 & HDR10+ Adaptativo',
      audioTrack: 'Dolby Atmos TrueHD 7.1.4 (Pistas 24-bit / 48kHz)',
      aspectRatio: '2.39:1 Panavision Anamórfico',
      director: 'Gabriel Sotomayor',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés (Dolby Atmos)', 'Portugués (5.1)', 'Francés (5.1)'],
      subtitles: ['Español [CC]', 'Inglés [CC]', 'Portugués', 'Alemán', 'Italiano'],
      ageRatingDescription: 'Contiene secuencias de acción intensa, peligro psicológico y lenguaje moderado.'
    }
  },
  {
    id: 'frontera-roja',
    title: 'Frontera Roja',
    type: 'series',
    year: 2026,
    ageRating: '18+',
    durationOrSeasons: '3 Temporadas',
    genres: ['Crimen', 'Drama', 'Acción', 'Suspenso'],
    isOriginal: true,
    isTrending: true,
    matchScore: 99,
    qualityBadges: ['4K UHD', 'HDR10+', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Una agente de inteligencia encubierta ingresa a la frontera norte donde nada es lo que parece y descubre una red que conecta a ambos lados de la ley.',
    whyWatch: 'Considerada la serie de intriga geopolítica más aclamada de la temporada por su ritmo implacable.',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    ratingAverage: 9.6,
    releaseDateISO: '2026-01-20',
    isInMyList: true,
    progressPercentage: 40,
    cast: [
      { id: 'c5', name: 'Valeria Solís', character: 'Agente Lucía Méndez', avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop' },
      { id: 'c6', name: 'Rodrigo Santoro', character: 'Coronel Barba', avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=200&auto=format&fit=crop' },
      { id: 'c7', name: 'Alba Flores', character: 'Dra. Inés Peralta', avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Lucía Fernández',
      outlet: 'StreamReport Global',
      score: 98,
      summary: 'Una narrativa magistral con giros calculados al milímetro y actuaciones de primer nivel.',
      date: '10 de Junio, 2026'
    },
    technicalDetails: {
      resolution: '3840 × 2160 (4K UHD)',
      hdrFormat: 'HDR10 / HLG',
      audioTrack: 'Dolby Digital Plus 5.1 & Stereo Envolvente',
      aspectRatio: '2.00:1 Univisium',
      director: 'Mariana Cordero',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés (5.1)', 'Italiano'],
      subtitles: ['Español [CC]', 'Inglés', 'Francés'],
      ageRatingDescription: 'Violencia explícita, lenguaje adulto y temas de crimen organizado.'
    },
    episodes: [
      {
        id: 'fr-s1-e1',
        seasonNumber: 1,
        episodeNumber: 1,
        title: 'Sombras en el límite',
        durationMinutes: 52,
        thumbnailUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 100,
        synopsis: 'Lucía llega al puesto fronterizo bajo una identidad civil tras la interceptación de un convoy fantasma.'
      },
      {
        id: 'fr-s1-e2',
        seasonNumber: 1,
        episodeNumber: 2,
        title: 'Vuelo ciego',
        durationMinutes: 48,
        thumbnailUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 100,
        synopsis: 'Una persecución en el desierto nocturno pone a prueba las lealtades del equipo táctico.'
      },
      {
        id: 'fr-s1-e3',
        seasonNumber: 1,
        episodeNumber: 3,
        title: 'Punto de inflexión',
        durationMinutes: 55,
        thumbnailUrl: 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 45,
        synopsis: 'Una llamada encriptada revela infiltraciones en los niveles más altos del mando estatal.'
      },
      {
        id: 'fr-s1-e4',
        seasonNumber: 1,
        episodeNumber: 4,
        title: 'Frecuencia cero',
        durationMinutes: 50,
        thumbnailUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 0,
        synopsis: 'El corte de comunicaciones deja a la unidad aislada en un búnker de montaña.'
      },
      {
        id: 'fr-s1-e5',
        seasonNumber: 1,
        episodeNumber: 5,
        title: 'El pacto roto',
        durationMinutes: 58,
        thumbnailUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 0,
        synopsis: 'El desenlace de la primera temporada culmina en una operación de alto riesgo.'
      }
    ]
  },
  {
    id: 'sombras-de-hielo',
    title: 'Sombras de hielo',
    type: 'movie',
    year: 2025,
    ageRating: '16+',
    durationOrSeasons: '1 h 52 min',
    genres: ['Suspenso', 'Misterio', 'Drama'],
    isOriginal: false,
    isTrending: true,
    matchScore: 94,
    qualityBadges: ['4K UHD', 'HDR10', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'En una estación meteorológica aislada en el archipiélago ártico, un equipo de científicos descubre un cilindro criogénico no registrado que data de 1962.',
    whyWatch: 'Tensión claustrofóbica y una banda sonora gélida que te mantendrá al filo del asiento.',
    ratingAverage: 8.9,
    releaseDateISO: '2025-11-14',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c8', name: 'Mads Hansen', character: 'Dr. Erik Lind', avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=200&auto=format&fit=crop' },
      { id: 'c9', name: 'Astrid Bergman', character: 'Geóloga Astrid', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Tomás Rivas',
      outlet: 'Nordic Cinema Weekly',
      score: 91,
      summary: 'Un ejercicio impecable de tensión psicológica en entornos hostiles.',
      date: '28 de Noviembre, 2025'
    },
    technicalDetails: {
      resolution: '3840 × 2160',
      hdrFormat: 'HDR10',
      audioTrack: 'Dolby Digital Plus 5.1',
      aspectRatio: '2.35:1',
      director: 'Kasper Nygren',
      audioLanguages: ['Español (Neutro)', 'Noruego [Original]', 'Inglés'],
      subtitles: ['Español', 'Inglés'],
      ageRatingDescription: 'Suspenso intenso, angustia psicológica.'
    }
  },
  {
    id: 'la-voz-infinita',
    title: 'La voz infinita',
    type: 'movie',
    year: 2024,
    ageRating: '13+',
    durationOrSeasons: '2 h 04 min',
    genres: ['Ciencia Ficción', 'Drama'],
    isOriginal: false,
    isTrending: false,
    matchScore: 92,
    qualityBadges: ['4K UHD', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'Un radioastrónomo intercepta una frecuencia armónica proveniente del cúmulo de Perseo que parece responder en tiempo real a las emociones de quien la escucha.',
    whyWatch: 'Una exploración poética sobre la conexión humana y el cosmos profundo.',
    ratingAverage: 8.8,
    releaseDateISO: '2024-09-05',
    isInMyList: true,
    progressPercentage: 15,
    cast: [
      { id: 'c10', name: 'Julian Cross', character: 'Profesor Kenneth', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Beatriz Luna',
      outlet: 'Ciencia & Pantalla',
      score: 93,
      summary: 'Sensible y visualmente deslumbrante, rescata la ciencia ficción más reflexiva.',
      date: '14 de Octubre, 2024'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10+',
      audioTrack: 'Dolby Atmos 7.1',
      aspectRatio: '1.85:1',
      director: 'Nadia Chen',
      audioLanguages: ['Español (Latino)', 'Inglés [Original]'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Apto para mayores de 13 años.'
    }
  },
  {
    id: 'codigo-orbita',
    title: 'Código Órbita',
    type: 'movie',
    year: 2026,
    ageRating: '16+',
    durationOrSeasons: '1 h 48 min',
    genres: ['Acción', 'Ciencia Ficción', 'Cyberpunk'],
    isOriginal: true,
    isTrending: true,
    matchScore: 97,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'ESTRENO EXCLUSIVO',
    synopsis: 'En una megaciudad orbital autosuficiente, un ex-analista de seguridad debe hackear la inteligencia central antes de que el protocolo de purga reinicie los hábitats.',
    whyWatch: 'Coreografías cibernéticas de alta velocidad y efectos visuales de última generación.',
    ratingAverage: 9.3,
    releaseDateISO: '2026-02-18',
    isInMyList: true,
    progressPercentage: 80,
    cast: [
      { id: 'c11', name: 'Kenji Sato', character: 'Ren Takahashi', avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Jorge Valdés',
      outlet: 'CyberAction Daily',
      score: 95,
      summary: 'Pura adrenalina cinética que aprovecha cada segundo de metraje.',
      date: '20 de Febrero, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD 60FPS',
      hdrFormat: 'Dolby Vision',
      audioTrack: 'Dolby Atmos',
      aspectRatio: '2.39:1',
      director: 'Liam Gallagher',
      audioLanguages: ['Español (Latino)', 'Japonés [Original]', 'Inglés'],
      subtitles: ['Español', 'Inglés', 'Japonés'],
      ageRatingDescription: 'Violencia estilizada, secuencias de acción frenéticas.'
    }
  },
  {
    id: 'memoria-de-cristal',
    title: 'Memoria de cristal',
    type: 'movie',
    year: 2025,
    ageRating: '13+',
    durationOrSeasons: '1 h 56 min',
    genres: ['Drama', 'Romance', 'Misterio'],
    isOriginal: false,
    isTrending: false,
    matchScore: 90,
    qualityBadges: ['4K UHD', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'Una restauradora de arte descubre cartas ocultas tras una serie de vitrales coloniales que revelan la desaparición de un pianista en 1934.',
    whyWatch: 'Una narrativa íntima y conmovedora sobre la memoria, el arte y el destino.',
    ratingAverage: 8.7,
    releaseDateISO: '2025-08-10',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c12', name: 'Sofía Carvajal', character: 'Clara Domínguez', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Ana Beltrán',
      outlet: 'Letras & Celuloide',
      score: 89,
      summary: 'Elegante y cautivadora, con una dirección de arte impecable.',
      date: '12 de Septiembre, 2025'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10',
      audioTrack: 'Dolby Digital 5.1',
      aspectRatio: '1.85:1',
      director: 'Mateo Osorio',
      audioLanguages: ['Español (España) [Original]'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Apto para mayores de 13 años.'
    }
  },
  {
    id: 'el-refugio-nocturno',
    title: 'El refugio nocturno',
    type: 'movie',
    year: 2024,
    ageRating: '18+',
    durationOrSeasons: '2 h 10 min',
    genres: ['Terror', 'Suspenso'],
    isOriginal: false,
    isTrending: true,
    matchScore: 91,
    qualityBadges: ['4K UHD', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'Un grupo de viajeros queda varado en una posada de montaña durante la noche más larga del año, donde las sombras cobran voluntad propia.',
    whyWatch: 'Terror de atmósfera implacable que no depende de sustos fáciles.',
    ratingAverage: 8.6,
    releaseDateISO: '2024-10-31',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c13', name: 'Hugo Silva', character: 'Marcos', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Víctor Solano',
      outlet: 'Noche de Cine',
      score: 88,
      summary: 'Inquietante de principio a fin, aprovecha cada rincón de la cabaña.',
      date: '5 de Noviembre, 2024'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10',
      audioTrack: 'Dolby Surround 5.1',
      aspectRatio: '2.39:1',
      director: 'Raúl Morales',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español', 'Inglés'],
      ageRatingDescription: 'Terror psicológico, tensión gráfica.'
    }
  },
  {
    id: 'silencio-en-el-bosque',
    title: 'Silencio en el bosque',
    type: 'series',
    year: 2024,
    ageRating: '16+',
    durationOrSeasons: '2 Temporadas',
    genres: ['Misterio', 'Drama', 'Crimen'],
    isOriginal: false,
    isTrending: false,
    matchScore: 93,
    qualityBadges: ['1080p HD', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'La misteriosa desaparición de una guardabosques destapa una trama de experimentos biológicos en una reserva natural protegida.',
    whyWatch: 'Fotografía naturalista majestuosa y un enigma que te atrapa desde el episodio piloto.',
    ratingAverage: 9.0,
    releaseDateISO: '2024-05-18',
    isInMyList: true,
    progressPercentage: 20,
    cast: [
      { id: 'c14', name: 'Laura Novoa', character: 'Agente Paula Varela', avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Eduardo Paz',
      outlet: 'Revista Seriados',
      score: 92,
      summary: 'Tensión constante en un paisaje tan sobrecogedor como claustrofóbico.',
      date: '1 de Junio, 2024'
    },
    technicalDetails: {
      resolution: 'Full HD 1080p',
      hdrFormat: 'SDR Master',
      audioTrack: 'Dolby Digital Plus 5.1',
      aspectRatio: '16:9',
      director: 'Ignacio Ortiz',
      audioLanguages: ['Español (Latino) [Original]'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Crimen y misterio.'
    },
    episodes: [
      {
        id: 'seb-s1-e1',
        seasonNumber: 1,
        episodeNumber: 1,
        title: 'Niebla en la cumbre',
        durationMinutes: 46,
        thumbnailUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 100,
        synopsis: 'Un todoterreno abandonado con el motor encendido alerta a la estación central.'
      },
      {
        id: 'seb-s1-e2',
        seasonNumber: 1,
        episodeNumber: 2,
        title: 'Rastros en el musgo',
        durationMinutes: 50,
        thumbnailUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 30,
        synopsis: 'Los perros de rastreo pierden la pista junto a una antigua mina clausurada.'
      }
    ]
  },
  {
    id: 'ciudad-nocturna',
    title: 'Ciudad nocturna',
    type: 'series',
    year: 2025,
    ageRating: '18+',
    durationOrSeasons: '1 Temporada',
    genres: ['Crimen', 'Neo-Noir', 'Drama'],
    isOriginal: true,
    isTrending: true,
    matchScore: 95,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Bajo las luces de neón y la lluvia ácida de una metrópolis costera, un detective privado investiga el chantaje a un consorcio tecnológico de energía limpia.',
    whyWatch: 'Estética neo-noir implacable con atmósfera sonora sintetizada analógica.',
    ratingAverage: 9.2,
    releaseDateISO: '2025-04-12',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c15', name: 'Nicolás Furtado', character: 'Detective Dante', avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Esteban Reyes',
      outlet: 'Noir Cinema Digest',
      score: 94,
      summary: 'El género noir encuentra en esta producción su más elegante manifestación contemporánea.',
      date: '25 de Abril, 2025'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10+ / Dolby Vision',
      audioTrack: 'Dolby Atmos 7.1.4',
      aspectRatio: '2.39:1',
      director: 'Sebastián Silva',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Violencia, contenido adulto y lenguaje fuerte.'
    },
    episodes: [
      {
        id: 'cn-s1-e1',
        seasonNumber: 1,
        episodeNumber: 1,
        title: 'Asfalto mojado',
        durationMinutes: 54,
        thumbnailUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 0,
        synopsis: 'Dante es contratado para recuperar un disco duro cifrado antes del amanecer.'
      }
    ]
  },
  {
    id: 'horizonte-cero',
    title: 'Horizonte cero',
    type: 'series',
    year: 2026,
    ageRating: '16+',
    durationOrSeasons: '2 Temporadas',
    genres: ['Ciencia Ficción', 'Aventura'],
    isOriginal: true,
    isTrending: false,
    matchScore: 96,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'La primera tripulación internacional en viajar más allá del cinturón de Kuiper debe descifrar un artefacto alienígena que altera el flujo del tiempo relativo.',
    whyWatch: 'Grandiosidad astronómica basada en física teórica rigurosa y drama humano profundo.',
    ratingAverage: 9.5,
    releaseDateISO: '2026-04-01',
    isInMyList: true,
    progressPercentage: 10,
    cast: [
      { id: 'c16', name: 'Clara Lago', character: 'Dra. Maya Vance', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Martín Barrenechea',
      outlet: 'AstroFilm Review',
      score: 97,
      summary: 'Una ambición cósmica ejecutada con virtuosismo técnico y rigor científico.',
      date: '10 de Abril, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'Dolby Vision',
      audioTrack: 'Dolby Atmos',
      aspectRatio: '2.20:1 IMAX',
      director: 'Alejandro Amenábar',
      audioLanguages: ['Español (Latino)', 'Inglés [Original]'],
      subtitles: ['Español [CC]', 'Inglés [CC]'],
      ageRatingDescription: 'Apto para mayores de 16 años.'
    },
    episodes: [
      {
        id: 'hz-s1-e1',
        seasonNumber: 1,
        episodeNumber: 1,
        title: 'El salto cuántico',
        durationMinutes: 62,
        thumbnailUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=600&auto=format&fit=crop',
        progressPercentage: 10,
        synopsis: 'La nave Odisea cruza el umbral magnético mientras los relojes internos divergen.'
      }
    ]
  },
  {
    id: 'marea-oscura',
    title: 'Marea oscura',
    type: 'movie',
    year: 2025,
    ageRating: '16+',
    durationOrSeasons: '1 h 42 min',
    genres: ['Acción', 'Suspenso', 'Aventuras'],
    isOriginal: false,
    isTrending: false,
    matchScore: 89,
    qualityBadges: ['1080p HD', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'Un buzo de rescate debe descender a 200 metros en una plataforma petrolífera en colapso para asegurar las válvulas de cierre antes de que el oleaje destruya la estructura.',
    whyWatch: 'Adrenalina submarina constante y efectos prácticos de máxima tensión.',
    ratingAverage: 8.5,
    releaseDateISO: '2025-07-22',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c17', name: 'Pedro Pascal', character: 'Buzo Tomás', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Gonzalo Vega',
      outlet: 'Cine de Acción',
      score: 87,
      summary: 'Rápida, directa y físicamente agotadora en el mejor de los sentidos.',
      date: '30 de Julio, 2025'
    },
    technicalDetails: {
      resolution: 'Full HD 1080p',
      hdrFormat: 'HDR10',
      audioTrack: 'Dolby Digital Plus 5.1',
      aspectRatio: '2.39:1',
      director: 'Gonzalo López-Gallego',
      audioLanguages: ['Español (Latino) [Original]'],
      subtitles: ['Español', 'Inglés'],
      ageRatingDescription: 'Tensión submarina, lenguaje fuerte.'
    }
  },
  {
    id: 'abismo-profundo',
    title: 'Abismo Profundo',
    type: 'movie',
    year: 2024,
    ageRating: '13+',
    durationOrSeasons: '1 h 50 min',
    genres: ['Documental', 'Naturaleza'],
    isOriginal: false,
    isTrending: false,
    matchScore: 94,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'Una expedición de cuatro años a las fosas abisales revela especies bioluminiscentes nunca antes filmadas en ultra alta resolución.',
    whyWatch: 'Imágenes asombrosas que parecen de otro planeta narradas con rigor científico.',
    ratingAverage: 9.3,
    releaseDateISO: '2024-03-15',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c18', name: 'Dra. Sylvia Earle', character: 'Narración y Liderazgo', avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Marta Rangel',
      outlet: 'DocuWorld Magazine',
      score: 95,
      summary: 'Un hito técnico en la filmación submarina de grandes profundidades.',
      date: '20 de Marzo, 2024'
    },
    technicalDetails: {
      resolution: '4K Ultra HD Nativo',
      hdrFormat: 'HDR10+ / Dolby Vision',
      audioTrack: 'Dolby Atmos',
      aspectRatio: '1.78:1',
      director: 'James Cameron & Alastair Fothergill',
      audioLanguages: ['Español (Neutro)', 'Inglés [Original]'],
      subtitles: ['Español [CC]', 'Inglés [CC]'],
      ageRatingDescription: 'Apto para todo público / Recomendado 13+.'
    }
  },
  {
    id: 'desierto-de-fuego',
    title: 'Desierto de Fuego',
    type: 'movie',
    year: 2025,
    ageRating: '16+',
    durationOrSeasons: '2 h 05 min',
    genres: ['Acción', 'Aventura', 'Suspenso'],
    isOriginal: false,
    isTrending: false,
    matchScore: 88,
    qualityBadges: ['4K UHD', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=1600&auto=format&fit=crop',
    synopsis: 'Una caravana de científicos y guías locales atraviesa la zona más inhóspita del desierto de Atacama transportando muestras de un meteorito radiactivo.',
    whyWatch: 'Paisajes desérticos impresionantes y persecuciones en terrenos escarpados.',
    ratingAverage: 8.6,
    releaseDateISO: '2025-10-05',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c19', name: 'Benjamín Vicuña', character: 'Santiago', avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Felipe Correa',
      outlet: 'Andes Film Critics',
      score: 86,
      summary: 'Una travesía física de supervivencia con gran empaque visual.',
      date: '15 de Octubre, 2025'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10',
      audioTrack: 'Dolby Digital 5.1',
      aspectRatio: '2.39:1',
      director: 'Matías Bize',
      audioLanguages: ['Español (Latino) [Original]'],
      subtitles: ['Español', 'Inglés'],
      ageRatingDescription: 'Violencia y acción extrema en entorno hostil.'
    }
  },
  {
    id: 'guardianes-del-abismo',
    title: 'Guardianes del Abismo',
    type: 'series',
    year: 2026,
    ageRating: '16+',
    durationOrSeasons: '2 Temporadas',
    genres: ['Ciencia Ficción', 'Suspenso', 'Misterio'],
    isOriginal: true,
    isTrending: true,
    matchScore: 97,
    qualityBadges: ['4K UHD', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Un laboratorio submarino en la fosa de las Marianas pierde contacto tras detectar señales de origen biomecánico no terrestre.',
    whyWatch: 'Atmósfera claustrofóbica y diseño sonoro de referencia en Dolby Atmos.',
    ratingAverage: 9.4,
    releaseDateISO: '2026-02-10',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c20', name: 'Alba García', character: 'Dra. Karen Santos', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Lucas Varela',
      outlet: 'SciFi Pulse',
      score: 95,
      summary: 'Una de las mejores producciones de ciencia ficción acuática jamás realizadas.',
      date: '14 de Febrero, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD Master Nativo',
      hdrFormat: 'Dolby Vision',
      audioTrack: 'Dolby Atmos 7.1.4',
      aspectRatio: '2.39:1',
      director: 'Santiago Mitre',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Tensión psicológica y suspenso continuo.'
    }
  },
  {
    id: 'cronicas-de-neo-bogota',
    title: 'Crónicas de Neo-Bogotá',
    type: 'series',
    year: 2026,
    ageRating: '18+',
    durationOrSeasons: '1 Temporada',
    genres: ['Cyberpunk', 'Acción', 'Crimen'],
    isOriginal: true,
    isTrending: false,
    matchScore: 96,
    qualityBadges: ['4K UHD', 'HDR10+'],
    posterUrl: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'En el año 2088, una investigadora cibernética debe desentrañar una conspiración entre corporaciones de implantes neurales y sindicatos subterráneos.',
    whyWatch: 'Diseño de producción cyberpunk latinoamericano único con banda sonora retro-sintética.',
    ratingAverage: 9.3,
    releaseDateISO: '2026-03-01',
    isInMyList: true,
    progressPercentage: 0,
    cast: [
      { id: 'c21', name: 'Natalia Reyes', character: 'Vera Silva', avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Mario Casas',
      outlet: 'Neo Cinema Digest',
      score: 93,
      summary: 'Visualmente apabullante y con un ritmo que no concede respiro.',
      date: '5 de Marzo, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10+',
      audioTrack: 'Dolby Atmos',
      aspectRatio: '2.00:1',
      director: 'Ciro Guerra',
      audioLanguages: ['Español (Latino) [Original]'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Violencia estilizada, lenguaje adulto.'
    }
  },
  {
    id: 'el-enigma-de-los-andes',
    title: 'El Enigma de los Andes',
    type: 'movie',
    year: 2025,
    ageRating: '13+',
    durationOrSeasons: '2 h 12 min',
    genres: ['Aventura', 'Misterio', 'Drama'],
    isOriginal: true,
    isTrending: false,
    matchScore: 92,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Una expedición arqueológica en los picos más remotos de la cordillera descubre una ciudadela oculta que desafía la cronología de la civilización humana.',
    whyWatch: 'Panorámicas montañosas espectaculares en 4K HDR nativo y una trama absorbente.',
    ratingAverage: 9.1,
    releaseDateISO: '2025-12-05',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c22', name: 'Gael García Bernal', character: 'Dr. Diego Morales', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Carla Peñaloza',
      outlet: 'Geomundo Cinema',
      score: 91,
      summary: 'Una aventura cinematográfica imponente que rinde homenaje a los paisajes andinos.',
      date: '12 de Diciembre, 2025'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'Dolby Vision / HDR10+',
      audioTrack: 'Dolby Atmos',
      aspectRatio: '2.39:1 Panavision',
      director: 'Sebastián Lelio',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español [CC]', 'Inglés', 'Quechua'],
      ageRatingDescription: 'Apto para mayores de 13 años.'
    }
  },
  {
    id: 'sombra-solar',
    title: 'Sombra Solar',
    type: 'movie',
    year: 2026,
    ageRating: '16+',
    durationOrSeasons: '1 h 55 min',
    genres: ['Ciencia Ficción', 'Acción', 'Suspenso'],
    isOriginal: true,
    isTrending: true,
    matchScore: 95,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1538370965046-79c0d6907d47?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1538370965046-79c0d6907d47?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Una estación de recolección de energía heliosférica sufre un fallo en sus escudos térmicos durante la mayor eyección de masa coronal del siglo.',
    whyWatch: 'Tensión extrema en tiempo real con una cinematografía ardiente de alto contraste.',
    ratingAverage: 9.3,
    releaseDateISO: '2026-01-15',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c23', name: 'Diego Luna', character: 'Capitán Tomás Cruz', avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Hernán Silva',
      outlet: 'Solar Film Review',
      score: 94,
      summary: 'Adrenalina pura a millones de kilómetros de la Tierra.',
      date: '20 de Enero, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD 60FPS',
      hdrFormat: 'HDR10+',
      audioTrack: 'Dolby Atmos 7.1',
      aspectRatio: '2.39:1',
      director: 'Alfonso Cuarón',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español', 'Inglés'],
      ageRatingDescription: 'Suspenso espacial intenso.'
    }
  },
  {
    id: 'la-isla-de-las-luces',
    title: 'La Isla de las Luces',
    type: 'series',
    year: 2025,
    ageRating: '13+',
    durationOrSeasons: '1 Temporada',
    genres: ['Misterio', 'Drama', 'Fantasía'],
    isOriginal: true,
    isTrending: false,
    matchScore: 93,
    qualityBadges: ['4K UHD', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'En un archipiélago donde la noche dura meses, extraños fenómenos luminosos conectan los recuerdos de los habitantes con eventos futuros.',
    whyWatch: 'Poética, visualmente hechizante y con un misterio que se desvela con sutileza.',
    ratingAverage: 9.0,
    releaseDateISO: '2025-09-20',
    isInMyList: true,
    progressPercentage: 0,
    cast: [
      { id: 'c24', name: 'Paulina Gaitán', character: 'Marina', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Rosa Montero',
      outlet: 'Luz y Pantalla',
      score: 92,
      summary: 'Una joya visual que explora el tiempo, la nostalgia y la fantasía poética.',
      date: '28 de Septiembre, 2025'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10',
      audioTrack: 'Dolby Digital Plus 5.1',
      aspectRatio: '1.85:1',
      director: 'Fernando Fimbres',
      audioLanguages: ['Español (Latino) [Original]'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Apto para mayores de 13 años.'
    }
  },
  {
    id: 'frecuencia-prohibida',
    title: 'Frecuencia Prohibida',
    type: 'series',
    year: 2026,
    ageRating: '18+',
    durationOrSeasons: '2 Temporadas',
    genres: ['Suspenso', 'Terror', 'Misterio'],
    isOriginal: true,
    isTrending: true,
    matchScore: 97,
    qualityBadges: ['4K UHD', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Un locutor de radio nocturna empieza a recibir transmisiones que relatan crímenes antes de que ocurran.',
    whyWatch: 'Terror sonoro innovador y giros impredecibles en cada episodio.',
    ratingAverage: 9.5,
    releaseDateISO: '2026-03-10',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c25', name: 'Joaquín Cosío', character: 'Ramiro Valle', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Damián Rugna',
      outlet: 'Horror Latino Review',
      score: 96,
      summary: 'El nuevo estándar del horror psicológico en streaming.',
      date: '15 de Marzo, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'Dolby Vision',
      audioTrack: 'Dolby Atmos 7.1.4',
      aspectRatio: '2.39:1',
      director: 'Guillermo del Toro (Productor Ejecutivo)',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Terror psicológico intenso, violencia.'
    }
  },
  {
    id: 'reino-de-acero',
    title: 'Reino de Acero',
    type: 'series',
    year: 2025,
    ageRating: '18+',
    durationOrSeasons: '3 Temporadas',
    genres: ['Drama', 'Acción', 'Historia'],
    isOriginal: true,
    isTrending: false,
    matchScore: 94,
    qualityBadges: ['4K UHD', 'HDR10+', '5.1'],
    posterUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'La épica disputa por el control de las fundiciones y rutas ferroviarias del continente en los albores de la era industrial.',
    whyWatch: 'Recreación histórica monumental y conspiraciones políticas de alta factura.',
    ratingAverage: 9.2,
    releaseDateISO: '2025-06-18',
    isInMyList: false,
    progressPercentage: 0,
    cast: [
      { id: 'c26', name: 'Leonardo Sbaraglia', character: 'Don Augusto', avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Claudio Tolcachir',
      outlet: 'Drama & Escena',
      score: 93,
      summary: 'Una producción fastuosa con interpretaciones memorables.',
      date: '24 de Junio, 2025'
    },
    technicalDetails: {
      resolution: '4K Ultra HD',
      hdrFormat: 'HDR10+',
      audioTrack: 'Dolby Digital Plus 5.1',
      aspectRatio: '2.20:1',
      director: 'Pablo Trapero',
      audioLanguages: ['Español (Latino) [Original]'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Violencia de época, drama maduro.'
    }
  },
  {
    id: 'ultimo-vuelo-del-fénix',
    title: 'Último Vuelo del Fénix',
    type: 'movie',
    year: 2026,
    ageRating: '16+',
    durationOrSeasons: '2 h 08 min',
    genres: ['Acción', 'Aventuras', 'Suspenso'],
    isOriginal: true,
    isTrending: true,
    matchScore: 98,
    qualityBadges: ['4K UHD', 'HDR10+', 'Dolby Atmos'],
    posterUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=800&auto=format&fit=crop',
    backdropUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1600&auto=format&fit=crop',
    heroHeadline: 'HOURTV ORIGINAL',
    synopsis: 'Un escuadrón de pilotos acrobáticos de élite debe interceptar una flota de drones renegados sobre el estrecho de Magallanes.',
    whyWatch: 'Tomas aéreas reales a velocidad supersónica con cámara 4K de alta frecuencia.',
    ratingAverage: 9.6,
    releaseDateISO: '2026-04-14',
    isInMyList: true,
    progressPercentage: 0,
    cast: [
      { id: 'c27', name: 'Manolo Cardona', character: 'Comandante Ángel', avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=200&auto=format&fit=crop' }
    ],
    editorialReview: {
      author: 'Esteban Valenzuela',
      outlet: 'AeroAction Magazine',
      score: 97,
      summary: 'Acción aérea de clase mundial con sonido envolvente demoledor.',
      date: '20 de Abril, 2026'
    },
    technicalDetails: {
      resolution: '4K Ultra HD IMAX Enhanced',
      hdrFormat: 'Dolby Vision',
      audioTrack: 'Dolby Atmos 7.1.4',
      aspectRatio: '1.90:1 IMAX',
      director: 'Joseph Kosinski & Matías Lira',
      audioLanguages: ['Español (Latino) [Original]', 'Inglés'],
      subtitles: ['Español [CC]', 'Inglés'],
      ageRatingDescription: 'Acción intensa y vértigo.'
    }
  }
];

export const MOCK_TV_CHANNELS: TVChannel[] = [
  {
    id: 'ch-01-noticias24',
    channelNumber: '01',
    name: 'HourTV Noticias 24',
    category: 'noticias',
    isPopular: true,
    logoText: 'NOTICIAS 24',
    isFavorite: true,
    isLive: true,
    streamQuality: '1080p 60FPS',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-01-1',
      title: 'Edición Central: Cobertura Global y Análisis',
      startTime: '22:00',
      endTime: '23:30',
      progressPercent: 62,
      category: 'Noticiero en Vivo',
      synopsis: 'Las noticias más relevantes del plano internacional, política, avances tecnológicos y reporte bursátil en tiempo real.',
      ageRating: 'TP'
    },
    nextProgram: {
      id: 'prg-01-2',
      title: 'Economía & Mundo: Perspectiva de Mercados',
      startTime: '23:30',
      endTime: '00:30',
      progressPercent: 0,
      category: 'Análisis Económico',
      synopsis: 'Debate con economistas destacados sobre tendencias de inversión y geopolítica financiera.',
      ageRating: 'TP'
    }
  },
  {
    id: 'ch-02-cinema-premier',
    channelNumber: '02',
    name: 'Hour Cinema Premier',
    category: 'cine',
    isPopular: true,
    logoText: 'CINEMA PREMIER',
    isFavorite: true,
    isLive: true,
    streamQuality: '4K 60FPS',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-02-1',
      title: 'El último amanecer (Versión Extendida Director)',
      startTime: '21:30',
      endTime: '23:50',
      progressPercent: 48,
      category: 'Cine / Ciencia Ficción',
      synopsis: 'Emisión especial con audio Dolby Atmos sin cortes publicitarios para abonados HourTV.',
      ageRating: '16+'
    },
    nextProgram: {
      id: 'prg-02-2',
      title: 'Código Órbita (Estreno Exclusivo)',
      startTime: '23:50',
      endTime: '01:40',
      progressPercent: 0,
      category: 'Cine / Cyberpunk Acción',
      synopsis: 'Un ex-agente hackea la computadora central de una metrópolis espacial.',
      ageRating: '16+'
    }
  },
  {
    id: 'ch-03-sports-live',
    channelNumber: '03',
    name: 'Hour Sports Live',
    category: 'deportes',
    isPopular: true,
    logoText: 'SPORTS LIVE',
    isFavorite: false,
    isLive: true,
    streamQuality: '4K 60FPS',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-03-1',
      title: 'Liga de Campeones: Minuto a Minuto & Post-Partido',
      startTime: '22:15',
      endTime: '00:00',
      progressPercent: 35,
      category: 'Fútbol Internacional',
      synopsis: 'Análisis táctico con cámara multi-ángulo y estadísticas de rendimiento en vivo.',
      ageRating: 'TP'
    },
    nextProgram: {
      id: 'prg-03-2',
      title: 'Zona Motor: Resumen GP de Velocidad',
      startTime: '00:00',
      endTime: '01:00',
      progressPercent: 0,
      category: 'Automovilismo',
      synopsis: 'Las mejores maniobras y paradas en boxes del campeonato mundial.',
      ageRating: 'TP'
    }
  },
  {
    id: 'ch-04-kids',
    channelNumber: '04',
    name: 'Hour Kids',
    category: 'infantil',
    logoText: 'HOUR KIDS',
    isFavorite: true,
    isLive: true,
    streamQuality: '1080p 60FPS',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-04-1',
      title: 'Club Aventuras: El océano increíble',
      startTime: '22:00',
      endTime: '23:15',
      progressPercent: 75,
      category: 'Infantil educativo',
      synopsis: 'Una expedición animada descubre los secretos del océano con juegos y aprendizaje.',
      ageRating: 'TP'
    },
    nextProgram: {
      id: 'prg-04-2',
      title: 'Hora de cuentos: El bosque de colores',
      startTime: '23:15',
      endTime: '00:15',
      progressPercent: 0,
      category: 'Fauna & Ecosistemas',
      synopsis: 'Los lobos árticos y manadas de renos en su migración anual bajo la aurora boreal.',
      ageRating: 'TP'
    }
  },
  {
    id: 'ch-05-series-max',
    channelNumber: '05',
    name: 'Hour Series Max',
    category: 'series',
    isPopular: true,
    logoText: 'SERIES MAX',
    isFavorite: false,
    isLive: true,
    streamQuality: '1080p',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-05-1',
      title: 'Frontera Roja • T2:E4 "Punto de Inflexión"',
      startTime: '22:30',
      endTime: '23:25',
      progressPercent: 50,
      category: 'Serie Dramática',
      synopsis: 'Una llamada interceptada pone al descubierto el escondite del comandante Barba.',
      ageRating: '18+'
    },
    nextProgram: {
      id: 'prg-05-2',
      title: 'Silencio en el bosque • T1:E1 "Niebla en la cumbre"',
      startTime: '23:25',
      endTime: '00:15',
      progressPercent: 0,
      category: 'Serie Suspenso',
      synopsis: 'El hallazgo de un todoterreno en una reserva protegida inicia una investigación perturbadora.',
      ageRating: '16+'
    }
  },
  {
    id: 'ch-06-novelas',
    channelNumber: '06',
    name: 'Hour Novelas',
    category: 'novelas',
    logoText: 'HOUR NOVELAS',
    isFavorite: false,
    isLive: true,
    streamQuality: '1080p',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-06-1',
      title: 'Destino Cruzado • Capítulo 48',
      startTime: '22:00',
      endTime: '00:00',
      progressPercent: 40,
      category: 'Novela dramática',
      synopsis: 'Valeria descubre la carta que puede cambiar para siempre el destino de dos familias.',
      ageRating: 'TP'
    },
    nextProgram: {
      id: 'prg-06-2',
      title: 'Corazones de frontera • Capítulo 12',
      startTime: '00:00',
      endTime: '01:30',
      progressPercent: 0,
      category: 'Concierto Acústico',
      synopsis: 'Artistas emergentes interpretan versiones íntimas de sus mayores éxitos.',
      ageRating: 'TP'
    }
  },
  {
    id: 'ch-07-fe-vida',
    channelNumber: '07',
    name: 'Hour Fe y Vida',
    category: 'religioso',
    logoText: 'FE Y VIDA',
    isFavorite: false,
    isLive: true,
    streamQuality: '1080p',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1438232992991-995b7058bbb3?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-07-1',
      title: 'Reflexiones para un nuevo día',
      startTime: '22:00',
      endTime: '23:00',
      progressPercent: 52,
      category: 'Espiritualidad',
      synopsis: 'Conversaciones sobre comunidad, esperanza y bienestar familiar.',
      ageRating: 'TP'
    },
    nextProgram: {
      id: 'prg-07-2',
      title: 'Música y encuentro',
      startTime: '23:00',
      endTime: '00:00',
      progressPercent: 0,
      category: 'Música espiritual',
      synopsis: 'Presentaciones musicales y mensajes para toda la familia.',
      ageRating: 'TP'
    }
  },
  {
    id: 'ch-18-after-dark',
    channelNumber: '18',
    name: 'Hour After Dark',
    category: 'adulto',
    logoText: 'AFTER DARK',
    isFavorite: false,
    isLive: true,
    streamQuality: '1080p',
    streamPreviewUrl: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?q=80&w=1000&auto=format&fit=crop',
    currentProgram: {
      id: 'prg-18-1',
      title: 'Cine nocturno',
      startTime: '22:30',
      endTime: '00:20',
      progressPercent: 38,
      category: 'Contenido para adultos',
      synopsis: 'Programación protegida disponible únicamente con autorización parental.',
      ageRating: '18+'
    },
    nextProgram: {
      id: 'prg-18-2',
      title: 'Selección de medianoche',
      startTime: '00:20',
      endTime: '02:00',
      progressPercent: 0,
      category: 'Contenido para adultos',
      synopsis: 'Selección nocturna protegida mediante Control parental.',
      ageRating: '18+'
    }
  }
];

export const GENRE_CATEGORIES = [
  'Todos',
  'Originals',
  'Películas',
  'Series',
  'Tendencias',
  'Acción',
  'Ciencia Ficción',
  'Drama',
  'Suspenso',
  'Crimen',
  'Terror',
  'Documental',
  '4K UHD'
];

export const RECENT_SEARCHES = [
  'El último amanecer',
  'Frontera Roja temporada 3',
  'Ciencia ficción 4K',
  'Películas de suspenso',
  'Gabriel Sotomayor director'
];

export const TRENDING_KEYWORDS = [
  'Código Órbita',
  'Sombras de hielo',
  'HourTV Originals',
  'Dolby Atmos',
  'Frontera Roja T3',
  'Nuevos estrenos 2026'
];


