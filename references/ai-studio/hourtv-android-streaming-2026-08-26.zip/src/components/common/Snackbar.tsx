import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { SnackbarState } from '../../types';

interface SnackbarProps {
  snackbar: SnackbarState | null;
  onDismiss: () => void;
}

export const Snackbar: React.FC<SnackbarProps> = ({ snackbar, onDismiss }) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!snackbar) return;
    const timer = setTimeout(() => {
      onDismiss();
    }, 4000);
    return () => clearTimeout(timer);
  }, [snackbar, onDismiss]);

  if (!snackbar || !mounted) return null;

  const icons = {
    success: <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-[#00C781] flex-shrink-0" />,
    warning: <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-[#FBBF24] flex-shrink-0" />,
    info: <Info className="w-4 h-4 sm:w-5 sm:h-5 text-[#38BDF8] flex-shrink-0" />
  };

  const type = snackbar.type || 'success';

  const snackbarContent = (
    <aside
      className="pointer-events-auto absolute bottom-[calc(4.25rem+env(safe-area-inset-bottom,0px))] sm:bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] left-4 right-4 z-[80] flex items-center justify-between gap-2.5 px-3.5 py-2.5 bg-[#151917]/95 backdrop-blur-md text-[#F5F5F5] border border-[#27302C] rounded-xl shadow-[0_10px_28px_rgba(0,0,0,0.85),0_0_0_1px_rgba(0,199,129,0.1)] animate-snackbar-in select-none"
      role="status"
      aria-live="polite"
      aria-atomic="true"
    >
      <div className="flex items-center gap-2.5 min-w-0 flex-1">
        {icons[type]}
        <span className="text-xs sm:text-sm font-medium leading-snug truncate text-[#F5F5F5]">
          {snackbar.message}
        </span>
      </div>

      <div className="flex items-center gap-1 flex-shrink-0">
        {snackbar.actionLabel && snackbar.onAction && (
          <button
            type="button"
            onClick={() => {
              snackbar.onAction?.();
              onDismiss();
            }}
            className="min-h-[44px] px-2.5 py-1 text-xs sm:text-sm font-bold text-[#00C781] hover:text-[#00E595] hover:bg-[#00C781]/10 rounded-lg transition-colors active:scale-95 flex items-center justify-center focus:outline-none focus-visible:ring-1 focus-visible:ring-[#00C781]"
          >
            {snackbar.actionLabel}
          </button>
        )}
        <button
          type="button"
          onClick={onDismiss}
          className="min-w-[44px] min-h-[44px] -mr-1.5 flex items-center justify-center rounded-lg text-[#A8ADAB] hover:text-[#F5F5F5] hover:bg-[#27302C]/60 active:scale-90 transition-all focus:outline-none focus-visible:ring-1 focus-visible:ring-[#00C781]"
          aria-label="Cerrar notificación"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );

  const portalRoot = document.getElementById('android-snackbar-portal-root');
  if (portalRoot) {
    return createPortal(snackbarContent, portalRoot);
  }

  return createPortal(snackbarContent, document.body);
};

