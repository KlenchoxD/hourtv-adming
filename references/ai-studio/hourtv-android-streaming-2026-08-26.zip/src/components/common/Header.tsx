import React from 'react';
import { Cast, WifiOff } from 'lucide-react';
import { HourTVLogo } from './HourTVLogo';
import { RouteId, UserProfile } from '../../types';
import { ProfileAvatar } from '../../../ProfileAvatar';

interface HeaderProps {
  currentRoute: RouteId;
  onNavigate: (route: RouteId) => void;
  userProfile: UserProfile;
  isOffline?: boolean;
  onOpenCastModal?: () => void;
  onOpenProfileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRoute,
  onNavigate,
  userProfile,
  isOffline = false,
  onOpenCastModal,
  onOpenProfileMenu
}) => {
  return (
    <header className="sticky top-0 z-30 w-full bg-[#080A09]/90 backdrop-blur-md border-b border-[#27302C]/60 px-5 py-2.5 flex items-center justify-between transition-colors">
      {/* Brand Logo & Tap to Home */}
      <button
        type="button"
        onClick={() => onNavigate('home')}
        className="flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]/30 rounded-lg p-1 -ml-1 transition-transform active:scale-95"
        aria-label="Ir a Inicio HourTV"
      >
        <HourTVLogo size="sm" />
      </button>

      {/* Action Controls (Cast y Perfil) */}
      <div className="flex items-center gap-2">
        {/* Offline Badge if active */}
        {isOffline && (
          <div className="inline-flex items-center gap-1.5 bg-[#27302C] text-[#F5F5F5] px-2.5 py-1 rounded-full text-xs font-semibold border border-[#38443F]">
            <WifiOff className="w-3.5 h-3.5 text-[#00C781]" />
            <span className="hidden xs:inline text-[11px]">Sin Conexión</span>
          </div>
        )}

        {/* Cast Screen Button — only in live TV */}
        {currentRoute === 'live_tv' && (
          <button
            type="button"
            onClick={onOpenCastModal}
            className="w-10 h-10 min-w-[40px] flex items-center justify-center rounded-full text-[#C4C8C6] hover:text-[#F5F5F5] hover:bg-[#151917] active:bg-[#101412] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]/40"
            aria-label="Transmitir a dispositivo Chromecast o Android TV"
          >
            <Cast className="w-5 h-5" />
          </button>
        )}

        {/* User Profile Avatar */}
        <button
          type="button"
          onClick={onOpenProfileMenu || (() => onNavigate('profile'))}
          className="relative w-10 h-10 min-w-[40px] rounded-2xl transition-transform active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781] ml-1 flex items-center justify-center"
          aria-label={`Perfil de ${userProfile.name}`}
        >
          <ProfileAvatar
            avatarId={userProfile.avatarId}
            name={userProfile.name}
            size={36}
            className="rounded-xl"
          />
        </button>
      </div>
    </header>
  );
};