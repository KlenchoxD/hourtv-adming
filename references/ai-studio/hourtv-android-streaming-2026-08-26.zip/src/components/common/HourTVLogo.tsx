import React from 'react';

interface HourTVLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showTagline?: boolean;
}

export const HourTVLogo: React.FC<HourTVLogoProps> = ({
  size = 'md',
  className = '',
  showTagline = false
}) => {
  const sizeClasses = {
    sm: 'text-[22px]',
    md: 'text-[28px]',
    lg: 'text-[40px]',
    xl: 'text-[56px]'
  };

  return (
    <div className={['inline-flex flex-col items-center select-none', className].join(' ')}>
      <span
        aria-label="HourTV"
        className={[sizeClasses[size], 'inline-flex items-baseline whitespace-nowrap font-extrabold leading-none tracking-[-0.045em]'].join(' ')}
      >
        <span className="text-[#F5F5F5]">Hour</span>
        <span className="text-[#00C781]">TV</span>
      </span>

      {showTagline && (
        <span className="mt-1 text-[10px] font-semibold uppercase tracking-widest text-[#A8ADAB]">
          Streaming Premium
        </span>
      )}
    </div>
  );
};
