import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

interface ModalSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  maxHeight?: string;
}

export const ModalSheet: React.FC<ModalSheetProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  maxHeight = 'max-h-[calc(100%-20px)] sm:max-h-[calc(100%-28px)]'
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Lock background scroll when modal is open and restore on close/unmount
  useEffect(() => {
    if (!isOpen) return;

    const scrollContainer = document.getElementById('android-scroll-container');
    const prevScrollContainerOverflow = scrollContainer ? scrollContainer.style.overflowY : '';
    const prevBodyOverflow = document.body.style.overflow;

    if (scrollContainer) {
      scrollContainer.style.overflowY = 'hidden';
    }
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      if (scrollContainer) {
        scrollContainer.style.overflowY = prevScrollContainerOverflow;
      }
      document.body.style.overflow = prevBodyOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen || !mounted) return null;

  const modalNode = (
    <div
      className="absolute inset-0 z-[100] flex items-end justify-center pointer-events-auto overflow-hidden"
      role="presentation"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm animate-backdrop-in"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Sheet Container */}
      <section
        className={`relative z-10 w-full ${maxHeight} bg-[#101412] border-t border-[#27302C] rounded-t-2xl sm:rounded-t-3xl shadow-[0_-12px_40px_rgba(0,0,0,0.85)] flex flex-col overflow-hidden animate-sheet-up pb-[max(0.875rem,env(safe-area-inset-bottom,0px))]`}
        role="dialog"
        aria-modal="true"
        aria-label={title || 'Ventana emergente'}
      >
        {/* Drag Handle Bar */}
        <div className="w-full flex items-center justify-center pt-3 pb-1 cursor-grab flex-shrink-0">
          <div className="w-10 h-1.5 rounded-full bg-[#27302C]" />
        </div>

        {/* Header if title or subtitle exists */}
        {(title || subtitle) && (
          <div className="flex items-center justify-between px-5 py-3 border-b border-[#27302C]/60 flex-shrink-0">
            <div className="min-w-0 pr-3">
              {title && <h3 className="text-sm sm:text-base font-bold text-[#F5F5F5] truncate">{title}</h3>}
              {subtitle && <p className="text-[11px] text-[#A8ADAB] mt-0.5 line-clamp-1">{subtitle}</p>}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#151917] border border-[#27302C] text-[#A8ADAB] hover:text-[#F5F5F5] flex items-center justify-center transition-all duration-120 active:scale-95 flex-shrink-0"
              aria-label="Cerrar modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Sheet Body with custom scrollbar */}
        <div className="px-5 py-3.5 overflow-y-auto custom-scrollbar flex-1 min-h-0">
          {children}
        </div>
      </section>
    </div>
  );

  const portalTarget = document.getElementById('android-modal-portal-root');
  if (portalTarget) {
    return createPortal(modalNode, portalTarget);
  }

  return createPortal(modalNode, document.body);
};


