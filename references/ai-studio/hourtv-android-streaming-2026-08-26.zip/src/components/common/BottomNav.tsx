import React from 'react';
import { Home, Tv, Search, Bookmark, User } from 'lucide-react';
import { RouteId } from '../../types';

interface BottomNavProps {
  currentRoute: RouteId;
  onNavigate: (route: RouteId) => void;
  hasPendingUpdate?: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentRoute, onNavigate, hasPendingUpdate = false }) => {
  const navItems = [
    {
      id: 'home' as RouteId,
      label: 'Inicio',
      icon: Home
    },
    {
      id: 'live_tv' as RouteId,
      label: 'TV',
      icon: Tv
    },
    {
      id: 'search' as RouteId,
      label: 'Buscar',
      icon: Search
    },
    {
      id: 'library' as RouteId,
      label: 'Mi Biblioteca',
      icon: Bookmark
    },
    {
      id: 'profile' as RouteId,
      label: 'Perfil',
      icon: User
    }
  ];

  return (
    <nav
      className="absolute bottom-0 left-0 right-0 z-40 bg-[#080A09]/95 backdrop-blur-md px-2 pt-1.5 pb-[max(0.375rem,env(safe-area-inset-bottom,0px))] border-t border-[#27302C]/50 transition-colors"
      role="navigation"
      aria-label="Navegación principal Android"
    >
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const isActive =
            currentRoute === item.id ||
            (item.id === 'home' && (currentRoute === 'movies' || currentRoute === 'series' || currentRoute === 'originals'));
          const IconComponent = item.icon;

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`flex-1 min-h-[52px] flex flex-col items-center justify-center gap-1 relative px-1 py-1 rounded-xl transition-all duration-180 active:scale-95 focus:outline-none focus-visible:ring-1 focus-visible:ring-[#00C781]/40 ${
                isActive ? 'text-[#00C781]' : 'text-[#A8ADAB] hover:text-[#F5F5F5]'
              }`}
              aria-current={isActive ? 'page' : undefined}
            >
              <div className="relative flex items-center justify-center">
                <IconComponent
                  className={`w-5 h-5 transition-all duration-180 ease-out ${
                    isActive ? 'scale-110 -translate-y-0.5 stroke-[2.4]' : 'scale-100 translate-y-0 stroke-[1.8]'
                  }`}
                />
                {item.id === 'profile' && hasPendingUpdate && (
                  <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#00C781] ring-2 ring-[#080A09]" />
                )}
              </div>
              <span
                className={`text-[11px] tracking-tight leading-none transition-colors duration-180 ${
                  isActive ? 'font-bold text-[#F5F5F5]' : 'font-normal text-[#A8ADAB]'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

