import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, SignalHigh } from 'lucide-react';
import { ViewportOption } from '../../types';

interface AndroidFrameProps {
  viewport: ViewportOption;
  children: React.ReactNode;
  isLandscape?: boolean;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ viewport, children, isLandscape = false }) => {
  const [currentTime, setCurrentTime] = useState('22:54');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const isFluid = viewport.width === 0;

  if (isFluid) {
    return (
      <div
        id="android-device-screen"
        className={`w-full min-h-screen bg-[#080A09] text-[#F5F5F5] flex flex-col relative ${isLandscape ? 'overflow-hidden h-screen' : 'overflow-x-hidden'}`}
      >
        {/* Status Bar */}
        {!isLandscape && (
          <div className="w-full bg-[#080A09] px-4 py-1.5 flex items-center justify-between text-xs text-[#C4C8C6] z-30 select-none border-b border-[#27302C]/30 flex-shrink-0">
            <span className="font-semibold text-white font-mono">{currentTime}</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-[#00C781] bg-[#00C781]/15 px-1 rounded">5G</span>
              <SignalHigh className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px] font-mono">98%</span>
                <BatteryMedium className="w-4 h-4 text-[#00C781]" />
              </div>
            </div>
          </div>
        )}

        {/* App Scrollable Content Area */}
        <div
          id="android-scroll-container"
          className="flex-1 flex flex-col w-full h-full overflow-y-auto custom-scrollbar relative"
        >
          {children}
        </div>

        {/* Global Snackbar Toast Portal Container (below modals, above content/nav) */}
        <div id="android-snackbar-portal-root" className="pointer-events-none absolute inset-0 z-[80] overflow-hidden" />

        {/* Global Modal & Overlay Portal Container */}
        <div id="android-modal-portal-root" className="pointer-events-none absolute inset-0 z-[100] overflow-hidden" />
      </div>
    );
  }

  const effectiveWidth = isLandscape
    ? Math.max(viewport.height, viewport.width)
    : viewport.width;
  const effectiveHeight = isLandscape
    ? Math.min(viewport.height, viewport.width)
    : viewport.height;

  return (
    <div className="w-full flex-1 flex items-center justify-center p-2 sm:p-6 bg-[#050505] overflow-y-auto min-h-[calc(100vh-50px)]">
      {/* Device Bezel Shell */}
      <div
        id="android-device-screen"
        className={`relative bg-[#080A09] border-[6px] border-[#27302C] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_0_1px_rgba(0,199,129,0.12)] overflow-hidden flex flex-col transition-all duration-300 max-w-full ${
          isLandscape ? 'rounded-[36px]' : 'rounded-[44px]'
        }`}
        style={{
          width: `${effectiveWidth}px`,
          height: `${effectiveHeight}px`,
          maxWidth: '96vw',
          maxHeight: '92vh',
          aspectRatio: isLandscape ? `${effectiveWidth} / ${effectiveHeight}` : undefined
        }}
      >
        {/* Android Camera Punch Hole */}
        {isLandscape ? (
          <div className="absolute left-2.5 top-0 bottom-0 z-40 flex items-center justify-center pointer-events-none">
            <div className="w-3.5 h-3.5 rounded-full bg-[#050505] border border-[#27302C]/80 ring-1 ring-black/80" />
          </div>
        ) : (
          <div className="absolute top-2 left-0 right-0 z-40 flex items-center justify-center pointer-events-none">
            <div className="w-3.5 h-3.5 rounded-full bg-[#050505] border border-[#27302C]/80 ring-1 ring-black/80" />
          </div>
        )}

        {/* Android Status Bar */}
        {!isLandscape && (
          <div className="w-full bg-[#080A09]/95 px-6 pt-3 pb-1 flex items-center justify-between text-xs text-[#C4C8C6] z-30 select-none flex-shrink-0">
            <span className="font-semibold text-white font-mono text-[13px]">{currentTime}</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-bold text-[#00C781] bg-[#00C781]/15 px-1 py-0.2 rounded">5G</span>
              <SignalHigh className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-mono">98%</span>
                <BatteryMedium className="w-4 h-4 text-[#00C781]" />
              </div>
            </div>
          </div>
        )}

        {/* App Scrollable Content Area */}
        <div
          id="android-scroll-container"
          className={`flex-1 overflow-y-auto custom-scrollbar flex flex-col bg-[#080A09] relative ${isLandscape ? 'overflow-hidden h-full' : ''}`}
        >
          {children}
        </div>

        {/* Global Snackbar Toast Portal Container (below modals, above content/nav) */}
        <div id="android-snackbar-portal-root" className="pointer-events-none absolute inset-0 z-[80] overflow-hidden" />

        {/* Global Modal & Overlay Portal Container */}
        <div id="android-modal-portal-root" className="pointer-events-none absolute inset-0 z-[100] overflow-hidden" />
      </div>
    </div>
  );
};
