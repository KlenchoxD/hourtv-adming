import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { WifiOff, AlertTriangle, RefreshCw, Lock, Film, Sparkles } from 'lucide-react';
import { PrimaryButton, SecondaryButton } from './Buttons';
import { HourTVLogo } from './HourTVLogo';

export const InitialLoadingState: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] px-6 text-center select-none">
      <div className="relative mb-6">
        <HourTVLogo size="lg" showTagline />
        <div className="absolute -inset-4 rounded-full bg-[#00C781]/15 blur-2xl -z-10 animate-pulse" />
      </div>

      <div className="w-48 h-1.5 bg-[#151917] rounded-full overflow-hidden mb-4 border border-[#27302C]">
        <div className="h-full bg-[#00C781] rounded-full skeleton-shimmer w-full animate-pulse" />
      </div>

      <h3 className="text-base font-bold text-[#F5F5F5] mb-1">Preparando HourTV</h3>
      <p className="text-xs text-[#A8ADAB] max-w-xs">
        Cargando catálogo en 4K UHD, recomendaciones personalizadas y transmisiones en vivo...
      </p>
    </div>
  );
};

export const SkeletonHero: React.FC = () => {
  return (
    <div className="relative aspect-[4/5] w-full rounded-2xl overflow-hidden skeleton-shimmer border border-[#27302C]/60 mb-6">
      <div className="absolute inset-0 bg-gradient-to-t from-[#080A09] via-[#080A09]/40 to-transparent flex flex-col justify-end p-5">
        <div className="w-24 h-4 rounded bg-[#27302C] mb-2 animate-pulse" />
        <div className="w-3/4 h-8 rounded-lg bg-[#27302C] mb-3 animate-pulse" />
        <div className="w-1/2 h-4 rounded bg-[#27302C] mb-4 animate-pulse" />
        <div className="flex gap-3">
          <div className="w-32 h-12 rounded-xl bg-[#27302C] animate-pulse" />
          <div className="w-28 h-12 rounded-xl bg-[#27302C] animate-pulse" />
        </div>
      </div>
    </div>
  );
};

export const SkeletonCarousel: React.FC<{ count?: number }> = ({ count = 3 }) => {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between px-4 mb-3">
        <div className="w-36 h-5 rounded bg-[#151917] skeleton-shimmer" />
        <div className="w-12 h-4 rounded bg-[#151917] skeleton-shimmer" />
      </div>
      <div className="flex gap-3 px-4 overflow-hidden">
        {Array.from({ length: count }).map((_, i) => (
          <div
            key={i}
            className="w-[135px] min-w-[135px] aspect-[2/3] rounded-xl skeleton-shimmer border border-[#27302C]/40"
          />
        ))}
      </div>
    </div>
  );
};

interface ErrorViewProps {
  title?: string;
  message?: string;
  onRetry: () => void;
  isLoading?: boolean;
}

export const ErrorView: React.FC<ErrorViewProps> = ({
  title = 'No pudimos cargar el contenido',
  message = 'Hubo un inconveniente al conectar con los servidores de HourTV. Comprueba tu conexión o inténtalo de nuevo.',
  onRetry,
  isLoading = false
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[50vh] bg-[#101412]/60 border border-[#27302C] rounded-2xl mx-4 my-6">
      <div className="w-16 h-16 rounded-full bg-[#151917] border border-[#27302C] flex items-center justify-center text-[#FBBF24] mb-4">
        <AlertTriangle className="w-8 h-8 stroke-[1.8]" />
      </div>

      <h3 className="text-lg font-bold text-[#F5F5F5] mb-2">{title}</h3>
      <p className="text-sm text-[#A8ADAB] max-w-sm mb-6 leading-relaxed">{message}</p>

      <PrimaryButton
        onClick={onRetry}
        isLoading={isLoading}
        icon={<RefreshCw className="w-4 h-4" />}
      >
        Reintentar conexión
      </PrimaryButton>
    </div>
  );
};

interface OfflineViewProps {
  onRetry: () => void;
  onGoToLibrary?: () => void;
}

export const OfflineView: React.FC<OfflineViewProps> = ({ onRetry, onGoToLibrary }) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[60vh] bg-[#101412]/80 border border-[#27302C] rounded-2xl mx-4 my-6">
      <div className="w-16 h-16 rounded-full bg-[#151917] border border-[#27302C] flex items-center justify-center text-[#A8ADAB] mb-4">
        <WifiOff className="w-8 h-8" />
      </div>

      <h3 className="text-lg font-bold text-[#F5F5F5] mb-2">Sin conexión a Internet</h3>
      <p className="text-sm text-[#A8ADAB] max-w-sm mb-6 leading-relaxed">
        No se detecta señal de red. Puedes consultar tu lista de contenido guardado en Mi Biblioteca o reintentar la conexión.
      </p>

      <div className="flex flex-col w-full max-w-xs gap-3">
        {onGoToLibrary && (
          <PrimaryButton onClick={onGoToLibrary} icon={<Film className="w-4 h-4" />}>
            Ir a Mi Biblioteca
          </PrimaryButton>
        )}
        <SecondaryButton onClick={onRetry} icon={<RefreshCw className="w-4 h-4" />}>
          Reintentar reconexión
        </SecondaryButton>
      </div>
    </div>
  );
};

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center min-h-[45vh] bg-[#101412]/50 border border-[#27302C]/60 rounded-2xl mx-4 my-4">
      <div className="w-14 h-14 rounded-full bg-[#151917] border border-[#27302C] flex items-center justify-center text-[#00C781] mb-4">
        {icon || <Sparkles className="w-7 h-7" />}
      </div>

      <h3 className="text-base font-bold text-[#F5F5F5] mb-1.5">{title}</h3>
      <p className="text-xs sm:text-sm text-[#A8ADAB] max-w-xs mb-5 leading-relaxed">
        {description}
      </p>

      {actionLabel && onAction && (
        <PrimaryButton size="sm" onClick={onAction}>
          {actionLabel}
        </PrimaryButton>
      )}
    </div>
  );
};

interface ParentalPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  correctPin?: string;
  titleName?: string;
}

export const ParentalPinModal: React.FC<ParentalPinModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  correctPin = '1234',
  titleName = 'Contenido Restringido (+18)'
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const next = pin + digit;
      setPin(next);
      setError(false);
      if (next.length === 4) {
        if (next === correctPin) {
          setTimeout(() => {
            onSuccess();
            setPin('');
          }, 200);
        } else {
          setError(true);
          setTimeout(() => {
            setPin('');
          }, 800);
        }
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  if (!mounted) return null;

  const modalContent = (
    <div className="absolute inset-0 z-[100] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md pointer-events-auto overflow-y-auto custom-scrollbar">
      <div className="w-full max-w-xs sm:max-w-sm bg-[#101412] border border-[#27302C] rounded-2xl p-6 shadow-2xl flex flex-col items-center text-center my-auto">
        <div className="w-12 h-12 rounded-full bg-[#151917] border border-[#27302C] flex items-center justify-center text-[#00C781] mb-3">
          <Lock className="w-6 h-6" />
        </div>

        <h3 className="text-lg font-bold text-[#F5F5F5] mb-1">Control Parental</h3>
        <p className="text-xs text-[#A8ADAB] mb-4">
          Introduce tu PIN de 4 dígitos para acceder a <span className="text-[#F5F5F5] font-semibold">{titleName}</span>
        </p>

        {/* PIN Indicators */}
        <div className="flex justify-center gap-3 my-3">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-150 ${
                  error
                    ? 'bg-[#EF4444] scale-110'
                    : isFilled
                    ? 'bg-[#00C781] scale-110'
                    : 'bg-[#27302C]'
                }`}
              />
            );
          })}
        </div>

        {error && (
          <p className="text-xs text-[#EF4444] font-medium mb-2 animate-bounce">
            PIN incorrecto. Vuelve a intentarlo. (PIN demo: {correctPin})
          </p>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[260px] my-3">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => {
            const isAction = k === 'C' || k === '⌫';
            return (
              <button
                key={k}
                type="button"
                onClick={() => {
                  if (k === 'C') setPin('');
                  else if (k === '⌫') handleDelete();
                  else handleDigit(k);
                }}
                className={`h-12 rounded-xl flex items-center justify-center text-lg font-semibold transition-all active:scale-90 border ${
                  isAction
                    ? 'bg-[#151917] text-[#A8ADAB] border-[#27302C]'
                    : 'bg-[#151917] text-[#F5F5F5] border-[#27302C] hover:border-[#00C781]/60 active:bg-[#00C781]/20'
                }`}
              >
                {k}
              </button>
            );
          })}
        </div>

        <div className="w-full mt-4">
          <SecondaryButton fullWidth size="sm" onClick={onClose}>
            Cancelar
          </SecondaryButton>
        </div>
      </div>
    </div>
  );

  const portalRoot = document.getElementById('android-modal-portal-root');
  if (portalRoot) {
    return createPortal(modalContent, portalRoot);
  }

  return createPortal(modalContent, document.body);
};
