import React from 'react';
import {
  Smartphone,
  Layers,
  Sparkles,
  WifiOff,
  AlertTriangle,
  RotateCcw,
  Sliders,
  Tv,
  Film,
  Search,
  Bookmark,
  User,
  PlayCircle,
  Key,
  X,
  Radio,
  EyeOff
} from 'lucide-react';
import { RouteId, ViewportOption } from '../../types';

export const VIEWPORT_OPTIONS: ViewportOption[] = [
  { id: 'pixel8', name: 'Google Pixel 8', width: 412, height: 915, deviceLabel: '412 × 915 px (Referencia Principal)' },
  { id: 'galaxy', name: 'Samsung Galaxy S24', width: 390, height: 844, deviceLabel: '390 × 844 px' },
  { id: 'compact', name: 'Android Compacto', width: 360, height: 800, deviceLabel: '360 × 800 px' },
  { id: 'large', name: 'Android Pro Max', width: 480, height: 960, deviceLabel: '480 × 960 px' },
  { id: 'fluid', name: 'Viewport Fluido', width: 0, height: 0, deviceLabel: '100% Pantalla Fluida' }
];

interface ReviewInspectorProps {
  currentRoute: RouteId;
  onSelectRoute: (route: RouteId) => void;
  selectedViewport: ViewportOption;
  onSelectViewport: (vp: ViewportOption) => void;
  isSimulatedOffline: boolean;
  onToggleOffline: () => void;
  isSimulatedLoading: boolean;
  onToggleLoading: () => void;
  isSimulatedError: boolean;
  onToggleError: () => void;
  isEmptyLibrary: boolean;
  onToggleEmptyLibrary: () => void;
  isParentalRestricted: boolean;
  onToggleParental: () => void;
  onResetDemoData: () => void;
  onCloseQaMode: () => void;
}

export const ReviewInspector: React.FC<ReviewInspectorProps> = ({
  currentRoute,
  onSelectRoute,
  selectedViewport,
  onSelectViewport,
  isSimulatedOffline,
  onToggleOffline,
  isSimulatedLoading,
  onToggleLoading,
  isSimulatedError,
  onToggleError,
  isEmptyLibrary,
  onToggleEmptyLibrary,
  isParentalRestricted,
  onToggleParental,
  onResetDemoData,
  onCloseQaMode
}) => {
  const routes: { id: RouteId; label: string; icon: React.ReactNode; group: string }[] = [
    { id: 'home', label: 'Inicio', icon: <Sparkles className="w-3.5 h-3.5" />, group: '3. Inicio' },
    { id: 'originals', label: 'Originals', icon: <Sparkles className="w-3.5 h-3.5 text-[#00C781]" />, group: '3.1 Originals' },
    { id: 'live_tv', label: 'TV en Vivo', icon: <Tv className="w-3.5 h-3.5" />, group: '7. TV' },
    { id: 'search', label: 'Buscar', icon: <Search className="w-3.5 h-3.5" />, group: '4. Buscar' },
    { id: 'details', label: 'Detalles', icon: <Film className="w-3.5 h-3.5" />, group: '5. Detalles' },
    { id: 'player', label: 'Reproductor', icon: <PlayCircle className="w-3.5 h-3.5" />, group: '9. Reproductor' },
    { id: 'library', label: 'Mi Biblioteca', icon: <Bookmark className="w-3.5 h-3.5" />, group: '6. Biblioteca' },
    { id: 'profile', label: 'Perfil', icon: <User className="w-3.5 h-3.5" />, group: '8. Perfil' },
    { id: 'access', label: 'Acceso / Login', icon: <Key className="w-3.5 h-3.5" />, group: '2. Acceso' },
    { id: 'system_states', label: 'Estados del Sistema', icon: <Layers className="w-3.5 h-3.5" />, group: '1. Estados' }
  ];

  return (
    <aside className="w-full bg-[#050505] border-b border-[#27302C] px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs select-none shadow-md z-50">
      {/* Brand & Mode Tag */}
      <div className="flex items-center gap-2.5">
        <div className="flex items-center gap-1.5 bg-[#101412] px-2.5 py-1 rounded-lg border border-[#27302C]">
          <span className="w-2 h-2 rounded-full bg-[#00C781] animate-pulse" />
          <span className="font-bold text-white tracking-tight">HourTV QA Inspector</span>
          <span className="bg-[#00C781]/15 text-[#00C781] text-[10px] font-mono px-1.5 py-0.5 rounded font-bold">
            MODO QA ACTIVO
          </span>
        </div>
      </div>

      {/* Routes Switcher Bar */}
      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5 max-w-2xl">
        <span className="text-[#A8ADAB] font-semibold text-[11px] mr-1 hidden lg:inline">Rutas:</span>
        {routes.map((r) => {
          const isActive = currentRoute === r.id;
          return (
            <button
              key={r.id}
              type="button"
              onClick={() => onSelectRoute(r.id)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all duration-150 whitespace-nowrap active:scale-95 ${
                isActive
                  ? 'bg-[#00C781] text-[#050505] shadow-sm font-bold'
                  : 'bg-[#101412] text-[#C4C8C6] border border-[#27302C] hover:text-white hover:border-[#38443F]'
              }`}
            >
              {r.icon}
              <span>{r.label}</span>
            </button>
          );
        })}
      </div>

      {/* Viewports & Simulation Toggles */}
      <div className="flex items-center gap-2 ml-auto flex-wrap">
        {/* Viewport dropdown */}
        <div className="flex items-center gap-1.5 bg-[#101412] border border-[#27302C] rounded-lg px-2 py-1">
          <Smartphone className="w-3.5 h-3.5 text-[#00C781]" />
          <select
            value={selectedViewport.id}
            onChange={(e) => {
              const vp = VIEWPORT_OPTIONS.find((v) => v.id === e.target.value);
              if (vp) onSelectViewport(vp);
            }}
            className="bg-transparent text-white font-medium text-xs focus:outline-none cursor-pointer"
            aria-label="Seleccionar viewport de dispositivo Android"
          >
            {VIEWPORT_OPTIONS.map((v) => (
              <option key={v.id} value={v.id} className="bg-[#101412] text-white">
                {v.name} ({v.width > 0 ? `${v.width}×${v.height}` : 'Fluido'})
              </option>
            ))}
          </select>
        </div>

        {/* Simulator Controls */}
        <div className="flex items-center gap-1 bg-[#101412] border border-[#27302C] rounded-lg p-0.5">
          <button
            type="button"
            onClick={onToggleOffline}
            className={`p-1.5 rounded transition-colors ${
              isSimulatedOffline
                ? 'bg-[#EF4444] text-white'
                : 'text-[#A8ADAB] hover:text-white'
            }`}
            title="Simular Sin Conexión (Offline)"
          >
            <WifiOff className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggleLoading}
            className={`p-1.5 rounded transition-colors ${
              isSimulatedLoading
                ? 'bg-[#00C781] text-black font-bold'
                : 'text-[#A8ADAB] hover:text-white'
            }`}
            title="Simular Carga Inicial / Skeleton"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggleError}
            className={`p-1.5 rounded transition-colors ${
              isSimulatedError
                ? 'bg-[#F59E0B] text-black font-bold'
                : 'text-[#A8ADAB] hover:text-white'
            }`}
            title="Simular Error 500 de Conexión"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggleEmptyLibrary}
            className={`p-1.5 rounded transition-colors ${
              isEmptyLibrary
                ? 'bg-[#3B82F6] text-white'
                : 'text-[#A8ADAB] hover:text-white'
            }`}
            title="Simular Biblioteca Vacía"
          >
            <Bookmark className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggleParental}
            className={`p-1.5 rounded transition-colors ${
              isParentalRestricted
                ? 'bg-[#8B5CF6] text-white'
                : 'text-[#A8ADAB] hover:text-white'
            }`}
            title="Simular Bloqueo PIN Parental"
          >
            <Key className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onResetDemoData}
            className="p-1.5 rounded text-[#A8ADAB] hover:text-[#00C781] transition-colors"
            title="Restablecer Datos de Demostración"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Close QA Mode / Return to Product Preview */}
        <button
          type="button"
          onClick={onCloseQaMode}
          className="inline-flex items-center gap-1 bg-[#1A201D] hover:bg-[#27302C] text-[#C4C8C6] hover:text-white px-2.5 py-1 rounded-lg border border-[#27302C] transition-colors text-xs font-semibold"
          title="Cerrar barra QA y volver a Product Preview"
        >
          <EyeOff className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Cerrar QA</span>
        </button>
      </div>
    </aside>
  );
};

