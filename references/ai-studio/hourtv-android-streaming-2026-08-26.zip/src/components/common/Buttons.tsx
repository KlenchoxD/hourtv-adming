import React from 'react';
import { Loader2 } from 'lucide-react';

interface PrimaryButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'emerald' | 'white' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  isLoading?: boolean;
  fullWidth?: boolean;
  children: React.ReactNode;
}

export const PrimaryButton: React.FC<PrimaryButtonProps> = ({
  variant = 'emerald',
  size = 'md',
  icon,
  isLoading = false,
  fullWidth = false,
  children,
  className = '',
  disabled,
  ...props
}) => {
  const baseClasses =
    'relative inline-flex items-center justify-center font-medium rounded-xl transition-all duration-120 active:scale-[0.98] select-none min-h-[48px] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]/40 touch-manipulation disabled:opacity-50 disabled:pointer-events-none disabled:active:scale-100';

  const sizeClasses = {
    sm: 'px-4 py-2.5 text-sm gap-2',
    md: 'px-5 py-3 text-base gap-2.5 font-semibold',
    lg: 'px-6 py-3.5 text-lg gap-3 font-semibold'
  };

  const variantClasses = {
    emerald:
      'bg-[#00C781] text-[#050505] hover:bg-[#00E595] active:bg-[#00B072] shadow-sm font-bold',
    white:
      'bg-[#F5F5F5] text-[#050505] hover:bg-white active:bg-[#E0E0E0] font-bold',
    danger:
      'bg-[#1E1414] text-[#F87171] border border-[#7F1D1D]/40 hover:bg-[#2A1818] active:bg-[#180E0E]'
  };

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${
        fullWidth ? 'w-full' : ''
      } ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-5 h-5 animate-spin text-current" />
      ) : (
        icon && <span className="flex-shrink-0 flex items-center justify-center">{icon}</span>
      )}
      <span className="truncate whitespace-nowrap">{children}</span>
    </button>
  );
};

interface SecondaryButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  isLoading?: boolean;
  fullWidth?: boolean;
  children: React.ReactNode;
}

export const SecondaryButton: React.FC<SecondaryButtonProps> = ({
  size = 'md',
  icon,
  isLoading = false,
  fullWidth = false,
  children,
  className = '',
  disabled,
  ...props
}) => {
  const baseClasses =
    'relative inline-flex items-center justify-center font-medium rounded-xl bg-[#151917] hover:bg-[#1A201D] active:bg-[#101412] text-[#F5F5F5] border border-[#27302C] transition-all duration-120 active:scale-[0.98] select-none min-h-[48px] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#27302C] touch-manipulation disabled:opacity-50 disabled:pointer-events-none disabled:active:scale-100';

  const sizeClasses = {
    sm: 'px-4 py-2.5 text-sm gap-2',
    md: 'px-5 py-3 text-base gap-2.5 font-medium',
    lg: 'px-6 py-3.5 text-lg gap-3 font-medium'
  };

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${
        fullWidth ? 'w-full' : ''
      } ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-5 h-5 animate-spin text-[#A8ADAB]" />
      ) : (
        icon && <span className="flex-shrink-0 flex items-center justify-center">{icon}</span>
      )}
      <span className="truncate whitespace-nowrap">{children}</span>
    </button>
  );
};

interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'surface' | 'ghost' | 'emerald' | 'glass';
  ariaLabel: string;
  badge?: number | string | boolean;
  children: React.ReactNode;
}

export const IconButton: React.FC<IconButtonProps> = ({
  size = 'md',
  variant = 'surface',
  ariaLabel,
  badge,
  children,
  className = '',
  ...props
}) => {
  const sizeClasses = {
    sm: 'w-10 h-10 min-w-[40px]',
    md: 'w-12 h-12 min-w-[48px]',
    lg: 'w-14 h-14 min-w-[56px]'
  };

  const variantClasses = {
    surface:
      'bg-[#151917] text-[#F5F5F5] border border-[#27302C] hover:bg-[#1A201D] active:bg-[#101412]',
    ghost:
      'bg-transparent text-[#C4C8C6] hover:text-[#F5F5F5] hover:bg-[#151917]/70 active:bg-[#151917]',
    emerald:
      'bg-[#00C781] text-[#050505] hover:bg-[#00E595] active:bg-[#00B072] font-bold',
    glass:
      'bg-[#050505]/70 backdrop-blur-md text-[#F5F5F5] border border-[#27302C]/60 hover:bg-[#050505]/90 active:scale-95'
  };

  return (
    <button
      type="button"
      aria-label={ariaLabel}
      className={`relative inline-flex items-center justify-center rounded-full transition-all duration-120 active:scale-95 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]/40 touch-manipulation disabled:opacity-40 disabled:pointer-events-none ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
      {...props}
    >
      {children}
      {badge !== undefined && (
        <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-[#00C781] ring-2 ring-[#050505]" />
      )}
    </button>
  );
};

interface CategoryTabProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
  count?: number;
}

export const CategoryTab: React.FC<CategoryTabProps> = ({
  label,
  isActive,
  onClick,
  count
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all duration-120 active:scale-95 select-none whitespace-nowrap min-h-[38px] ${
        isActive
          ? 'bg-[#00C781] text-[#050505] font-bold shadow-sm'
          : 'bg-[#151917] text-[#C4C8C6] border border-[#27302C] hover:text-[#F5F5F5] hover:border-[#38443F]'
      }`}
    >
      <span>{label}</span>
      {count !== undefined && (
        <span
          className={`text-xs px-1.5 py-0.5 rounded-full ${
            isActive ? 'bg-black/20 text-black font-extrabold' : 'bg-[#27302C] text-[#A8ADAB]'
          }`}
        >
          {count}
        </span>
      )}
    </button>
  );
};

