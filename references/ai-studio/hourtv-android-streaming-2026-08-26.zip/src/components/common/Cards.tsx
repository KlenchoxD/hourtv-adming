import React, { useState } from 'react';
import { Play, Star, Plus, Check, MoreVertical } from 'lucide-react';
import { MediaItem, Episode, TVChannel } from '../../types';

interface PosterCardProps {
  item: MediaItem;
  onClick: (item: MediaItem) => void;
  onToggleMyList?: (item: MediaItem, e: React.MouseEvent) => void;
  size?: 'sm' | 'md' | 'lg';
  showRanking?: number;
  className?: string;
}

export const PosterCard: React.FC<PosterCardProps> = ({
  item,
  onClick,
  onToggleMyList,
  size = 'md',
  showRanking,
  className = ''
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);

  const widthClasses = {
    sm: 'w-[110px] min-w-[110px]',
    md: 'w-[135px] min-w-[135px]',
    lg: 'w-[160px] min-w-[160px]'
  };

  return (
    <div
      onClick={() => onClick(item)}
      className={`group relative flex flex-col cursor-pointer transition-transform duration-120 ease-out active:scale-[0.97] touch-manipulation select-none ${widthClasses[size]} ${className}`}
      role="button"
      tabIndex={0}
      aria-label={`${item.title}, ${item.year}, ${item.genres.join(', ')}`}
    >
      {showRanking !== undefined && (
        <div className="absolute -left-3 bottom-8 z-20 pointer-events-none">
          <span className="text-6xl font-black italic tracking-tighter text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)] stroke-black">
            {showRanking}
          </span>
        </div>
      )}

      <div className="relative aspect-[2/3] w-full rounded-xl overflow-hidden bg-[#101412] border border-[#27302C]/80 shadow-md">
        {/* Placeholder background while loading */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-[#151917] skeleton-shimmer" />
        )}

        <img
          src={item.posterUrl}
          alt={item.title}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-250 ease-out ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          } group-hover:scale-105 group-active:scale-100`}
        />

        <div className="absolute top-1.5 left-1.5 right-1.5 flex items-center justify-between pointer-events-none">
          {item.isOriginal ? (
            <span className="px-1.5 py-0.5 rounded bg-[#00C781] text-[#050505] text-[9px] font-extrabold tracking-wider uppercase shadow">
              Original
            </span>
          ) : (
            <span className="px-1.5 py-0.5 rounded bg-[#050505]/80 backdrop-blur-sm text-[#F5F5F5] text-[9px] font-semibold border border-[#27302C]/60">
              {item.ageRating}
            </span>
          )}

          {item.qualityBadges.includes('4K UHD') && (
            <span className="px-1 py-0.5 rounded bg-[#050505]/80 backdrop-blur-sm text-[#00C781] text-[9px] font-bold border border-[#00C781]/40">
              4K
            </span>
          )}
        </div>

        {onToggleMyList && (
          <button
            type="button"
            onClick={(e) => onToggleMyList(item, e)}
            className="absolute bottom-1.5 right-1.5 w-8 h-8 rounded-full bg-[#050505]/85 backdrop-blur-sm border border-[#27302C] text-[#F5F5F5] flex items-center justify-center hover:text-[#00C781] hover:border-[#00C781] transition-all duration-120 active:scale-90"
            aria-label={item.isInMyList ? 'Quitar de mi lista' : 'Agregar a mi lista'}
          >
            {item.isInMyList ? (
              <Check className="w-4 h-4 text-[#00C781]" />
            ) : (
              <Plus className="w-4 h-4" />
            )}
          </button>
        )}
      </div>

      <div className="mt-1.5 px-0.5">
        <h4 className="text-xs font-semibold text-[#F5F5F5] truncate leading-tight">
          {item.title}
        </h4>
        <div className="flex items-center gap-1.5 text-[11px] text-[#A8ADAB] mt-0.5">
          <span>{item.year}</span>
          <span>•</span>
          <span className="truncate">{item.genres[0]}</span>
        </div>
      </div>
    </div>
  );
};

interface ContinueWatchingCardProps {
  item: MediaItem;
  onClick: (item: MediaItem) => void;
  onPlayDirect: (item: MediaItem, e: React.MouseEvent) => void;
  onOptionsClick?: (item: MediaItem, e: React.MouseEvent) => void;
  className?: string;
}

export const ContinueWatchingCard: React.FC<ContinueWatchingCardProps> = ({
  item,
  onClick,
  onPlayDirect,
  onOptionsClick,
  className = ''
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const progress = item.progressPercentage || 45;

  return (
    <div
      onClick={() => onClick(item)}
      className={`group relative flex flex-col w-[230px] min-w-[230px] cursor-pointer transition-transform duration-120 ease-out active:scale-[0.98] touch-manipulation select-none ${className}`}
      role="button"
      tabIndex={0}
      aria-label={`Continuar viendo ${item.title}`}
    >
      <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden bg-[#101412] border border-[#27302C] shadow-md">
        {!imageLoaded && (
          <div className="absolute inset-0 bg-[#151917] skeleton-shimmer" />
        )}

        <img
          src={item.backdropUrl}
          alt={item.title}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-250 ease-out ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          } group-hover:scale-105`}
        />

        <div className="absolute inset-0 bg-gradient-to-t from-[#050505]/90 via-transparent to-black/30" />

        <button
          type="button"
          onClick={(e) => onPlayDirect(item, e)}
          className="absolute inset-0 m-auto w-11 h-11 rounded-full bg-[#00C781] text-[#050505] flex items-center justify-center shadow-lg transition-transform duration-120 hover:scale-110 active:scale-95 z-10"
          aria-label={`Reproducir ${item.title}`}
        >
          <Play className="w-5 h-5 fill-current ml-0.5" />
        </button>

        <div className="absolute top-2 left-2">
          <span className="px-1.5 py-0.5 rounded bg-[#050505]/80 backdrop-blur-sm text-[10px] font-semibold text-[#C4C8C6] border border-[#27302C]/60">
            {item.type === 'series' ? 'Serie' : 'Película'}
          </span>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-[#151917]">
          <div
            className="h-full bg-[#00C781] transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="flex items-center justify-between mt-2 px-1">
        <div className="flex-1 min-w-0 pr-2">
          <h4 className="text-xs font-semibold text-[#F5F5F5] truncate leading-tight">
            {item.title}
          </h4>
          <p className="text-[11px] text-[#A8ADAB] truncate mt-0.5">
            {item.type === 'series' ? 'T1:E3 • Quedan 28 min' : `Quedan 42 min de ${item.durationOrSeasons}`}
          </p>
        </div>

        {onOptionsClick && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOptionsClick(item, e);
            }}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#A8ADAB] hover:text-[#F5F5F5] hover:bg-[#151917] active:bg-[#101412] transition-colors"
            aria-label="Más opciones"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};

interface EpisodeCardProps {
  episode: Episode;
  isActive?: boolean;
  onPlay: (episode: Episode) => void;
  className?: string;
}

export const EpisodeCard: React.FC<EpisodeCardProps> = ({
  episode,
  isActive = false,
  onPlay,
  className = ''
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <div
      onClick={() => onPlay(episode)}
      className={`group relative flex items-center gap-3 p-2.5 rounded-xl border transition-all duration-120 active:scale-[0.99] cursor-pointer touch-manipulation select-none ${
        isActive
          ? 'bg-[#101412] border-[#00C781]'
          : 'bg-[#101412]/60 border-[#27302C]/80 hover:bg-[#151917] hover:border-[#38443F]'
      } ${className}`}
      role="button"
      tabIndex={0}
      aria-label={`Episodio ${episode.episodeNumber}: ${episode.title}`}
    >
      <div className="relative w-28 min-w-[112px] aspect-[16/9] rounded-lg overflow-hidden bg-[#080A09] flex-shrink-0">
        {!imageLoaded && (
          <div className="absolute inset-0 bg-[#151917] skeleton-shimmer" />
        )}

        <img
          src={episode.thumbnailUrl}
          alt={episode.title}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          className={`w-full h-full object-cover transition-opacity duration-250 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div className="absolute inset-0 bg-black/30 flex items-center justify-center group-hover:bg-black/10 transition-colors">
          <div className="w-8 h-8 rounded-full bg-[#00C781]/90 text-[#050505] flex items-center justify-center shadow transition-transform duration-120 group-active:scale-95">
            <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
          </div>
        </div>

        {episode.progressPercentage !== undefined && episode.progressPercentage > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/60">
            <div
              className="h-full bg-[#00C781]"
              style={{ width: `${episode.progressPercentage}%` }}
            />
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 text-xs text-[#00C781] font-semibold mb-0.5">
          <span>Episodio {episode.episodeNumber}</span>
          <span className="text-[#27302C]">•</span>
          <span className="text-[#A8ADAB] font-normal">{episode.durationMinutes} min</span>
        </div>
        <h4 className="text-sm font-semibold text-[#F5F5F5] truncate leading-tight">
          {episode.title}
        </h4>
        {episode.synopsis && (
          <p className="text-xs text-[#A8ADAB] line-clamp-2 mt-1 leading-relaxed">
            {episode.synopsis}
          </p>
        )}
      </div>
    </div>
  );
};

interface ChannelCardProps {
  channel: TVChannel;
  isSelected?: boolean;
  onSelect: (channel: TVChannel) => void;
  onToggleFavorite: (channel: TVChannel, e: React.MouseEvent) => void;
  className?: string;
}

/* Tarjeta de Canal IPTV Limpia y Compacta */
export const ChannelCard: React.FC<ChannelCardProps> = ({
  channel,
  isSelected = false,
  onSelect,
  onToggleFavorite,
  className = ''
}) => {
  return (
    <div
      onClick={() => onSelect(channel)}
      className={`group relative flex items-center justify-between p-3 rounded-xl border transition-all duration-120 active:scale-[0.99] cursor-pointer touch-manipulation select-none ${
        isSelected
          ? 'bg-[#101412] border-[#00C781] shadow-lg ring-1 ring-[#00C781]/50'
          : 'bg-[#101412]/80 border-[#27302C] hover:bg-[#151917] hover:border-[#38443F]'
      } ${className}`}
      role="button"
      tabIndex={0}
      aria-label={`Canal ${channel.channelNumber} ${channel.name}`}
    >
      {/* Número y Nombre del Canal */}
      <div className="flex items-center gap-3 min-w-0">
        <span className="w-8 h-8 min-w-[32px] rounded-lg bg-[#151917] border border-[#27302C] flex items-center justify-center font-mono font-bold text-xs text-[#00C781]">
          {channel.channelNumber}
        </span>
        <div className="min-w-0">
          <h4 className="text-sm font-bold text-[#F5F5F5] truncate leading-tight">{channel.name}</h4>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-[10px] text-[#00C781] uppercase font-semibold tracking-wider font-mono">
              {channel.streamQuality}
            </span>
          </div>
        </div>
      </div>

      {/* Botón de Favorito */}
      <button
        type="button"
        onClick={(e) => onToggleFavorite(channel, e)}
        className="w-8 h-8 min-w-[32px] rounded-full flex items-center justify-center text-[#A8ADAB] hover:text-[#00C781] active:scale-90 transition-all ml-2"
        aria-label={channel.isFavorite ? 'Quitar de favoritos' : 'Marcar favorito'}
      >
        <Star
          className={`w-4 h-4 ${
            channel.isFavorite ? 'text-[#00C781] fill-[#00C781]' : 'stroke-current'
          }`}
        />
      </button>
    </div>
  );
};