export type RouteId =
  | 'system_states'
  | 'access'
  | 'home'
  | 'movies'
  | 'series'
  | 'search'
  | 'details'
  | 'library'
  | 'live_tv'
  | 'profile'
  | 'player'
  | 'originals';

export type ContentType = 'movie' | 'series' | 'anime' | 'telenovela';

export interface Episode {
  id: string;
  seasonNumber: number;
  episodeNumber: number;
  title: string;
  durationMinutes: number;
  thumbnailUrl: string;
  progressPercentage?: number;
  synopsis?: string;
}

export interface CastMember {
  id: string;
  name: string;
  character: string;
  avatarUrl: string;
}

export interface EditorialReview {
  author: string;
  outlet: string;
  score: number; // 0 - 100
  summary: string;
  date: string;
}

export interface TechnicalDetails {
  resolution: string; // e.g. "4K Ultra HD (3840x2160)"
  hdrFormat: string; // e.g. "Dolby Vision / HDR10+"
  audioTrack: string; // e.g. "Dolby Atmos 7.1.4 / 5.1 Surround"
  aspectRatio: string; // e.g. "2.39:1 Panavision"
  director: string;
  audioLanguages: string[];
  subtitles: string[];
  ageRatingDescription: string;
}

export interface MediaItem {
  id: string;
  title: string;
  type: ContentType;
  year: number;
  ageRating: string; // "13+", "16+", "18+", "TP"
  durationOrSeasons: string; // "2 h 18 min" or "3 Temporadas"
  genres: string[];
  isOriginal?: boolean;
  isTrending?: boolean;
  matchScore: number; // e.g. 98%
  qualityBadges: string[]; // ["4K", "HDR10+", "Dolby Atmos"]
  posterUrl: string;
  backdropUrl: string;
  heroHeadline?: string;
  synopsis: string;
  whyWatch: string;
  trailerUrl?: string;
  cast: CastMember[];
  editorialReview: EditorialReview;
  technicalDetails: TechnicalDetails;
  episodes?: Episode[];
  isInMyList?: boolean;
  progressPercentage?: number;
  ratingAverage: number;
  releaseDateISO: string;
}

export interface TVProgram {
  id: string;
  title: string;
  startTime: string; // "22:00"
  endTime: string; // "23:30"
  progressPercent: number; // 0 - 100
  category: string;
  synopsis: string;
  ageRating: string;
}

export interface TVChannel {
  id: string;
  channelNumber: string;
  name: string;
  category: 'noticias' | 'cine' | 'deportes' | 'series' | 'novelas' | 'infantil' | 'religioso' | 'adulto';
  logoText: string;
  isFavorite: boolean;
  isPopular?: boolean;
  isLive: boolean;
  streamQuality: '4K 60FPS' | '1080p 60FPS' | '1080p';
  currentProgram: TVProgram;
  nextProgram: TVProgram;
  streamPreviewUrl: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatarId: string;
  avatarColor: string;
  isPrimary: boolean;
  isKids: boolean;
  email: string;
  planName: string;
  streamQualityPreference: 'Auto' | '4K' | '1080p' | 'Ahorro de datos';
  audioLanguagePreference: string;
  subtitlePreference: string;
  parentalControlEnabled: boolean;
  parentalPin: string;
  parentalMaxAge: 'TP' | '13+' | '16+' | '18+';
  dataSaverCellular: boolean;
  notificationsEnabled: boolean;
}

export interface SnackbarState {
  id: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  type?: 'success' | 'info' | 'warning';
}

export interface ViewportOption {
  id: string;
  name: string;
  width: number;
  height: number;
  deviceLabel: string;
}

export interface AppUpdateInfo {
  currentVersion: string;
  latestVersion: string;
  buildNumber: number;
  releaseDate: string;
  hasUpdate: boolean;
  releaseNotes: string[];
  sizeMB: number;
  status: 'idle' | 'checking' | 'downloading' | 'installing' | 'updated';
}

