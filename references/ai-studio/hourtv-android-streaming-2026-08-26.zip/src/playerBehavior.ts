export type SkipKind = 'recap' | 'intro';

export interface SkipAction {
  kind: SkipKind;
  label: string;
  targetSec: number;
}

export interface SkipActionInput {
  currentTimeSec: number;
  isEpisode: boolean;
  recapStartSec: number;
  recapEndSec: number;
  introStartSec: number;
  introEndSec: number;
  skippedRecap: boolean;
  skippedIntro: boolean;
}

export interface NextEpisodeCountdownState {
  visible: boolean;
  secondsRemaining: number;
  cancelled: boolean;
  shouldAdvance: boolean;
  advanced: boolean;
}

export function getSkipAction(input: SkipActionInput): SkipAction | null {
  if (
    input.isEpisode &&
    !input.skippedRecap &&
    input.currentTimeSec >= input.recapStartSec &&
    input.currentTimeSec <= input.recapEndSec
  ) {
    return {
      kind: 'recap',
      label: 'Omitir resumen',
      targetSec: input.recapEndSec,
    };
  }

  if (
    !input.skippedIntro &&
    input.currentTimeSec >= input.introStartSec &&
    input.currentTimeSec <= input.introEndSec
  ) {
    return {
      kind: 'intro',
      label: 'Omitir intro',
      targetSec: input.introEndSec,
    };
  }

  return null;
}

export function shouldShowNextEpisode(input: {
  isEpisode: boolean;
  currentTimeSec: number;
  durationSec: number;
  windowSec: number;
  cancelled: boolean;
}): boolean {
  return (
    input.isEpisode &&
    !input.cancelled &&
    input.currentTimeSec >= Math.max(0, input.durationSec - input.windowSec) &&
    input.currentTimeSec < input.durationSec
  );
}

export function resolvePlaybackEpisode<T>(input: {
  isSeries: boolean;
  requestedEpisode?: T;
  episodes?: T[];
}): T | undefined {
  if (input.requestedEpisode) {
    return input.requestedEpisode;
  }

  return input.isSeries ? input.episodes?.[0] : undefined;
}

export function createNextEpisodeCountdown(
  seconds: number,
): NextEpisodeCountdownState {
  return {
    visible: true,
    secondsRemaining: Math.max(0, seconds),
    cancelled: false,
    shouldAdvance: false,
    advanced: false,
  };
}

export function cancelNextEpisodeCountdown(
  state: NextEpisodeCountdownState,
): NextEpisodeCountdownState {
  return {
    ...state,
    visible: false,
    cancelled: true,
    shouldAdvance: false,
  };
}

export function tickNextEpisodeCountdown(
  state: NextEpisodeCountdownState,
): NextEpisodeCountdownState {
  if (!state.visible || state.cancelled || state.advanced) {
    return { ...state, shouldAdvance: false };
  }

  if (state.secondsRemaining <= 1) {
    return {
      ...state,
      visible: false,
      secondsRemaining: 0,
      shouldAdvance: true,
      advanced: true,
    };
  }

  return {
    ...state,
    secondsRemaining: state.secondsRemaining - 1,
    shouldAdvance: false,
  };
}



export type LiveTvCategoryId =
  | 'todos'
  | 'favoritos'
  | 'deportes'
  | 'cine'
  | 'series'
  | 'novelas'
  | 'populares'
  | 'noticias'
  | 'infantil'
  | 'religioso'
  | 'adulto';

export const LIVE_TV_CATEGORIES: ReadonlyArray<{ id: LiveTvCategoryId; label: string }> = [
  { id: 'todos', label: 'Todos los canales' },
  { id: 'favoritos', label: 'Favoritos' },
  { id: 'deportes', label: 'Deportes' },
  { id: 'cine', label: 'Cine' },
  { id: 'series', label: 'Series' },
  { id: 'novelas', label: 'Novelas' },
  { id: 'populares', label: 'Populares' },
  { id: 'noticias', label: 'Noticias' },
  { id: 'infantil', label: 'Infantil' },
  { id: 'religioso', label: 'Religioso' },
  { id: 'adulto', label: '+18' },
];

export const getVisibleLiveTvCategories = (adultAccessGranted: boolean) =>
  LIVE_TV_CATEGORIES.filter((category) => adultAccessGranted || category.id !== 'adulto');

export const filterLiveTvChannels = <T extends { id?: string; category: string; isPopular?: boolean; isFavorite?: boolean }>(
  channels: readonly T[],
  categoryId: LiveTvCategoryId,
  adultAccessGranted = false,
): T[] => {
  const visibleChannels = adultAccessGranted
    ? [...channels]
    : channels.filter((channel) => channel.category !== 'adulto');
  if (categoryId === 'todos') return visibleChannels;
  if (categoryId === 'favoritos') {
    return visibleChannels.filter((channel) => channel.isFavorite === true);
  }
  if (categoryId === 'populares') {
    return visibleChannels.filter((channel) => channel.isPopular === true);
  }
  return visibleChannels.filter((channel) => channel.category === categoryId);
};
