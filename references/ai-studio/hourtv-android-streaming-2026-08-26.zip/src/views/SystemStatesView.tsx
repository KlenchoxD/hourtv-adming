import React, { useState } from 'react';
import {
  Layers,
  Sparkles,
  WifiOff,
  AlertTriangle,
  RefreshCw,
  Bookmark,
  Search,
  Lock,
  CheckCircle2,
  Sliders
} from 'lucide-react';
import {
  InitialLoadingState,
  SkeletonHero,
  SkeletonCarousel,
  ErrorView,
  OfflineView,
  EmptyState,
  ParentalPinModal
} from '../components/common/SystemStates';
import { PrimaryButton, SecondaryButton } from '../components/common/Buttons';

interface SystemStatesViewProps {
  onShowSnackbar: (msg: string) => void;
}

export const SystemStatesView: React.FC<SystemStatesViewProps> = ({ onShowSnackbar }) => {
  const [activeTab, setActiveTab] = useState<
    'initial_loading' | 'skeleton' | 'offline' | 'load_error' | 'empty' | 'no_results' | 'parental_pin'
  >('initial_loading');

  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [isRetrying, setIsRetrying] = useState(false);

  const handleRetry = () => {
    setIsRetrying(true);
    setTimeout(() => {
      setIsRetrying(false);
      onShowSnackbar('Conexión reestablecida con los servidores de HourTV.');
    }, 900);
  };

  const stateTabs = [
    { id: 'initial_loading', label: 'Loading Inicial' },
    { id: 'skeleton', label: 'Skeletons' },
    { id: 'offline', label: 'Sin Conexión' },
    { id: 'load_error', label: 'Error 500 / Fallo' },
    { id: 'empty', label: 'Biblioteca Vacía' },
    { id: 'no_results', label: 'Sin Resultados' },
    { id: 'parental_pin', label: 'PIN Restringido' }
  ];

  return (
    <div className="flex-1 pb-24 text-[#F5F5F5] select-none bg-[#080A09] animate-in fade-in duration-200">
      {/* Header Selector */}
      <div className="sticky top-0 z-30 bg-[#080A09]/95 backdrop-blur-md px-4 pt-3 pb-2 border-b border-[#27302C]/60">
        <div className="flex items-center gap-2 mb-2">
          <Layers className="w-5 h-5 text-[#00C781]" />
          <h1 className="text-base font-bold text-white">System & Error States</h1>
        </div>

        {/* State Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {stateTabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-[#00C781] text-black font-bold shadow-sm'
                  : 'bg-[#151917] text-[#C4C8C6] border border-[#27302C] hover:border-[#38443F]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* State Rendering Container */}
      <div className="p-4">
        {/* 1. Initial Loading State */}
        {activeTab === 'initial_loading' && (
          <div>
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB]">
              <span className="font-bold text-[#00C781]">Estado 1:</span> Pantalla de carga inicial con branding HourTV, animación de resplandor esmeralda y barra de progreso.
            </div>
            <InitialLoadingState />
          </div>
        )}

        {/* 2. Skeletons */}
        {activeTab === 'skeleton' && (
          <div>
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB]">
              <span className="font-bold text-[#00C781]">Estado 2:</span> Shimmer Skeletons con gradientes ultra livianos adaptados a pantallas AMOLED.
            </div>
            <SkeletonHero />
            <SkeletonCarousel count={3} />
            <SkeletonCarousel count={3} />
          </div>
        )}

        {/* 3. Sin Conexión */}
        {activeTab === 'offline' && (
          <div>
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB]">
              <span className="font-bold text-[#00C781]">Estado 3:</span> Modo fuera de línea cuando se interrumpe la red móvil o Wi-Fi.
            </div>
            <OfflineView
              onRetry={handleRetry}
              onGoToLibrary={() => onShowSnackbar('Navegando a Mi Biblioteca...')}
            />
          </div>
        )}

        {/* 4. Error de Carga / 500 */}
        {activeTab === 'load_error' && (
          <div>
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB]">
              <span className="font-bold text-[#00C781]">Estado 4:</span> Error de servidor / timeout con botón de reintentar interactivo.
            </div>
            <ErrorView
              title="No pudimos sincronizar tu perfil"
              message="Ocurrió un error temporal al obtener tu lista de reproducción desde la nube de HourTV."
              onRetry={handleRetry}
              isLoading={isRetrying}
            />
          </div>
        )}

        {/* 5. Biblioteca Vacía */}
        {activeTab === 'empty' && (
          <div>
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB]">
              <span className="font-bold text-[#00C781]">Estado 5:</span> Estado vacío cuando el usuario no tiene contenidos guardados.
            </div>
            <EmptyState
              icon={<Bookmark className="w-8 h-8 text-[#00C781]" />}
              title="Tu lista está completamente vacía"
              description="Añade películas, series o programas de televisión para verlos más tarde en cualquier dispositivo."
              actionLabel="Explorar catálogo 2026"
              onAction={() => onShowSnackbar('Redirigiendo a estrenos...')}
            />
          </div>
        )}

        {/* 6. Sin Resultados de Búsqueda */}
        {activeTab === 'no_results' && (
          <div>
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB]">
              <span className="font-bold text-[#00C781]">Estado 6:</span> Búsqueda sin coincidencias con sugerencias inteligentes.
            </div>
            <EmptyState
              icon={<Search className="w-8 h-8 text-[#A8ADAB]" />}
              title="No encontramos coincidencias para 'Cyber2099'"
              description="Verifica que el título esté bien escrito o prueba explorando por géneros como Ciencia Ficción o Acción."
              actionLabel="Ver sugerencias de tendencias"
              onAction={() => onShowSnackbar('Cargando tendencias...')}
            />
          </div>
        )}

        {/* 7. PIN Parental Restringido */}
        {activeTab === 'parental_pin' && (
          <div className="flex flex-col items-center justify-center p-6 text-center">
            <div className="mb-4 p-3 rounded-xl bg-[#101412] border border-[#27302C] text-xs text-[#A8ADAB] w-full">
              <span className="font-bold text-[#00C781]">Estado 7:</span> Bloqueo de seguridad con PIN de 4 dígitos para títulos +18 (PIN demo: 1234).
            </div>

            <div className="w-16 h-16 rounded-full bg-[#151917] border border-[#27302C] flex items-center justify-center text-[#8B5CF6] mb-3">
              <Lock className="w-8 h-8" />
            </div>

            <h3 className="text-base font-bold text-white mb-2">Contenido Bloqueado (+18)</h3>
            <p className="text-xs text-[#A8ADAB] max-w-xs mb-5">
              Se requiere autenticación por PIN parental para reproducir "Frontera Roja" o "El refugio nocturno".
            </p>

            <PrimaryButton
              icon={<Lock className="w-4 h-4" />}
              onClick={() => setIsPinModalOpen(true)}
            >
              Abrir Teclado de PIN
            </PrimaryButton>
          </div>
        )}
      </div>

      {/* Parental PIN Modal */}
      <ParentalPinModal
        isOpen={isPinModalOpen}
        onClose={() => setIsPinModalOpen(false)}
        onSuccess={() => {
          setIsPinModalOpen(false);
          onShowSnackbar('PIN correcto. Acceso concedido a títulos restringidos.');
        }}
        titleName="Frontera Roja (+18)"
        correctPin="1234"
      />
    </div>
  );
};
