import React, { useState } from 'react';
import {
  ArrowLeft,
  Play,
  Plus,
  Check,
  Share2,
  Tv,
  ChevronDown
} from 'lucide-react';
import { MediaItem, Episode } from '../types';
import { PrimaryButton, SecondaryButton } from '../components/common/Buttons';
import { EpisodeCard, PosterCard } from '../components/common/Cards';

interface DetailsViewProps {
  item: MediaItem;
  allMedia: MediaItem[];
  onBack: () => void;
  onPlayMedia: (item: MediaItem, episode?: Episode) => void;
  onToggleMyList: (item: MediaItem) => void;
  onSelectRelatedMedia: (item: MediaItem) => void;
  onShowSnackbar: (msg: string) => void;
}

export const DetailsView: React.FC<DetailsViewProps> = ({
  item,
  allMedia,
  onBack,
  onPlayMedia,
  onToggleMyList,
  onSelectRelatedMedia,
  onShowSnackbar
}) => {
  const [selectedSeason, setSelectedSeason] = useState<number>(1);
  const [isSeasonOpen, setIsSeasonOpen] = useState<boolean>(false);

  // Related media items (same genre or type)
  const relatedItems = allMedia
    .filter((m) => m.id !== item.id && (m.genres.some((g) => item.genres.includes(g)) || m.type === item.type))
    .slice(0, 6);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${item.title} en HourTV`,
          text: `Mira "${item.title}" en HourTV Streaming Premium.`,
          url: window.location.href
        });
      } catch {
        onShowSnackbar(`Enlace de "${item.title}" copiado al portapapeles.`);
      }
    } else {
      onShowSnackbar(`Enlace de "${item.title}" copiado al portapapeles.`);
    }
  };

  // Filter episodes by season
  const currentSeasonEpisodes = (item.episodes || []).filter(
    (ep) => ep.seasonNumber === selectedSeason
  );

  return (
    <div className="flex-1 pb-12 text-[#F5F5F5] select-none bg-[#080A09] animate-screen-enter">
      {/* Floating Top Nav Button */}
      <div className="fixed top-3 left-4 z-40">
        <button
          type="button"
          onClick={onBack}
          className="w-12 h-12 min-w-[48px] min-h-[48px] rounded-full bg-[#050505]/85 backdrop-blur-md border border-[#27302C] text-[#F5F5F5] flex items-center justify-center shadow-lg hover:bg-[#050505] active:scale-95 transition-all duration-120 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]"
          aria-label="Volver a la pantalla anterior"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      </div>

      {/* Hero Backdrop & Posters */}
      <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] bg-[#101412] overflow-hidden">
        <img
          src={item.backdropUrl}
          alt={item.title}
          className="w-full h-full object-cover"
        />
        {/* Soft Multi-Stop Dark Vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#080A09] via-[#080A09]/50 to-black/20" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#080A09]/60 via-transparent to-transparent" />
      </div>

      {/* Main Metadata Section */}
      <div className="px-5 -mt-6 relative z-10">
        
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight mb-2">
          {item.title}
        </h1>

        {/* Quality Badges */}
        <div className="flex items-center gap-1.5 mb-4 flex-wrap">
          {item.qualityBadges.map((badge) => (
            <span
              key={badge}
              className="px-2 py-0.5 rounded bg-[#101412] border border-[#27302C] text-[10px] font-mono font-bold text-[#00C781]"
            >
              {badge}
            </span>
          ))}
        </div>

        {/* Primary Centered Action Buttons */}
        <div className="flex flex-col gap-2.5 mb-5">
          <PrimaryButton
            fullWidth
            onClick={() => onPlayMedia(item)}
            icon={<Play className="w-5 h-5 fill-current ml-0.5" />}
            size="lg"
          >
            {item.type === 'series' ? 'Reproducir T1:E1' : 'Reproducir Película'}
          </PrimaryButton>

          <div className="grid grid-cols-2 gap-2.5 [&>button]:!h-16 [&>button]:!flex-col [&>button]:!gap-1.5 [&>button]:!px-1.5">
            <SecondaryButton
              fullWidth
              onClick={() => onToggleMyList(item)}
              icon={
                item.isInMyList ? (
                  <Check className="w-4 h-4 text-[#00C781]" />
                ) : (
                  <Plus className="w-4 h-4" />
                )
              }
              size="sm"
            >
              Mi Lista
            </SecondaryButton>

            <SecondaryButton
              fullWidth
              onClick={handleShare}
              icon={<Share2 className="w-4 h-4" />}
              size="sm"
            >
              Compartir
            </SecondaryButton>
          </div>
        </div>

              {/* Synopsis & Editorial Metadata */}
      <div className="mb-5">
        <h3 className="text-xs uppercase font-bold text-[#A8ADAB] tracking-wider mb-1.5">
          Sinopsis
        </h3>
        <p className="text-sm text-[#C4C8C6] leading-relaxed font-normal">
          {item.synopsis}
        </p>

        <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 border-t border-[#27302C]/70 pt-4">
          <div className="min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Dirección</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.technicalDetails.director}</dd>
          </div>
          <div className="min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Guion</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.editorialReview.author}</dd>
          </div>
          <div className="col-span-2 min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Género</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.genres.join(" · ")}</dd>
          </div>
          <div className="min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Fecha de estreno</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.editorialReview.date}</dd>
          </div>
          <div className="min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Año</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.year}</dd>
          </div>
          <div className="min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Rating IMDb</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.ratingAverage.toFixed(1)} / 10</dd>
          </div>
          <div className="min-w-0">
            <dt className="text-[10px] uppercase tracking-wider text-[#7D8581]">Duración</dt>
            <dd className="mt-0.5 text-xs leading-snug text-[#F5F5F5]">{item.durationOrSeasons}</dd>
          </div>
        </dl>
      </div>

      {/* Series Episodes & Seasons Section */}
        {item.type === 'series' && item.episodes && item.episodes.length > 0 && (
          <section className="mb-6">
            <div className="flex items-center justify-between mb-3 border-b border-[#27302C]/60 pb-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Tv className="w-4 h-4 text-[#00C781]" />
                <span>Episodios</span>
              </h3>

              {/* Season Selector */}
                            <div
                className="relative z-30"
                onKeyDown={(event) => {
                  if (event.key === 'Escape') setIsSeasonOpen(false);
                }}
              >
                <button
                  type="button"
                  onClick={() => setIsSeasonOpen((open) => !open)}
                  className="flex min-h-[40px] items-center gap-2 rounded-lg border border-[#27302C] bg-[#151917] px-3 py-1 text-xs font-bold text-white transition-colors hover:border-[#00C781]/60 hover:bg-[#1B211E] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]"
                  aria-label={`Seleccionar temporada: Temporada ${selectedSeason}`}
                  aria-expanded={isSeasonOpen}
                  aria-haspopup="listbox"
                >
                  <span>Temporada {selectedSeason}</span>
                  <ChevronDown className={`h-3.5 w-3.5 text-[#A8ADAB] transition-transform ${isSeasonOpen ? 'rotate-180' : ''}`} />
                </button>

                {isSeasonOpen && (
                  <>
                    <button
                      type="button"
                      className="fixed inset-0 z-20 cursor-default bg-transparent"
                      aria-label="Cerrar selector de temporada"
                      onClick={() => setIsSeasonOpen(false)}
                    />
                    <div
                      role="listbox"
                      aria-label="Temporadas"
                      className="absolute right-0 top-full mt-2 z-30 w-[168px] rounded-xl border border-[#27302C] bg-[#101412] p-1.5 shadow-[0_14px_32px_rgba(0,0,0,0.45)]"
                    >
                      {[1, 2, 3].map((season) => {
                        const isSelected = season === selectedSeason;
                        return (
                          <button
                            key={season}
                            type="button"
                            role="option"
                            aria-selected={isSelected}
                            onClick={() => {
                              setSelectedSeason(season);
                              setIsSeasonOpen(false);
                            }}
                            className={`flex min-h-12 w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left text-sm whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781] ${
                              isSelected
                                ? 'bg-[#151917] font-semibold text-[#F5F5F5]'
                                : 'text-[#C4C8C6] hover:bg-[#151917] hover:text-white'
                            }`}
                          >
                            <span>
                              Temporada {season}
                            </span>
                            {isSelected && <Check className="h-4 w-4 text-[#00C781]" />}
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
</div>

            <div className="space-y-2.5">
              {currentSeasonEpisodes.map((ep) => (
                <EpisodeCard
                  key={ep.id}
                  episode={ep}
                  onPlay={(e) => onPlayMedia(item, e)}
                />
              ))}
            </div>
          </section>
        )}

        {/* Reparto Principal */}
        <section className="mb-6">
          <h3 className="text-sm font-bold text-white mb-3">Reparto Principal</h3>
          <div className="flex gap-3.5 overflow-x-auto no-scrollbar pb-1">
            {item.cast.map((actor) => (
              <div key={actor.id} className="flex flex-col items-center text-center w-20 min-w-[80px]">
                <div className="w-16 h-16 rounded-full overflow-hidden bg-[#151917] border border-[#27302C] mb-1.5 shadow">
                  <img
                    src={actor.avatarUrl}
                    alt={actor.name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-xs font-semibold text-white truncate w-full leading-tight">
                  {actor.name}
                </span>
                <span className="text-[10px] text-[#A8ADAB] truncate w-full leading-tight">
                  {actor.character}
                </span>
              </div>
            ))}
          </div>
        </section>

        
        
        {/* También te puede gustar */}
        {relatedItems.length > 0 && (
          <section className="mb-4">
            <h3 className="text-sm font-bold text-white mb-3">También te puede gustar</h3>
            <div className="grid grid-cols-3 gap-3">
              {relatedItems.map((rel) => (
                <PosterCard
                  key={rel.id}
                  item={rel}
                  size="sm"
                  onClick={onSelectRelatedMedia}
                  onToggleMyList={(i, e) => {
                    e.stopPropagation();
                    onToggleMyList(i);
                  }}
                  className="!w-full !min-w-0"
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
