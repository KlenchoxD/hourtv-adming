import React, { useState, useEffect, useRef } from 'react';
import {
  User,
  Crown,
  Settings,
  Sliders,
  Languages,
  Bell,
  Lock,
  Smartphone,
  LogOut,
  ChevronRight,
  Check,
  Plus,
  ShieldCheck,
  Zap,
  HelpCircle,
  Download,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ArrowUpCircle
} from 'lucide-react';
import { UserProfile, AppUpdateInfo } from '../types';
import { ProfileAvatar } from '../../ProfileAvatar';
import { ModalSheet } from '../components/common/ModalSheet';
import { PrimaryButton, SecondaryButton } from '../components/common/Buttons';

type UpdateCheckStatus = 'idle' | 'checking' | 'up_to_date' | 'error';

interface ProfileViewProps {
  userProfile: UserProfile;
  profiles: UserProfile[];
  updateInfo: AppUpdateInfo;
  isUpdating: boolean;
  updateProgress: number;
  onCheckUpdates: (showLoading?: boolean) => Promise<any>;
  onExecuteUpdate: () => Promise<any>;
  onUpdateProfile: (updated: UserProfile) => void;
  onSwitchProfile: (profile: UserProfile) => void;
  onManageProfiles: () => void;
  onLogout: () => void;
  onShowSnackbar: (msg: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userProfile,
  profiles,
  updateInfo,
  isUpdating,
  updateProgress,
  onCheckUpdates,
  onExecuteUpdate,
  onUpdateProfile,
  onSwitchProfile,
  onManageProfiles,
  onLogout,
  onShowSnackbar
}) => {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [updateCheckStatus, setUpdateCheckStatus] = useState<UpdateCheckStatus>('idle');
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [streamQuality, setStreamQuality] = useState(userProfile.streamQualityPreference);
  const [dataSaver, setDataSaver] = useState(userProfile.dataSaverCellular);
  const [notifications, setNotifications] = useState(userProfile.notificationsEnabled);
  const [parentalLock, setParentalLock] = useState(userProfile.parentalControlEnabled);
  const [parentalPin, setParentalPin] = useState(userProfile.parentalPin);
  const [isLogoutConfirmOpen, setIsLogoutConfirmOpen] = useState(false);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const handleSavePlaybackSettings = () => {
    onUpdateProfile({
      ...userProfile,
      streamQualityPreference: streamQuality,
      dataSaverCellular: dataSaver
    });
    setActiveModal(null);
    onShowSnackbar('Preferencias de reproducción actualizadas correctamente.');
  };

  const handleManualCheck = async () => {
    if (updateCheckStatus === 'checking') return;
    if (timerRef.current) clearTimeout(timerRef.current);
    setUpdateCheckStatus('checking');

    try {
      const res = await onCheckUpdates(true);
      if (res?.hasUpdate) {
        setUpdateCheckStatus('idle');
      } else {
        setUpdateCheckStatus('up_to_date');
        timerRef.current = setTimeout(() => {
          setUpdateCheckStatus('idle');
        }, 2200);
      }
    } catch {
      setUpdateCheckStatus('error');
      timerRef.current = setTimeout(() => {
        setUpdateCheckStatus('idle');
      }, 2500);
    }
  };

  const handlePerformUpdate = async () => {
    try {
      const newVersion = await onExecuteUpdate();
      onShowSnackbar(`¡HourTV actualizado con éxito a la versión ${newVersion}!`);
    } catch {
      onShowSnackbar('Error al aplicar la actualización. Inténtalo de nuevo.');
    }
  };

  const handleToggleParental = () => {
    const nextState = !parentalLock;
    setParentalLock(nextState);
    onUpdateProfile({
      ...userProfile,
      parentalControlEnabled: nextState
    });
    onShowSnackbar(
      nextState
        ? 'Control parental activado con PIN de seguridad.'
        : 'Control parental desactivado.'
    );
  };

  return (
    <>
      <div className="flex-1 pb-16 text-[#F5F5F5] select-none bg-[#080A09] animate-screen-enter">
      {/* Profile Header */}
      <div className="px-5 pt-4 pb-6 bg-gradient-to-b from-[#101412] to-[#080A09] border-b border-[#27302C]/60">
        {/* User Card */}
        <div className="flex items-center gap-4 mb-4">
          <ProfileAvatar
            avatarId={userProfile.avatarId}
            name={userProfile.name}
            size={64}
            selected
          />

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black text-white truncate">{userProfile.name}</h1>
              <span className="px-2 py-0.5 rounded-full bg-[#00C781]/20 text-[#00C781] text-[10px] font-mono font-bold border border-[#00C781]/40">
                {userProfile.isPrimary ? 'Principal' : userProfile.isKids ? 'Infantil' : 'Perfil'}
              </span>
            </div>
            <p className="text-xs text-[#A8ADAB] truncate mt-0.5">{userProfile.email}</p>
            <div className="flex items-center gap-1 text-xs text-[#00C781] font-semibold mt-1">
              <Crown className="w-3.5 h-3.5" />
              <span>{userProfile.planName}</span>
            </div>
          </div>
        </div>

        {/* Switch Profiles Avatars */}
        <div className="mt-4 pt-3 border-t border-[#27302C]/60">
          <span className="text-xs font-bold text-[#A8ADAB] uppercase tracking-wider block mb-2">
            Cambiar Perfil
          </span>
          <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
            {profiles.map((prof) => {
              const isCurrent = prof.id === userProfile.id;
              return (
                <button
                  key={prof.id}
                  type="button"
                  onClick={() => onSwitchProfile(prof)}
                  className={`flex flex-col items-center gap-1.5 p-1 rounded-xl transition-transform active:scale-95 min-w-[54px] ${
                    isCurrent ? 'opacity-100' : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <ProfileAvatar
                    avatarId={prof.avatarId}
                    name={prof.name}
                    size={44}
                    selected={isCurrent}
                    className="rounded-xl"
                  />
                  <span className={`text-[11px] truncate max-w-[65px] ${isCurrent ? 'text-white font-bold' : 'text-[#A8ADAB]'}`}>
                    {prof.name}
                  </span>
                </button>
              );
            })}

            <button
              type="button"
              onClick={onManageProfiles}
              className="flex flex-col items-center gap-1.5 p-1 text-[#A8ADAB] hover:text-white transition-opacity active:scale-95 min-w-[54px]"
            >
              <div className="w-12 h-12 rounded-xl bg-[#151917] border border-dashed border-[#27302C] flex items-center justify-center">
                <Plus className="w-4 h-4" />
              </div>
              <span className="text-[11px]">Administrar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Settings Groups */}
      <div className="px-4 py-4 space-y-4">
        {/* Grupo 0: Aplicación y Sistema */}
        <div className="bg-[#101412] rounded-2xl border border-[#27302C] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#27302C]/60 flex items-center gap-2 text-xs font-bold text-[#00C781] uppercase tracking-wider">
            <Smartphone className="w-4 h-4" />
            <span>Aplicación y Sistema</span>
          </div>

          <div className="divide-y divide-[#27302C]/40">
            <button
              type="button"
              onClick={() => setActiveModal('app_update')}
              className="w-full px-4 py-3.5 flex items-center justify-between text-left hover:bg-[#151917] transition-colors active:bg-[#101412] min-h-[48px]"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-white block">Actualización de la app</span>
                  <span className="text-[11px] text-[#A8ADAB] block truncate">
                    {updateInfo.hasUpdate
                      ? `Versión ${updateInfo.currentVersion} · Nueva ${updateInfo.latestVersion}`
                      : `Versión ${updateInfo.currentVersion} · Al día`}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0 ml-3">
                {updateInfo.hasUpdate ? (
                  <span className="text-xs font-semibold text-[#00C781]">
                    Disponible
                  </span>
                ) : null}
                <ChevronRight className="w-4 h-4 text-[#A8ADAB]" />
              </div>
            </button>
          </div>
        </div>

        {/* Grupo 1: Reproducción y Calidad */}
        <div className="bg-[#101412] rounded-2xl border border-[#27302C] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#27302C]/60 flex items-center gap-2 text-xs font-bold text-[#00C781] uppercase tracking-wider">
            <Sliders className="w-4 h-4" />
            <span>Reproducción y Calidad de Video</span>
          </div>

          <div className="divide-y divide-[#27302C]/40">
            <button
              type="button"
              onClick={() => setActiveModal('playback')}
              className="w-full px-4 py-3.5 flex items-center justify-between text-left hover:bg-[#151917] transition-colors active:bg-[#101412] min-h-[48px]"
            >
              <div>
                <span className="text-xs font-semibold text-white block">Calidad de Streaming</span>
                <span className="text-[11px] text-[#A8ADAB]">{userProfile.streamQualityPreference} (Ultra HD 4K)</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#A8ADAB]" />
            </button>

            <div className="px-4 py-3.5 flex items-center justify-between min-h-[48px]">
              <div>
                <span className="text-xs font-semibold text-white block">Ahorro de datos en redes móviles</span>
                <span className="text-[11px] text-[#A8ADAB]">Limita el consumo a 720p en red celular</span>
              </div>
              <button
                type="button"
                onClick={() => setDataSaver(!dataSaver)}
                className={`w-12 h-7 rounded-full transition-colors relative ${
                  dataSaver ? 'bg-[#00C781]' : 'bg-[#27302C]'
                }`}
                aria-label="Alternar ahorro de datos móviles"
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-1 ${
                    dataSaver ? 'left-6' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Grupo 2: Idioma y Subtítulos */}
        <div className="bg-[#101412] rounded-2xl border border-[#27302C] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#27302C]/60 flex items-center gap-2 text-xs font-bold text-[#00C781] uppercase tracking-wider">
            <Languages className="w-4 h-4" />
            <span>Idioma y Audio</span>
          </div>

          <div className="divide-y divide-[#27302C]/40">
            <div className="px-4 py-3.5 flex items-center justify-between min-h-[48px]">
              <div>
                <span className="text-xs font-semibold text-white block">Audio predeterminado</span>
                <span className="text-[11px] text-[#A8ADAB]">{userProfile.audioLanguagePreference}</span>
              </div>
              <span className="text-xs text-[#00C781] font-bold">Activo</span>
            </div>

            <div className="px-4 py-3.5 flex items-center justify-between min-h-[48px]">
              <div>
                <span className="text-xs font-semibold text-white block">Subtítulos automáticos</span>
                <span className="text-[11px] text-[#A8ADAB]">Español [CC] con fondo semi-transparente</span>
              </div>
              <span className="text-xs text-[#A8ADAB]">Configurado</span>
            </div>
          </div>
        </div>

        {/* Grupo 3: Notificaciones y Control Parental */}
        <div className="bg-[#101412] rounded-2xl border border-[#27302C] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#27302C]/60 flex items-center gap-2 text-xs font-bold text-[#00C781] uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            <span>Seguridad y Notificaciones</span>
          </div>

          <div className="divide-y divide-[#27302C]/40">
            <div className="px-4 py-3.5 flex items-center justify-between min-h-[48px]">
              <div>
                <span className="text-xs font-semibold text-white block">Notificaciones de nuevos estrenos</span>
                <span className="text-[11px] text-[#A8ADAB]">Avisos de episodios de series seguidas</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  const nextNotifications = !notifications;
                  setNotifications(nextNotifications);
                  onUpdateProfile({ ...userProfile, notificationsEnabled: nextNotifications });
                }}
                className={`w-12 h-7 rounded-full transition-colors relative ${
                  notifications ? 'bg-[#00C781]' : 'bg-[#27302C]'
                }`}
                aria-label="Alternar notificaciones de estrenos"
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-1 ${
                    notifications ? 'left-6' : 'left-1'
                  }`}
                />
              </button>
            </div>

            <div className="px-4 py-3.5 flex items-center justify-between min-h-[48px]">
              <div>
                <span className="text-xs font-semibold text-white block">Control Parental (PIN +18)</span>
                <span className="text-[11px] text-[#A8ADAB]">Solicitar PIN de 4 dígitos para títulos restringidos</span>
              </div>
              <button
                type="button"
                onClick={handleToggleParental}
                className={`w-12 h-7 rounded-full transition-colors relative ${
                  parentalLock ? 'bg-[#00C781]' : 'bg-[#27302C]'
                }`}
                aria-label="Alternar control parental"
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-1 ${
                    parentalLock ? 'left-6' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Grupo 4: Dispositivos y Cierre */}
        <div className="space-y-2.5 pt-2">
          <button
            type="button"
            onClick={() => setIsLogoutConfirmOpen(true)}
            className="w-full p-3.5 rounded-xl bg-[#151917] border border-[#27302C] hover:border-[#EF4444]/60 text-[#EF4444] text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.99] min-h-[48px]"
          >
            <LogOut className="w-4 h-4" />
            <span>Cerrar sesión en este dispositivo Android</span>
          </button>

          <div className="text-center text-[10px] text-[#A8ADAB] pt-2">
            HourTV Android App v{updateInfo.currentVersion} • Build {updateInfo.buildNumber} • Google Play Services
          </div>
        </div>
      </div>
    </div>

      {/* Modal Sheets & Overlays (Rendered outside animate-screen-enter container) */}
      <ModalSheet
        isOpen={activeModal === 'app_update'}
        onClose={() => {
          if (!isUpdating) setActiveModal(null);
        }}
        title="Actualización de la app"
      >
        <div className="space-y-3">
          {updateInfo.hasUpdate ? (
            /* Update Pending Section */
            <div className="space-y-3">
              {/* Version & Size Info */}
              <div className="p-3.5 rounded-xl bg-[#151917] border border-[#27302C] flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">
                    Nueva versión {updateInfo.latestVersion}
                  </span>
                  <span className="text-xs text-[#A8ADAB] mt-0.5 block">
                    Instalada actualmente: v{updateInfo.currentVersion}
                  </span>
                </div>
                <span className="text-xs text-[#00C781] font-mono font-bold bg-[#00C781]/15 px-2.5 py-1 rounded-md border border-[#00C781]/30">
                  {updateInfo.sizeMB} MB
                </span>
              </div>

              {/* Release Notes */}
              <div className="p-3.5 rounded-xl bg-[#101412] border border-[#27302C] space-y-1.5">
                <span className="text-[11px] font-bold text-[#00C781] uppercase tracking-wider block">
                  Novedades del paquete
                </span>
                <ul className="space-y-1.5 text-xs text-[#C4C8C6]">
                  {updateInfo.releaseNotes.map((note, index) => (
                    <li key={index} className="flex items-start gap-2 leading-relaxed">
                      <span className="text-[#00C781] leading-none select-none mt-0.5">•</span>
                      <span>{note}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Download / Progress Bar when updating */}
              {isUpdating && (
                <div className="p-3 rounded-xl bg-[#101412] border border-[#00C781]/40 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 text-[#00C781] animate-spin" />
                      {updateProgress < 100 ? 'Descargando paquete...' : 'Instalando componentes...'}
                    </span>
                    <span className="font-mono text-[#00C781] font-bold text-sm">{updateProgress}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-[#151917] overflow-hidden border border-[#27302C]">
                    <div
                      className="h-full bg-[#00C781] transition-all duration-200"
                      style={{ width: `${updateProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                <PrimaryButton
                  fullWidth
                  size="md"
                  onClick={handlePerformUpdate}
                  disabled={isUpdating}
                >
                  <div className="flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" />
                    <span>{isUpdating ? 'Actualizando paquete...' : 'Actualizar ahora'}</span>
                  </div>
                </PrimaryButton>

                {!isUpdating && (
                  <button
                    type="button"
                    onClick={() => setActiveModal(null)}
                    className="w-full py-2 text-xs text-[#A8ADAB] hover:text-white font-medium transition-colors text-center"
                  >
                    Ahora no
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Already Updated Section */
            <div className="space-y-4 text-center py-2">
              <div className="w-12 h-12 rounded-full bg-[#00C781]/15 border border-[#00C781]/30 flex items-center justify-center text-[#00C781] mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white">Tu aplicación está al día</h3>
                <p className="text-xs text-[#A8ADAB]">
                  Versión instalada: v{updateInfo.currentVersion} • Última versión oficial
                </p>
              </div>

              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={handleManualCheck}
                  disabled={updateCheckStatus === 'checking' || updateCheckStatus === 'up_to_date'}
                  className={`w-full min-h-[44px] py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all duration-200 active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781] ${
                    updateCheckStatus === 'up_to_date'
                      ? 'bg-[#00C781]/15 text-[#00C781] border border-[#00C781]/40'
                      : updateCheckStatus === 'error'
                      ? 'bg-[#FBBF24]/10 text-[#FBBF24] border border-[#FBBF24]/40 hover:bg-[#FBBF24]/20'
                      : updateCheckStatus === 'checking'
                      ? 'bg-[#151917] text-[#A8ADAB] border border-[#27302C] opacity-80 cursor-not-allowed'
                      : 'bg-[#151917] text-[#F5F5F5] hover:text-white hover:bg-[#202724] border border-[#27302C]'
                  }`}
                >
                  {updateCheckStatus === 'checking' && (
                    <>
                      <RefreshCw className="w-4 h-4 text-[#00C781] animate-spin flex-shrink-0" />
                      <span>Buscando actualizaciones...</span>
                    </>
                  )}
                  {updateCheckStatus === 'up_to_date' && (
                    <>
                      <Check className="w-4 h-4 text-[#00C781] flex-shrink-0" />
                      <span>Ya tienes la última versión</span>
                    </>
                  )}
                  {updateCheckStatus === 'error' && (
                    <>
                      <AlertTriangle className="w-4 h-4 text-[#FBBF24] flex-shrink-0" />
                      <span>Error al comprobar • Reintentar</span>
                    </>
                  )}
                  {updateCheckStatus === 'idle' && (
                    <>
                      <RefreshCw className="w-4 h-4 text-[#C4C8C6] flex-shrink-0" />
                      <span>Buscar actualizaciones</span>
                    </>
                  )}
                </button>

                <PrimaryButton
                  fullWidth
                  size="md"
                  onClick={() => {
                    setUpdateCheckStatus('idle');
                    setActiveModal(null);
                  }}
                >
                  Entendido
                </PrimaryButton>
              </div>
            </div>
          )}
        </div>
      </ModalSheet>

      {/* Modal Sheet for Quality Settings */}
      <ModalSheet
        isOpen={activeModal === 'playback'}
        onClose={() => setActiveModal(null)}
        title="Calidad de Streaming"
        subtitle="Resolución predeterminada en Wi-Fi y datos móviles"
      >
        <div className="space-y-2">
          {[
            { id: '4K', label: 'Ultra HD 4K (Máxima fidelidad)', desc: 'Hasta 25 Mbps en HDR10+ y Dolby Vision' },
            { id: '1080p', label: 'Full HD 1080p (Recomendada)', desc: 'Excelente equilibrio de calidad y consumo' },
            { id: 'Auto', label: 'Automática Adaptativa', desc: 'Ajusta la calidad según la velocidad de red' },
            { id: 'Ahorro de datos', label: 'Ahorro de Datos (720p)', desc: 'Ideal para conexiones móviles limitadas' }
          ].map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setStreamQuality(opt.id as any)}
              className={`w-full p-3 rounded-xl border flex items-center justify-between text-left transition-all duration-120 active:scale-[0.99] ${
                streamQuality === opt.id
                  ? 'bg-[#151917] border-[#00C781] text-white shadow-sm'
                  : 'bg-[#101412] border-[#27302C] text-[#C4C8C6] hover:border-[#38443F]'
              }`}
            >
              <div>
                <span className="text-xs sm:text-sm font-bold block text-white">{opt.label}</span>
                <span className="text-[11px] text-[#A8ADAB] mt-0.5 block">{opt.desc}</span>
              </div>
              {streamQuality === opt.id && <Check className="w-4 h-4 text-[#00C781] flex-shrink-0 ml-2" />}
            </button>
          ))}

          <div className="pt-2">
            <PrimaryButton fullWidth size="md" onClick={handleSavePlaybackSettings}>
              Guardar preferencias
            </PrimaryButton>
          </div>
        </div>
      </ModalSheet>

      {/* Logout Confirmation Dialog */}
      {isLogoutConfirmOpen && (
        <ModalSheet
          isOpen={isLogoutConfirmOpen}
          onClose={() => setIsLogoutConfirmOpen(false)}
          title="Cerrar sesión"
        >
          <div className="space-y-4 text-center py-2">
            <div className="w-12 h-12 rounded-full bg-[#1E1414] border border-[#7F1D1D]/40 flex items-center justify-center text-[#EF4444] mx-auto">
              <LogOut className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">¿Deseas cerrar tu sesión?</h3>
              <p className="text-xs text-[#A8ADAB]">
                Tendrás que volver a ingresar tus credenciales para acceder a tu perfil y contenido guardado.
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <SecondaryButton fullWidth size="md" onClick={() => setIsLogoutConfirmOpen(false)}>
                Cancelar
              </SecondaryButton>
              <PrimaryButton
                fullWidth
                size="md"
                variant="danger"
                onClick={() => {
                  setIsLogoutConfirmOpen(false);
                  onLogout();
                }}
              >
                Salir
              </PrimaryButton>
            </div>
          </div>
        </ModalSheet>
      )}
    </>
  );
};

