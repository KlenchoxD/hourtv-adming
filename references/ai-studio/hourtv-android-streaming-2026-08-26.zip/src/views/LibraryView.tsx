import React, { useState, useMemo } from 'react';
import {
  Bookmark,
  ArrowUpDown,
  ChevronDown,
  Check,
  Trash2,
  Play,
  Film,
  Tv,
  CheckCircle2,
  Sparkles,
  History
} from 'lucide-react';
import { MediaItem } from '../types';
import { PrimaryButton } from '../components/common/Buttons';
import { EmptyState } from '../components/common/SystemStates';

interface LibraryViewProps {
  myList: MediaItem[];
  allMedia: MediaItem[];
  onSelectMedia: (item: MediaItem) => void;
  onPlayMedia: (item: MediaItem) => void;
  onRemoveFromMyList: (item: MediaItem) => void;
  onExploreCatalog: () => void;
  onShowSnackbarWithUndo: (removedItem: MediaItem) => void;
}

const SORT_OPTIONS = [
  { value: 'recent', label: 'Más recientes' },
  { value: 'oldest', label: 'Más antiguas' },
  { value: 'az', label: 'Orden A–Z' },
] as const;

export const LibraryView: React.FC<LibraryViewProps> = ({
  myList,
  onSelectMedia,
  onPlayMedia,
  onRemoveFromMyList,
  onExploreCatalog,
  onShowSnackbarWithUndo
}) => {
  const [activeTab, setActiveTab] = useState<'my_list' | 'continue' | 'history'>('my_list');
  const [contentTypeFilter, setContentTypeFilter] = useState<'all' | 'movie' | 'series'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'oldest' | 'az'>('recent');
  const [isSortOpen, setIsSortOpen] = useState(false);

  // Filter and Sort active list
  const filteredAndSortedList = useMemo(() => {
    let items = [...myList];

    if (activeTab === 'continue') {
      items = items.filter((i) => i.progressPercentage && i.progressPercentage > 0);
    } else if (activeTab === 'history') {
      items = items.slice(0, 4);
    }

    // Apply content type filter
    if (contentTypeFilter === 'movie') {
      items = items.filter((i) => i.type === 'movie');
    } else if (contentTypeFilter === 'series') {
      items = items.filter((i) => i.type === 'series');
    }

    // Apply sorting
    if (sortBy === 'recent') {
      items.sort((a, b) => new Date(b.releaseDateISO).getTime() - new Date(a.releaseDateISO).getTime());
    } else if (sortBy === 'oldest') {
      items.sort((a, b) => new Date(a.releaseDateISO).getTime() - new Date(b.releaseDateISO).getTime());
    } else if (sortBy === 'az') {
      items.sort((a, b) => a.title.localeCompare(b.title));
    }

    return items;
  }, [myList, activeTab, contentTypeFilter, sortBy]);

  const handleDeleteItem = (item: MediaItem, e: React.MouseEvent) => {
    e.stopPropagation();
    onRemoveFromMyList(item);
    onShowSnackbarWithUndo(item);
  };

  return (
    <div className="flex-1 pb-16 text-[#F5F5F5] select-none animate-screen-enter">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#080A09]/95 backdrop-blur-md px-4 pt-3 pb-2 border-b border-[#27302C]/60">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-[#00C781]" />
            <h1 className="text-xl font-black text-white tracking-tight">Mi Biblioteca</h1>
          </div>
          <span className="text-xs font-mono font-bold text-[#00C781] bg-[#00C781]/15 px-2.5 py-1 rounded-full">
            {filteredAndSortedList.length} títulos
          </span>
        </div>

        {/* Section Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            { id: 'my_list', label: 'Mi Lista', icon: Bookmark },
            { id: 'continue', label: 'Continuar Viendo', icon: Play },
            { id: 'history', label: 'Historial', icon: History }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-120 active:scale-95 min-h-[44px] ${
                  isActive
                    ? 'bg-[#00C781] text-[#050505] font-bold shadow-sm'
                    : 'bg-[#151917] text-[#C4C8C6] border border-[#27302C] hover:border-[#38443F]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter & Sort Controls Toolbar */}
      <div className="px-4 py-3 bg-[#101412]/60 border-b border-[#27302C]/40 flex items-center justify-between gap-2 flex-wrap">
        {/* Type Filter Pills */}
        <div className="flex items-center gap-1.5">
          {[
            { id: 'all', label: 'Todo' },
            { id: 'movie', label: 'Películas' },
            { id: 'series', label: 'Series' }
          ].map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setContentTypeFilter(f.id as any)}
              className={`px-3 py-2 rounded-full text-xs font-semibold transition-all duration-120 active:scale-95 min-h-[40px] flex items-center ${
                contentTypeFilter === f.id
                  ? 'bg-[#27302C] text-[#00C781] font-bold border border-[#00C781]/40'
                  : 'bg-[#151917] text-[#A8ADAB] border border-[#27302C] hover:border-[#00C781]/50 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Real Functional Sort Selector */}
        <div
          className="relative"
          onKeyDown={(event) => {
            if (event.key === 'Escape') setIsSortOpen(false);
          }}
        >
          <button
            type="button"
            onClick={() => setIsSortOpen((open) => !open)}
            className="flex min-h-[40px] items-center gap-1.5 rounded-full border border-[#27302C] bg-[#151917] px-2.5 py-1 text-xs font-semibold text-[#F5F5F5] transition-all duration-120 active:scale-95 hover:border-[#00C781]/60 hover:bg-[#1B211E] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781]"
            aria-label={`Ordenar biblioteca: ${SORT_OPTIONS.find((option) => option.value === sortBy)?.label}`}
            aria-expanded={isSortOpen}
            aria-haspopup="listbox"
          >
            <ArrowUpDown className="h-3.5 w-3.5 text-[#00C781]" />
            <span>{SORT_OPTIONS.find((option) => option.value === sortBy)?.label}</span>
            <ChevronDown className={`h-3.5 w-3.5 text-[#A8ADAB] transition-transform ${isSortOpen ? 'rotate-180' : ''}`} />
          </button>

          {isSortOpen && (
            <>
              <button
                type="button"
                className="fixed inset-0 z-20 cursor-default bg-transparent"
                aria-label="Cerrar opciones de orden"
                onClick={() => setIsSortOpen(false)}
              />
              <div
                role="listbox"
                aria-label="Opciones de orden"
                className="absolute right-0 top-[calc(100%+8px)] z-30 min-w-[174px] rounded-xl border border-[#27302C] bg-[#101412] p-1.5 shadow-[0_14px_32px_rgba(0,0,0,0.45)] animate-screen-enter"
              >
                {SORT_OPTIONS.map((option) => {
                  const isSelected = option.value === sortBy;
                  return (
                    <button
                      key={option.value}
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      onClick={() => {
                        setSortBy(option.value);
                        setIsSortOpen(false);
                      }}
                      className={`flex min-h-12 w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00C781] ${
                        isSelected
                          ? 'bg-[#151917] font-semibold text-[#F5F5F5]'
                          : 'text-[#C4C8C6] hover:bg-[#151917] hover:text-white'
                      }`}
                    >
                      <span>{option.label}</span>
                      {isSelected && <Check className="h-4 w-4 text-[#00C781]" />}
                    </button>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Library Grid or Empty State */}
      <div className="px-4 py-4">
        {filteredAndSortedList.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {filteredAndSortedList.map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectMedia(item)}
                className="group relative flex flex-col rounded-xl bg-[#101412] border border-[#27302C] overflow-hidden cursor-pointer active:scale-[0.98] transition-transform duration-120 hover:border-[#38443F]"
              >
                {/* Poster container */}
                <div className="relative aspect-[2/3] w-full bg-[#080A09] overflow-hidden">
                  <img
                    src={item.posterUrl}
                    alt={item.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-250"
                  />

                  {/* Play overlay */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayMedia(item);
                    }}
                    className="absolute inset-0 m-auto w-12 h-12 min-w-[48px] min-h-[48px] rounded-full bg-[#00C781] text-[#050505] flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-150 active:scale-95"
                    aria-label={`Reproducir ${item.title}`}
                  >
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </button>

                  {/* Delete button from list */}
                  <button
                    type="button"
                    onClick={(e) => handleDeleteItem(item, e)}
                    className="absolute top-1.5 right-1.5 w-9 h-9 min-w-[36px] min-h-[36px] rounded-full bg-[#050505]/80 backdrop-blur-sm border border-[#27302C] text-[#A8ADAB] hover:text-[#EF4444] hover:border-[#EF4444]/60 flex items-center justify-center transition-all duration-120 shadow active:scale-90"
                    aria-label={`Eliminar ${item.title} de Mi Lista`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  {/* Badges */}
                  <div className="absolute top-1.5 left-1.5">
                    {item.isOriginal && (
                      <span className="px-1.5 py-0.5 rounded bg-[#00C781] text-black text-[9px] font-black uppercase">
                        Original
                      </span>
                    )}
                  </div>

                  {/* Progress bar if continue */}
                  {item.progressPercentage && item.progressPercentage > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#151917]">
                      <div
                        className="h-full bg-[#00C781] transition-all duration-200"
                        style={{ width: `${item.progressPercentage}%` }}
                      />
                    </div>
                  )}
                </div>

                {/* Details Footer */}
                <div className="p-2.5">
                  <h3 className="text-xs font-bold text-[#F5F5F5] truncate">{item.title}</h3>
                  <div className="flex items-center justify-between text-[10px] text-[#A8ADAB] mt-1">
                    <span>{item.year}</span>
                    <span className="font-mono text-[#00C781] font-bold">{item.ageRating}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={<Bookmark className="w-8 h-8 text-[#00C781]" />}
            title="Tu biblioteca está vacía"
            description="Guarda películas, series y documentales en 'Mi Lista' para acceder rápidamente a ellos en cualquier momento."
            actionLabel="Explorar catálogo de estrenos"
            onAction={onExploreCatalog}
          />
        )}
      </div>
    </div>
  );
};

