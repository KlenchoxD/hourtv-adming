import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, CheckCircle2, AlertCircle, ArrowRight, Sparkles } from 'lucide-react';
import { HourTVLogo } from '../components/common/HourTVLogo';
import { PrimaryButton, SecondaryButton } from '../components/common/Buttons';
import { UserProfile } from '../types';

interface AccessViewProps {
  onLoginSuccess: (profile?: UserProfile) => void;
  onShowSnackbar: (msg: string) => void;
}

export const AccessView: React.FC<AccessViewProps> = ({
  onLoginSuccess,
  onShowSnackbar
}) => {
  const [email, setEmail] = useState('renata.m@hourtv.app');
  const [password, setPassword] = useState('hourtv2026');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [emailTouched, setEmailTouched] = useState(false);

  const isEmailValid = email.includes('@') && email.includes('.');
  const isPasswordValid = password.length >= 6;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEmailValid) {
      setErrorMsg('Introduce un correo electrónico válido.');
      return;
    }
    if (!isPasswordValid) {
      setErrorMsg('La contraseña debe tener al menos 6 caracteres.');
      return;
    }

    setErrorMsg('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
      onShowSnackbar('¡Sesión iniciada con éxito! Bienvenido a HourTV.');
    }, 900);
  };

  const handleQuickDemoLogin = () => {
    setEmail('renata.m@hourtv.app');
    setPassword('hourtv2026');
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
      onShowSnackbar('Acceso demo autorizado para Renata.');
    }, 600);
  };

  return (
    <div className="flex-1 flex flex-col justify-between px-6 py-8 text-[#F5F5F5] select-none bg-[#080A09] min-h-[85vh] animate-in fade-in duration-200">
      {/* Brand Header */}
      <div className="flex flex-col items-center text-center mt-4">
        <HourTVLogo size="lg" showTagline />
        <h1 className="text-xl font-bold text-white mt-6 mb-1 tracking-tight">
          Inicia sesión en tu cuenta
        </h1>
        <p className="text-xs text-[#A8ADAB] max-w-xs">
          Accede a estrenos exclusivos en 4K UHD, tus listas guardadas y TV en vivo.
        </p>
      </div>

      {/* Form Container */}
      <form onSubmit={handleSubmit} className="w-full max-w-sm mx-auto space-y-4 my-6">
        {errorMsg && (
          <div className="p-3 rounded-xl bg-[#1E1414] border border-[#7F1D1D]/60 text-[#EF4444] text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Email Field */}
        <div>
          <label className="block text-xs font-bold text-[#C4C8C6] uppercase tracking-wider mb-1.5">
            Correo Electrónico
          </label>
          <div className="relative">
            <div className="absolute left-3.5 top-3.5 text-[#A8ADAB]">
              <Mail className="w-5 h-5" />
            </div>
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setEmailTouched(true);
                setErrorMsg('');
              }}
              placeholder="ejemplo@correo.com"
              className={`w-full h-12 pl-11 pr-10 rounded-xl bg-[#151917] border text-sm text-[#F5F5F5] placeholder-[#A8ADAB] focus:outline-none transition-all ${
                emailTouched && !isEmailValid
                  ? 'border-[#EF4444] focus:ring-2 focus:ring-[#EF4444]/30'
                  : 'border-[#27302C] focus:border-[#00C781] focus:ring-2 focus:ring-[#00C781]/20'
              }`}
            />
            {emailTouched && isEmailValid && (
              <div className="absolute right-3.5 top-3.5 text-[#00C781]">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            )}
          </div>
        </div>

        {/* Password Field */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-[#C4C8C6] uppercase tracking-wider">
              Contraseña
            </label>
            <button
              type="button"
              onClick={() => onShowSnackbar('Se envió un enlace de recuperación a tu correo.')}
              className="text-xs text-[#00C781] hover:underline"
            >
              ¿Olvidaste tu clave?
            </button>
          </div>
          <div className="relative">
            <div className="absolute left-3.5 top-3.5 text-[#A8ADAB]">
              <Lock className="w-5 h-5" />
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setErrorMsg('');
              }}
              placeholder="••••••••"
              className="w-full h-12 pl-11 pr-12 rounded-xl bg-[#151917] border border-[#27302C] text-sm text-[#F5F5F5] placeholder-[#A8ADAB] focus:outline-none focus:border-[#00C781] focus:ring-2 focus:ring-[#00C781]/20 transition-all font-mono"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-3 w-7 h-7 rounded-full flex items-center justify-center text-[#A8ADAB] hover:text-white"
              aria-label={showPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5 pt-2">
          <PrimaryButton
            fullWidth
            type="submit"
            isLoading={isLoading}
            icon={<ArrowRight className="w-4 h-4" />}
            size="lg"
          >
            Iniciar Sesión
          </PrimaryButton>

          <SecondaryButton
            fullWidth
            type="button"
            onClick={handleQuickDemoLogin}
            icon={<Sparkles className="w-4 h-4 text-[#00C781]" />}
            size="md"
          >
            Acceso Rápido Demo (Renata)
          </SecondaryButton>
        </div>
      </form>

      {/* Footer Info */}
      <div className="text-center text-xs text-[#A8ADAB]">
        <p>¿Aún no tienes suscripción HourTV?</p>
        <button
          type="button"
          onClick={handleQuickDemoLogin}
          className="text-[#00C781] font-bold mt-1 hover:underline block mx-auto"
        >
          Probar catálogo de demostración sin cargo
        </button>
      </div>
    </div>
  );
};
