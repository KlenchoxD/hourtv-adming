import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Search, X, History, TrendingUp, Sparkles, Filter, Trash2 } from 'lucide-react';
import { MediaItem } from '../types';
import { PosterCard } from '../components/common/Cards';
import { RECENT_SEARCHES, TRENDING_KEYWORDS } from '../data/mockData';
import {
  filterCatalog,
  initialVisibleCount,
  nextVisibleCount,
  progressiveSlice,
  resetVisibleCount
} from '../../searchProgressiveBehavior.mjs';

interface SearchViewProps {
  mediaItems: MediaItem[];
  onSelectMedia: (item: MediaItem) => void;
  onToggleMyList: (item: MediaItem) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  mediaItems,
  onSelectMedia,
  onToggleMyList
}) => {
  const [query, setQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>(RECENT_SEARCHES);
  const [filterType, setFilterType] = useState<'all' | 'movie' | 'series' | '4k'>('all');
  const [isSearching, setIsSearching] = useState(false);
  const [catalogVisibleCount, setCatalogVisibleCount] = useState(() => initialVisibleCount(mediaItems.length));
  const [resultsVisibleCount, setResultsVisibleCount] = useState(0);
  const loadMoreRef = useRef<HTMLDivElement | null>(null);

  const handleQueryChange = (val: string) => {
    setQuery(val);
  };

  const handleClearQuery = () => {
    setQuery('');
  };

  const handleSelectRecentOrTrending = (text: string) => {
    setQuery(text);
  };

  const handleDeleteRecent = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches((prev) => prev.filter((item) => item !== text));
  };

  const handleClearAllRecents = () => {
    setRecentSearches([]);
  };

  // Filtered results
  const searchResults = useMemo(() => {
    if (!query.trim()) return [];

    return (filterCatalog(mediaItems, query) as MediaItem[]).filter((item) => {
      if (filterType === 'movie') return item.type === 'movie';
      if (filterType === 'series') return item.type === 'series';
      if (filterType === '4k') return item.qualityBadges.some((badge) => badge.toLowerCase().includes('4k'));

      return true;
    });
  }, [query, mediaItems, filterType]);

  const isQueryActive = query.trim().length > 0;
  const activeItems = isQueryActive ? searchResults : mediaItems;
  const activeVisibleCount = isQueryActive ? resultsVisibleCount : catalogVisibleCount;
  const visibleItems = progressiveSlice(activeItems, activeVisibleCount) as MediaItem[];
  const hasMoreItems = visibleItems.length < activeItems.length;

  useEffect(() => {
    if (!isQueryActive) {
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const timer = window.setTimeout(() => setIsSearching(false), 180);
    return () => window.clearTimeout(timer);
  }, [query, filterType, isQueryActive]);

  useEffect(() => {
    if (isQueryActive) {
      setResultsVisibleCount(resetVisibleCount(searchResults.length));
    } else {
      setCatalogVisibleCount(resetVisibleCount(mediaItems.length));
    }
  }, [isQueryActive, query, filterType, searchResults.length, mediaItems.length]);

  useEffect(() => {
    const sentinel = loadMoreRef.current;
    if (!sentinel || !hasMoreItems) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;

        if (isQueryActive) {
          setResultsVisibleCount((current) => nextVisibleCount(current, searchResults.length));
        } else {
          setCatalogVisibleCount((current) => nextVisibleCount(current, mediaItems.length));
        }
      },
      { rootMargin: '180px 0px' }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasMoreItems, isQueryActive, isSearching, searchResults.length, mediaItems.length]);

  return (
    <div className="flex-1 pb-16 text-[#F5F5F5] select-none animate-screen-enter">
      {/* Search Input Bar (Sticky Android Native Input) */}
      <div className="sticky top-0 z-30 bg-[#080A09]/95 backdrop-blur-md px-4 py-3 border-b border-[#27302C]/60">
        <div className="relative flex items-center w-full">
          <div className="absolute left-3.5 flex items-center pointer-events-none text-[#A8ADAB]">
            <Search className="w-5 h-5" />
          </div>

          <input
            type="text"
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            placeholder="Buscar títulos, actores, géneros o directores..."
            className="w-full h-12 pl-11 pr-12 rounded-xl bg-[#151917] border border-[#27302C] text-[#F5F5F5] placeholder-[#A8ADAB] text-sm focus:outline-none focus:border-[#00C781] focus:ring-2 focus:ring-[#00C781]/20 transition-all font-medium"
            autoFocus={false}
          />

          {query && (
            <button
              type="button"
              onClick={handleClearQuery}
              className="absolute right-3 w-7 h-7 rounded-full bg-[#27302C] text-[#F5F5F5] flex items-center justify-center hover:bg-[#38443F] active:scale-90 transition-all duration-120"
              aria-label="Limpiar búsqueda"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter chips when searching */}
        {query.trim().length > 0 && (
          <div className="flex items-center gap-2 mt-2.5 overflow-x-auto no-scrollbar">
            <span className="text-xs text-[#A8ADAB] font-semibold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-[#00C781]" />
            </span>
            {[
              { id: 'all', label: 'Todo' },
              { id: 'movie', label: 'Películas' },
              { id: 'series', label: 'Series' },
              { id: '4k', label: '4K Ultra HD' }
            ].map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilterType(f.id as any)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-120 active:scale-95 ${
                  filterType === f.id
                    ? 'bg-[#00C781] text-[#050505] font-bold'
                    : 'bg-[#101412] text-[#C4C8C6] border border-[#27302C]'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Search Body */}
      <div className="px-4 py-4">
        {/* State 1: Active query with results */}
        {query.trim().length > 0 ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-[#C4C8C6]">
                Resultados para <span className="font-bold text-white">"{query}"</span>
              </p>
              <span className="text-xs font-mono font-bold text-[#00C781] bg-[#00C781]/15 px-2 py-0.5 rounded">
                {searchResults.length} {searchResults.length === 1 ? 'título' : 'títulos'}
              </span>
            </div>

            {isSearching ? (
              <div className="grid grid-cols-3 gap-3">
                {[1, 2, 3, 4, 5, 6].map((idx) => (
                  <div
                    key={idx}
                    className="w-full aspect-[2/3] rounded-xl skeleton-shimmer border border-[#27302C]"
                  />
                ))}
              </div>
            ) : searchResults.length > 0 ? (
              <div className="grid grid-cols-3 gap-3">
                {visibleItems.map((item) => (
                  <PosterCard
                    key={item.id}
                    item={item}
                    size="sm"
                    onClick={onSelectMedia}
                    onToggleMyList={(i, e) => {
                      e.stopPropagation();
                      onToggleMyList(i);
                    }}
                    className="w-full min-w-0"
                  />
                ))}
              </div>
            ) : (
              /* State 2: Sin resultados */
              <div className="flex flex-col items-center justify-center p-8 text-center bg-[#101412]/60 border border-[#27302C] rounded-2xl my-6 animate-screen-enter">
                <div className="w-14 h-14 rounded-full bg-[#151917] border border-[#27302C] flex items-center justify-center text-[#A8ADAB] mb-3">
                  <Search className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white mb-1">
                  No encontramos resultados para "{query}"
                </h3>
                <p className="text-xs text-[#A8ADAB] max-w-xs mb-4">
                  Revisa la ortografía o intenta buscar por directores como "Gabriel Sotomayor" o géneros como "Ciencia Ficción".
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {TRENDING_KEYWORDS.slice(0, 3).map((kw) => (
                    <button
                      key={kw}
                      type="button"
                      onClick={() => setQuery(kw)}
                      className="px-3 py-1.5 rounded-lg bg-[#151917] border border-[#27302C] text-xs font-semibold text-[#00C781] hover:border-[#00C781] active:scale-95 transition-all duration-120"
                    >
                      {kw}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* State 3: Empty query - Show Recents & Trending */
          <div className="space-y-6">
            {/* Recent Searches */}
            {recentSearches.length > 0 && (
              <section>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <History className="w-4 h-4 text-[#00C781]" />
                    <span>Búsquedas recientes</span>
                  </h3>
                  <button
                    type="button"
                    onClick={handleClearAllRecents}
                    className="text-xs text-[#A8ADAB] hover:text-[#EF4444] font-medium active:scale-95 transition-all"
                  >
                    Borrar todo
                  </button>
                </div>

                <div className="space-y-1.5">
                  {recentSearches.map((item) => (
                    <div
                      key={item}
                      onClick={() => handleSelectRecentOrTrending(item)}
                      className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-[#101412] border border-[#27302C]/60 hover:bg-[#151917] hover:border-[#38443F] cursor-pointer active:scale-[0.99] transition-all duration-120"
                    >
                      <div className="flex items-center gap-2.5 text-xs text-[#F5F5F5] font-medium">
                        <History className="w-3.5 h-3.5 text-[#A8ADAB]" />
                        <span>{item}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteRecent(item, e)}
                        className="w-7 h-7 rounded-full flex items-center justify-center text-[#A8ADAB] hover:text-white active:scale-90 transition-transform"
                        aria-label={`Eliminar ${item}`}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Trending Searches */}
            <section>
              <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-[#00C781]" />
                <span>Tendencias de búsqueda</span>
              </h3>

              <div className="flex flex-wrap gap-2">
                {TRENDING_KEYWORDS.map((kw) => (
                  <button
                    key={kw}
                    type="button"
                    onClick={() => handleSelectRecentOrTrending(kw)}
                    className="px-3.5 py-2 rounded-xl bg-[#151917] border border-[#27302C] text-xs font-semibold text-[#F5F5F5] hover:border-[#00C781] hover:text-[#00C781] transition-all duration-120 active:scale-95 flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3 h-3 text-[#00C781]" />
                    <span>{kw}</span>
                  </button>
                ))}
              </div>
            </section>

            {/* Progressive Catalog */}
            <section className="pt-2">
              <div className="mb-3 flex items-end justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white">Explorar todo HourTV</h3>
                  <p className="mt-0.5 text-[11px] text-[#A8ADAB]">Películas, series, novelas y anime</p>
                </div>
                <span className="text-[11px] font-mono font-bold text-[#00C781]">
                  {mediaItems.length} títulos
                </span>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {visibleItems.map((item) => (
                  <PosterCard
                    key={item.id}
                    item={item}
                    size="sm"
                    onClick={onSelectMedia}
                    onToggleMyList={(i, e) => {
                      e.stopPropagation();
                      onToggleMyList(i);
                    }}
                    className="w-full min-w-0"
                  />
                ))}
              </div>
            </section>
          </div>
        )}

        {hasMoreItems && !isSearching && (
          <div
            ref={loadMoreRef}
            className="flex min-h-14 items-center justify-center pt-3 text-[11px] font-semibold text-[#7F8783]"
            aria-label="Cargar más títulos"
          >
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#27302C] border-t-[#00C781]" />
          </div>
        )}
      </div>
    </div>
  );
};
