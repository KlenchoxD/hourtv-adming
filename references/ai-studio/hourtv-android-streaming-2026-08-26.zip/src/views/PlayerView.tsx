import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Sliders,
  MessageSquare,
  FastForward,
  SkipForward,
  Check,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Layers
} from 'lucide-react';
import { MediaItem, Episode } from '../types';
import { ModalSheet } from '../components/common/ModalSheet';
import { PrimaryButton, SecondaryButton } from '../components/common/Buttons';
import {
  cancelNextEpisodeCountdown,
  createNextEpisodeCountdown,
  getSkipAction,
  shouldShowNextEpisode,
  tickNextEpisodeCountdown,
} from '../playerBehavior';

interface PlayerViewProps {
  item: MediaItem;
  episode?: Episode;
  onBack: () => void;
  onNextEpisode?: () => void;
  onShowSnackbar: (msg: string) => void;
}

export const PlayerView: React.FC<PlayerViewProps> = ({
  item,
  episode,
  onBack,
  onNextEpisode,
  onShowSnackbar
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(() => (episode ? 8 : 342));
  const totalDurationSec = episode ? episode.durationMinutes * 60 : 138 * 60; // default 2h 18m
  const [isControlsVisible, setIsControlsVisible] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [activeSheet, setActiveSheet] = useState<'audio_subs' | 'quality' | null>(null);

  // Tracks State
  const [selectedAudio, setSelectedAudio] = useState<string>('Español (Latino) [Dolby Atmos]');
  const [selectedSub, setSelectedSub] = useState<string>('Desactivados');
  const [selectedQuality, setSelectedQuality] = useState<string>('4K Ultra HD (HDR10+)');

  // Simulation controls
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [isPlaybackError, setIsPlaybackError] = useState<boolean>(false);
  const [skippedRecap, setSkippedRecap] = useState<boolean>(false);
  const [skippedIntro, setSkippedIntro] = useState<boolean>(false);
  const [nextEpisodeCountdown, setNextEpisodeCountdown] = useState(() => ({
    ...createNextEpisodeCountdown(10),
    visible: false,
  }));

  const skipAction = getSkipAction({
    currentTimeSec,
    isEpisode: Boolean(episode),
    recapStartSec: 5,
    recapEndSec: 45,
    introStartSec: 60,
    introEndSec: 150,
    skippedRecap,
    skippedIntro,
  });

  const currentEpisodeIndex = episode
    ? item.episodes?.findIndex((candidate) => candidate.id === episode.id) ?? -1
    : -1;
  const nextEpisode =
    currentEpisodeIndex >= 0 && item.episodes && item.episodes.length > 1
      ? item.episodes[(currentEpisodeIndex + 1) % item.episodes.length]
      : undefined;

  useEffect(() => {
    setCurrentTimeSec(episode ? 8 : 342);
    setSkippedRecap(false);
    setSkippedIntro(false);
    setNextEpisodeCountdown({
      ...createNextEpisodeCountdown(10),
      visible: false,
    });
    setIsPlaying(true);
    setIsControlsVisible(true);
  }, [item.id, episode?.id]);

  // Auto hide HUD after 4.5 seconds
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isControlsVisible && isPlaying && !activeSheet) {
      timer = setTimeout(() => {
        setIsControlsVisible(false);
      }, 4500);
    }
    return () => clearTimeout(timer);
  }, [isControlsVisible, isPlaying, activeSheet]);

  // Tick playback timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && !isBuffering && !isPlaybackError) {
      interval = setInterval(() => {
        setCurrentTimeSec((prev) => {
          const nextTime = Math.min(totalDurationSec, prev + 1);
          if (
            shouldShowNextEpisode({
              isEpisode: Boolean(episode && nextEpisode),
              currentTimeSec: nextTime,
              durationSec: totalDurationSec,
              windowSec: 20,
              cancelled: nextEpisodeCountdown.cancelled,
            }) &&
            !nextEpisodeCountdown.visible &&
            !nextEpisodeCountdown.advanced
          ) {
            setNextEpisodeCountdown(createNextEpisodeCountdown(10));
          }
          return nextTime;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [
    isPlaying,
    isBuffering,
    isPlaybackError,
    totalDurationSec,
    episode,
    nextEpisode,
    nextEpisodeCountdown.cancelled,
    nextEpisodeCountdown.visible,
    nextEpisodeCountdown.advanced,
  ]);

  // Countdown timer for next episode
  useEffect(() => {
    if (
      !nextEpisodeCountdown.visible ||
      nextEpisodeCountdown.cancelled ||
      nextEpisodeCountdown.advanced
    ) {
      return;
    }

    const timer = setTimeout(() => {
      setNextEpisodeCountdown((previous) => tickNextEpisodeCountdown(previous));
    }, 1000);

    return () => clearTimeout(timer);
  }, [nextEpisodeCountdown]);

  useEffect(() => {
    if (!nextEpisodeCountdown.shouldAdvance) {
      return;
    }

    onNextEpisode?.();
    setNextEpisodeCountdown((previous) => ({
      ...previous,
      shouldAdvance: false,
    }));
  }, [nextEpisodeCountdown.shouldAdvance, onNextEpisode]);

  const formatTime = (secs: number) => {
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    if (hrs > 0) {
      return `${hrs}:${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${mins}:${String(s).padStart(2, '0')}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTimeSec(Number(e.target.value));
  };

  const handleJump = (seconds: number) => {
    setCurrentTimeSec((prev) => Math.max(0, Math.min(totalDurationSec, prev + seconds)));
    setIsControlsVisible(true);
  };

  const handleSkipAction = () => {
    if (!skipAction) {
      return;
    }

    setCurrentTimeSec(skipAction.targetSec);
    if (skipAction.kind === 'recap') {
      setSkippedRecap(true);
      onShowSnackbar('Resumen omitido');
    } else {
      setSkippedIntro(true);
      onShowSnackbar('Introducción omitida');
    }
    setIsControlsVisible(false);
  };

  const handlePlayNextEpisode = () => {
    setNextEpisodeCountdown((previous) => ({
      ...previous,
      visible: false,
      advanced: true,
      shouldAdvance: false,
    }));
    onNextEpisode?.();
  };

  const handleCancelNextEpisode = () => {
    setNextEpisodeCountdown((previous) => cancelNextEpisodeCountdown(previous));
  };

  const handleRetryPlayback = () => {
    setIsPlaybackError(false);
    setIsBuffering(true);
    setTimeout(() => {
      setIsBuffering(false);
      setIsPlaying(true);
    }, 800);
  };

  const progressPercent = (currentTimeSec / totalDurationSec) * 100;

  return (
    <div
      onClick={() => setIsControlsVisible(!isControlsVisible)}
      className="relative w-full h-full min-h-full flex-1 bg-black text-[#F5F5F5] select-none flex flex-col justify-between overflow-hidden"
    >
      {/* Background Cinematic Artwork Simulation */}
      <div className="absolute inset-0 bg-black">
        <img
          src={episode ? episode.thumbnailUrl : item.backdropUrl}
          alt={item.title}
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            isPlaying ? 'opacity-85' : 'opacity-50'
          }`}
        />
      </div>

      {/* Subtitles Overlay if enabled */}
      {selectedSub !== 'Desactivados' && (
        <div className="absolute bottom-14 left-0 right-0 z-20 flex justify-center px-6 pointer-events-none">
          <p className="bg-black/80 backdrop-blur-sm text-white px-3 py-1 rounded-lg text-xs sm:text-sm font-medium tracking-wide text-center border border-white/10 shadow-lg">
            [Frecuencia armónica interceptada en sector 7...]
          </p>
        </div>
      )}

      {/* Buffering Indicator */}
      {isBuffering && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/60 backdrop-blur-xs pointer-events-none">
          <div className="w-14 h-14 rounded-full border-4 border-[#27302C] border-t-[#00C781] animate-spin mb-3" />
          <span className="text-xs font-bold text-white tracking-wider uppercase font-mono">
            Cargando buffer 4K HDR...
          </span>
        </div>
      )}

      {/* Playback Error Overlay */}
      {isPlaybackError && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute inset-0 z-40 bg-[#080A09]/95 flex flex-col items-center justify-center p-6 text-center"
        >
          <div className="w-16 h-16 rounded-full bg-[#1E1414] border border-[#7F1D1D]/50 flex items-center justify-center text-[#EF4444] mb-3">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">Error de decodificación de flujo</h3>
          <p className="text-xs text-[#A8ADAB] max-w-sm mb-5">
            El códec HEVC HDR10+ experimentó una pérdida de paquetes. Puedes reintentar o reducir la calidad a 1080p.
          </p>
          <div className="flex gap-3">
            <PrimaryButton
              size="sm"
              onClick={handleRetryPlayback}
              icon={<RefreshCw className="w-4 h-4" />}
            >
              Reintentar
            </PrimaryButton>
            <SecondaryButton
              size="sm"
              onClick={() => {
                setSelectedQuality('1080p Full HD');
                handleRetryPlayback();
              }}
            >
              Forzar 1080p
            </SecondaryButton>
          </div>
        </div>
      )}

      {/* Next Episode Floating Countdown */}
      {nextEpisodeCountdown.visible && nextEpisode && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute bottom-20 right-4 z-40 w-[min(21rem,calc(100vw-2rem))] overflow-hidden rounded-2xl bg-[#101412]/95 border border-[#27302C] shadow-2xl backdrop-blur-xl animate-in slide-in-from-right duration-200"
        >
          <div className="flex gap-3 p-3">
            <div className="relative h-20 w-32 shrink-0 overflow-hidden rounded-xl bg-[#080A09]">
              <img
                src={nextEpisode.thumbnailUrl}
                alt=""
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#00C781] text-[#050505] shadow-lg">
                  <Play className="h-4 w-4 fill-current ml-0.5" />
                </span>
              </div>
            </div>
            <div className="min-w-0 flex-1 py-0.5">
              <div className="mb-1 flex items-center justify-between gap-2">
                <span className="text-[10px] uppercase font-bold text-[#00C781] tracking-wider">
                  A continuación
                </span>
                <span className="text-[11px] font-mono font-bold text-white">
                  {nextEpisodeCountdown.secondsRemaining}s
                </span>
              </div>
              <h4 className="line-clamp-2 text-sm font-bold leading-tight text-white">
                T{nextEpisode.seasonNumber}:E{nextEpisode.episodeNumber} • {nextEpisode.title}
              </h4>
              <p className="mt-1 text-[11px] text-[#A8ADAB]">Reproducción automática</p>
            </div>
          </div>
          <div className="flex gap-2 border-t border-[#27302C] p-3 pt-2.5">
            <button
              type="button"
              onClick={handlePlayNextEpisode}
              className="min-h-12 flex-1 rounded-xl bg-[#00C781] px-4 text-xs font-bold text-[#050505] transition-colors hover:bg-[#00E595] active:scale-[0.98]"
            >
              Ver ahora
            </button>
            <button
              type="button"
              onClick={handleCancelNextEpisode}
              className="min-h-12 rounded-xl bg-[#151917] px-4 text-xs font-semibold text-[#F5F5F5] transition-colors hover:bg-[#1D2421] active:scale-[0.98]"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Contextual Skip Action: remains available with the HUD hidden */}
      {skipAction && isPlaying && !isControlsVisible && (
        <div className="absolute bottom-20 right-4 z-30">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleSkipAction();
            }}
            className="min-h-12 px-4 rounded-xl bg-[#101412]/92 backdrop-blur-md border border-[#27302C] text-xs font-bold text-white shadow-2xl flex items-center gap-2 hover:border-[#00C781] hover:text-[#00C781] transition-all active:scale-95"
          >
            <span>{skipAction.label}</span>
            <FastForward className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* HUD OVERLAYS (Visible on tap) */}
      <div
        aria-hidden={!isControlsVisible}
        className={`absolute inset-0 flex flex-col justify-between p-4 bg-gradient-to-t from-black/90 via-black/20 to-black/80 transition-opacity duration-200 z-20 ${
          isControlsVisible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onBack}
              className="w-12 h-12 rounded-full bg-[#151917]/80 border border-[#27302C] text-white flex items-center justify-center hover:bg-[#27302C] active:scale-95"
              aria-label="Salir del reproductor"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="px-1.5 py-0.5 rounded bg-[#00C781] text-black text-[9px] font-black uppercase font-mono">
                  {selectedQuality.split(' ')[0]}
                </span>
                <span className="text-xs font-mono text-[#00C781] font-bold">
                  {selectedAudio.includes('Atmos') ? 'Dolby Atmos' : '5.1'}
                </span>
              </div>
              <h2 className="text-sm font-bold text-white truncate max-w-xs sm:max-w-md">
                {item.title} {episode ? `• T${episode.seasonNumber}:E${episode.episodeNumber} "${episode.title}"` : ''}
              </h2>
            </div>
          </div>

          {/* Quick Config Buttons */}
          <div className="flex items-center gap-1.5">
            {episode && nextEpisode && onNextEpisode && (
              <button
                type="button"
                onClick={handlePlayNextEpisode}
                className="w-12 h-12 rounded-full bg-[#151917]/80 border border-[#27302C] text-[#C4C8C6] hover:text-[#00C781] flex items-center justify-center"
                aria-label={`Reproducir siguiente episodio: ${nextEpisode.title}`}
                title="Siguiente episodio"
              >
                <SkipForward className="w-5 h-5" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveSheet('audio_subs')}
              className="w-12 h-12 rounded-full bg-[#151917]/80 border border-[#27302C] text-[#C4C8C6] hover:text-white flex items-center justify-center"
              aria-label="Audio y Subtítulos"
            >
              <MessageSquare className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setActiveSheet('quality')}
              className="w-12 h-12 rounded-full bg-[#151917]/80 border border-[#27302C] text-[#C4C8C6] hover:text-white flex items-center justify-center"
              aria-label="Calidad de Video"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center Playback Controls: ±10s & Play/Pause */}
        <div className="flex items-center justify-center gap-8 my-auto">
          <button
            type="button"
            onClick={() => handleJump(-10)}
            className="w-12 h-12 rounded-full bg-[#151917]/80 border border-[#27302C] text-white flex items-center justify-center hover:text-[#00C781] active:scale-90 transition-transform"
            aria-label="Retroceder 10 segundos"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-16 h-16 rounded-full bg-[#00C781] text-[#050505] flex items-center justify-center hover:bg-[#00E595] active:scale-95 shadow-2xl transition-transform"
            aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
          >
            {isPlaying ? (
              <Pause className="w-7 h-7 fill-current" />
            ) : (
              <Play className="w-7 h-7 fill-current ml-1" />
            )}
          </button>

          <button
            type="button"
            onClick={() => handleJump(10)}
            className="w-12 h-12 rounded-full bg-[#151917]/80 border border-[#27302C] text-white flex items-center justify-center hover:text-[#00C781] active:scale-90 transition-transform"
            aria-label="Avanzar 10 segundos"
          >
            <RotateCw className="w-5 h-5" />
          </button>
        </div>

        {/* Bottom Timeline, Scrubber & Controls */}
        <div className="space-y-2">
          {/* Contextual skip action inside the visible HUD */}
          {skipAction && (
            <div className="flex justify-end mb-1">
              <button
                type="button"
                onClick={handleSkipAction}
                className="min-h-12 px-4 rounded-xl bg-[#101412]/92 border border-[#27302C] text-white text-xs font-bold flex items-center gap-2 shadow-lg hover:border-[#00C781] hover:text-[#00C781] active:scale-95"
              >
                <span>{skipAction.label}</span>
                <FastForward className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Timeline Scrubber */}
          <div className="relative flex items-center group">
            <input
              type="range"
              min={0}
              max={totalDurationSec}
              value={currentTimeSec}
              onChange={handleSeek}
              className="w-full h-1.5 bg-[#27302C] rounded-lg appearance-none cursor-pointer accent-[#00C781] focus:outline-none"
            />
          </div>

          {/* Timestamps & Extra Controls */}
          <div className="flex items-center justify-between text-xs text-[#C4C8C6] font-mono font-medium">
            <span>{formatTime(currentTimeSec)}</span>
            <span className="text-[#A8ADAB]">-{formatTime(totalDurationSec - currentTimeSec)}</span>
          </div>
        </div>
      </div>

      {/* Audio & Subtitles Modal Sheet */}
      <ModalSheet
        isOpen={activeSheet === 'audio_subs'}
        onClose={() => setActiveSheet(null)}
        title="Audio y Subtítulos"
        subtitle={item.title}
      >
        <div className="space-y-4 my-2">
          {/* Audio Tracks */}
          <div>
            <h4 className="text-xs font-bold text-[#00C781] uppercase tracking-wider mb-2">
              Pistas de Audio
            </h4>
            <div className="space-y-1.5">
              {[
                'Español (Latino) [Dolby Atmos]',
                'Español (España) [Dolby 5.1]',
                'Inglés [Dolby Atmos Original]',
                'Portugués [5.1 Surround]'
              ].map((trk) => (
                <button
                  key={trk}
                  type="button"
                  onClick={() => setSelectedAudio(trk)}
                  className={`w-full p-3 rounded-xl border flex items-center justify-between text-left text-xs ${
                    selectedAudio === trk
                      ? 'bg-[#151917] border-[#00C781] text-white font-bold'
                      : 'bg-[#101412] border-[#27302C] text-[#C4C8C6]'
                  }`}
                >
                  <span>{trk}</span>
                  {selectedAudio === trk && <Check className="w-4 h-4 text-[#00C781]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Subtitle Tracks */}
          <div>
            <h4 className="text-xs font-bold text-[#00C781] uppercase tracking-wider mb-2">
              Subtítulos
            </h4>
            <div className="space-y-1.5">
              {[
                'Desactivados',
                'Español [CC]',
                'Inglés [CC]',
                'Portugués',
                'Alemán'
              ].map((sub) => (
                <button
                  key={sub}
                  type="button"
                  onClick={() => setSelectedSub(sub)}
                  className={`w-full p-3 rounded-xl border flex items-center justify-between text-left text-xs ${
                    selectedSub === sub
                      ? 'bg-[#151917] border-[#00C781] text-white font-bold'
                      : 'bg-[#101412] border-[#27302C] text-[#C4C8C6]'
                  }`}
                >
                  <span>{sub}</span>
                  {selectedSub === sub && <Check className="w-4 h-4 text-[#00C781]" />}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2">
            <PrimaryButton fullWidth onClick={() => setActiveSheet(null)}>
              Aplicar cambios
            </PrimaryButton>
          </div>
        </div>
      </ModalSheet>

      {/* Quality Modal Sheet */}
      <ModalSheet
        isOpen={activeSheet === 'quality'}
        onClose={() => setActiveSheet(null)}
        title="Calidad de Transmisión"
        subtitle="Optimiza el bitrate y rendimiento de reproducción"
      >
        <div className="space-y-2 my-2">
          {[
            { id: '4K Ultra HD (HDR10+)', desc: 'Máxima resolución 3840×2160 a 25 Mbps' },
            { id: '1080p Full HD', desc: '1920×1080 a 8 Mbps (Bajo consumo de batería)' },
            { id: '720p HD', desc: '1280×720 a 3 Mbps' },
            { id: 'Automática', desc: 'Ajuste continuo según estabilidad de la red' }
          ].map((q) => (
            <button
              key={q.id}
              type="button"
              onClick={() => {
                setSelectedQuality(q.id);
                setActiveSheet(null);
                onShowSnackbar(`Calidad establecida en ${q.id}`);
              }}
              className={`w-full p-3 rounded-xl border flex items-center justify-between text-left ${
                selectedQuality === q.id
                  ? 'bg-[#151917] border-[#00C781] text-white'
                  : 'bg-[#101412] border-[#27302C] text-[#C4C8C6]'
              }`}
            >
              <div>
                <span className="text-xs font-bold block">{q.id}</span>
                <span className="text-[11px] text-[#A8ADAB]">{q.desc}</span>
              </div>
              {selectedQuality === q.id && <Check className="w-4 h-4 text-[#00C781]" />}
            </button>
          ))}
        </div>
      </ModalSheet>
    </div>
  );
};

