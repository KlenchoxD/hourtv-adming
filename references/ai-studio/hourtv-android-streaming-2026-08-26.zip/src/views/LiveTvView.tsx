import React, { useEffect, useRef, useState } from 'react';
import {
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Volume2,
  VolumeX,
  Radio,
  AlertTriangle,
  RefreshCw,
  Layers,
  ArrowLeft,
  Lock,
  Check,
  ShieldAlert
} from 'lucide-react';
import { TVChannel } from '../types';
import { ChannelCard } from '../components/common/Cards';
import {
  PrimaryButton,
  SecondaryButton
} from '../components/common/Buttons';

interface LiveTvViewProps {
  channels: TVChannel[];
  activeChannel: TVChannel;
  onSelectChannel: (channel: TVChannel) => void;
  onToggleFavorite: (channel: TVChannel) => void;
}

interface CategoryOption {
  id: string;
  label: string;
  isAdult?: boolean;
}

export const LiveTvView: React.FC<LiveTvViewProps> = ({
  channels,
  activeChannel,
  onSelectChannel,
  onToggleFavorite
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isControlsVisible, setIsControlsVisible] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isSignalError, setIsSignalError] = useState<boolean>(false);
  const [isRetrying, setIsRetrying] = useState<boolean>(false);

  /* =========================
     CONTROL PARENTAL
  ========================== */
  const [isAdultUnlocked, setIsAdultUnlocked] = useState<boolean>(false);
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');

  const playerContainerRef = useRef<HTMLDivElement>(null);

  /* =========================
     CATEGORÍAS
  ========================== */
  const allCategories: CategoryOption[] = [
    { id: 'todos', label: 'Todos los canales' },
    { id: 'favoritos', label: 'Favoritos' },
    { id: 'deportes', label: 'Deportes' },
    { id: 'cine', label: 'Cine' },
    { id: 'series', label: 'Series' },
    { id: 'novelas', label: 'Novelas' },
    { id: 'populares', label: 'Populares' },
    { id: 'noticias', label: 'Noticias' },
    { id: 'infantil', label: 'Infantil' },
    { id: 'religioso', label: 'Religioso' },
    { id: 'adultos', label: '+18', isAdult: true }
  ];

  /* =========================
     FULLSCREEN
  ========================== */
  const checkIsNativeFullscreen = (): boolean => {
    if (typeof document === 'undefined') {
      return false;
    }
    const doc = document as any;
    return Boolean(
      doc.fullscreenElement ||
        doc.webkitFullscreenElement ||
        doc.mozFullScreenElement ||
        doc.msFullscreenElement
    );
  };

  const handleToggleFullscreen = async () => {
    const element = playerContainerRef.current as any;
    const doc = document as any;
    const currentlyFullscreen = isFullscreen || checkIsNativeFullscreen();

    if (currentlyFullscreen) {
      try {
        if (doc.exitFullscreen) {
          await doc.exitFullscreen();
        } else if (doc.webkitExitFullscreen) {
          await doc.webkitExitFullscreen();
        } else if (doc.mozCancelFullScreen) {
          await doc.mozCancelFullScreen();
        } else if (doc.msExitFullscreen) {
          await doc.msExitFullscreen();
        }
      } catch (error) {
        console.warn('Error al salir de pantalla completa:', error);
      }
      setIsFullscreen(false);
    } else {
      try {
        if (element) {
          if (element.requestFullscreen) {
            await element.requestFullscreen();
          } else if (element.webkitRequestFullscreen) {
            await element.webkitRequestFullscreen();
          } else if (element.mozRequestFullScreen) {
            await element.mozRequestFullScreen();
          } else if (element.msRequestFullscreen) {
            await element.msRequestFullscreen();
          }
        }
      } catch (error) {
        console.warn('Fullscreen nativo denegado:', error);
      }
      setIsFullscreen(true);
    }
    setIsControlsVisible(true);
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(checkIsNativeFullscreen());
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isFullscreen) {
        handleToggleFullscreen();
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isFullscreen]);

  /* =========================
     AUTO OCULTAR CONTROLES
  ========================== */
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    if (isControlsVisible) {
      timer = setTimeout(() => {
        setIsControlsVisible(false);
      }, 4500);
    }
    return () => {
      if (timer) {
        clearTimeout(timer);
      }
    };
  }, [isControlsVisible]);

  /* =========================
     BLOQUEAR SCROLL CUANDO
     HAY MODAL PIN
  ========================== */
  useEffect(() => {
    if (!isPinModalOpen) {
      return;
    }
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isPinModalOpen]);

  /* =========================
     CONTROLES DEL PLAYER
  ========================== */
  const handleTouchScreen = () => {
    setIsControlsVisible((previous) => !previous);
  };

  const handleNextChannel = (event: React.MouseEvent) => {
    event.stopPropagation();
    if (channels.length === 0) return;
    const currentIndex = channels.findIndex((ch) => ch.id === activeChannel.id);
    const nextIndex = (currentIndex + 1) % channels.length;
    onSelectChannel(channels[nextIndex]);
    setIsControlsVisible(true);
  };

  const handlePrevChannel = (event: React.MouseEvent) => {
    event.stopPropagation();
    if (channels.length === 0) return;
    const currentIndex = channels.findIndex((ch) => ch.id === activeChannel.id);
    const previousIndex = (currentIndex - 1 + channels.length) % channels.length;
    onSelectChannel(channels[previousIndex]);
    setIsControlsVisible(true);
  };

  const handleRetrySignal = (event: React.MouseEvent) => {
    event.stopPropagation();
    setIsRetrying(true);
    setTimeout(() => {
      setIsRetrying(false);
      setIsSignalError(false);
    }, 800);
  };

  /* =========================
     VERIFICACIÓN PIN
  ========================== */
  const handleVerifyPin = () => {
    if (enteredPin === '1234' || enteredPin === '0000') {
      setIsAdultUnlocked(true);
      setIsPinModalOpen(false);
      setSelectedCategory('adultos');
      setIsCategoryMenuOpen(false);
      setEnteredPin('');
      setPinError('');
      return;
    }
    setPinError('PIN incorrecto. PIN de prueba: 1234');
  };

  /* =========================
     FILTRADO DE CANALES
  ========================== */
  const filteredChannels = channels.filter((channel) => {
    if (selectedCategory === 'favoritos') {
      return channel.isFavorite;
    }
    if (selectedCategory === 'todos') {
      return true;
    }
    return (channel.category as string) === selectedCategory;
  });

  const activeCategoryLabel =
    allCategories.find((cat) => cat.id === selectedCategory)?.label || 'Todos los canales';

  return (
    <div className="flex-1 min-h-screen pb-16 text-[#F5F5F5] select-none bg-[#080A09] animate-screen-enter">
      {/* =========================
          PLAYER
      ========================== */}
      <div
        ref={playerContainerRef}
        className={`relative w-full bg-black overflow-hidden transition-all duration-300 ${
          isFullscreen
            ? 'fixed inset-0 z-[9999] w-screen h-screen flex items-center justify-center'
            : 'aspect-[16/9] border-b border-[#27302C]'
        }`}
        onClick={handleTouchScreen}
      >
        <img
          src={activeChannel.streamPreviewUrl}
          alt={activeChannel.name}
          className="w-full h-full object-cover"
        />

        {/* ERROR DE SEÑAL */}
        {isSignalError ? (
          <div
            onClick={(event) => event.stopPropagation()}
            className="absolute inset-0 z-30 flex flex-col items-center justify-center p-6 text-center bg-[#050505]/95"
          >
            <AlertTriangle className="w-12 h-12 text-[#FBBF24] mb-3 animate-bounce" />
            <h3 className="text-sm font-bold text-white mb-1">Señal en vivo no disponible</h3>
            <p className="text-xs text-[#A8ADAB] max-w-xs mb-4">
              La emisión de "{activeChannel.name}" está experimentando latencia temporal en tu zona.
            </p>
            <PrimaryButton
              size="sm"
              onClick={handleRetrySignal}
              isLoading={isRetrying}
              icon={<RefreshCw className="w-4 h-4" />}
            >
              Reconectar señal
            </PrimaryButton>
          </div>
        ) : (
          /* CONTROLES DEL PLAYER */
          <div
            className={`absolute inset-0 z-20 flex flex-col justify-between p-3.5 transition-opacity duration-200 bg-gradient-to-t from-black/85 via-transparent to-black/60 ${
              isControlsVisible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
            }`}
          >
            {/* TOP PLAYER */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isFullscreen && (
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      handleToggleFullscreen();
                    }}
                    className="w-9 h-9 rounded-full bg-black/70 text-white flex items-center justify-center border border-white/10 active:scale-95"
                    aria-label="Salir de pantalla completa"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                )}

                <span className="w-8 h-8 rounded-lg bg-[#00D88B] text-[#04110C] font-mono font-black text-xs flex items-center justify-center">
                  {activeChannel.channelNumber}
                </span>

                <div>
                  <h3 className="text-xs font-bold text-white leading-tight">
                    {activeChannel.name}
                  </h3>
                  <div className="flex items-center gap-1.5 text-[10px]">
                    <span className="flex items-center gap-1 text-[#00D88B] font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00D88B] animate-pulse" />
                      EN VIVO
                    </span>
                    <span className="text-[#A8ADAB]">•</span>
                    <span className="text-[#A8ADAB] font-mono">
                      {activeChannel.streamQuality}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* SONIDO */}
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    setIsMuted((previous) => !previous);
                  }}
                  className="w-9 h-9 rounded-full bg-black/70 text-white flex items-center justify-center border border-white/10 active:scale-95"
                  aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-[#EF4444]" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-[#00D88B]" />
                  )}
                </button>

                {/* FULLSCREEN */}
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    handleToggleFullscreen();
                  }}
                  className="w-9 h-9 rounded-full bg-black/70 text-white flex items-center justify-center border border-white/10 active:scale-95"
                  aria-label={isFullscreen ? 'Salir de pantalla completa' : 'Pantalla completa'}
                >
                  {isFullscreen ? (
                    <Minimize2 className="w-4 h-4" />
                  ) : (
                    <Maximize2 className="w-4 h-4 text-[#00D88B]" />
                  )}
                </button>
              </div>
            </div>

            {/* CAMBIAR CANAL */}
            <div className="flex items-center justify-between px-2">
              <button
                type="button"
                onClick={handlePrevChannel}
                className="w-11 h-11 rounded-full bg-black/70 text-white border border-white/10 flex items-center justify-center active:scale-95 backdrop-blur-md"
                aria-label="Canal anterior"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              <button
                type="button"
                onClick={handleNextChannel}
                className="w-11 h-11 rounded-full bg-black/70 text-white border border-white/10 flex items-center justify-center active:scale-95 backdrop-blur-md"
                aria-label="Siguiente canal"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* PROGRAMA ACTUAL */}
            <div className="bg-black/65 backdrop-blur-md p-2.5 rounded-xl border border-white/10">
              <div className="flex items-center justify-between text-[11px] mb-1 gap-3">
                <span className="text-white font-semibold truncate">
                  {activeChannel.currentProgram.title}
                </span>
                <span className="text-[#00D88B] font-mono font-bold whitespace-nowrap">
                  {activeChannel.currentProgram.startTime} - {activeChannel.currentProgram.endTime}
                </span>
              </div>

              <div className="w-full h-1 bg-[#252A28] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#00D88B] rounded-full"
                  style={{
                    width: `${activeChannel.currentProgram.progressPercent}%`
                  }}
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* =========================
          CONTENIDO NORMAL
      ========================== */}
      {!isFullscreen && (
        <div className="px-4 py-3">
          {/* Vertical category selector: no sideways navigation */}
          <div className="relative mb-3">
            <button
              type="button"
              onClick={() => setIsCategoryMenuOpen((open) => !open)}
              className="w-full min-h-12 px-3.5 py-2.5 rounded-xl bg-[#151917] border border-[#27302C] flex items-center justify-between gap-3 text-left focus:outline-none focus:ring-2 focus:ring-[#00C781]"
              aria-expanded={isCategoryMenuOpen}
              aria-haspopup="listbox"
            >
              <span className="flex items-center gap-2 min-w-0">
                <Layers className="w-4 h-4 shrink-0 text-[#00C781]" />
                <span>
                  <span className="block text-[10px] uppercase tracking-[0.12em] text-[#A8ADAB]">Categoría</span>
                  <span className="block text-sm font-semibold text-white truncate">{activeCategoryLabel}</span>
                </span>
              </span>
              <ChevronDown
                className={`w-4 h-4 text-[#C4C8C6] transition-transform ${isCategoryMenuOpen ? 'rotate-180' : ''}`}
              />
            </button>

            {isCategoryMenuOpen && (
              <div
                role="listbox"
                aria-label="Categorías de TV"
                className="mt-2 w-full overflow-hidden rounded-xl border border-[#27302C] bg-[#101412] shadow-xl"
              >
                {allCategories.map((category) => {
                  const isSelected = category.id === selectedCategory;
                  return (
                    <button
                      key={category.id}
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      onClick={() => {
                        if (category.isAdult && !isAdultUnlocked) {
                          setPinError('');
                          setEnteredPin('');
                          setIsPinModalOpen(true);
                          setIsCategoryMenuOpen(false);
                          return;
                        }
                        setSelectedCategory(category.id);
                        setIsCategoryMenuOpen(false);
                      }}
                      className={`w-full min-h-12 px-3.5 flex items-center justify-between border-b border-[#27302C]/60 last:border-b-0 text-sm transition-colors focus-visible:outline-none focus-visible:bg-[#00C781] focus-visible:text-[#050505] ${
                        isSelected ? 'bg-[#151917] text-white font-semibold' : 'text-[#C4C8C6]'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {category.label}
                        {category.isAdult && !isAdultUnlocked && (
                          <Lock className="w-3.5 h-3.5 text-[#FBBF24]" />
                        )}
                      </span>
                      {isSelected && <Check className="w-4 h-4 text-[#00C781]" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* LISTA DE CANALES */}
          <div className="space-y-2.5">
            {filteredChannels.length > 0 ? (
              filteredChannels.map((channel) => (
                <ChannelCard
                  key={channel.id}
                  channel={channel}
                  isSelected={channel.id === activeChannel.id}
                  onSelect={(ch) => onSelectChannel(ch)}
                  onToggleFavorite={(ch, event) => {
                    event.stopPropagation();
                    onToggleFavorite(ch);
                  }}
                />
              ))
            ) : (
              <div className="py-12 text-center text-[#A8ADAB] bg-[#101412]/40 rounded-2xl border border-[#27302C]/60 p-4">
                <Radio className="w-8 h-8 text-[#27302C] mx-auto mb-2" />
                <p className="text-xs font-semibold text-white">
                  No hay canales en esta categoría
                </p>
                <p className="text-[11px] text-[#A8ADAB] mt-1">
                  {selectedCategory === 'favoritos'
                    ? 'No has marcado canales como favoritos todavía.'
                    : 'Prueba seleccionando "Todos los canales".'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================================
          MODAL PIN CONTROL PARENTAL
      ========================================================== */}
      {isPinModalOpen && (
        <div
          className="fixed inset-0 z-[10010] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
          onClick={() => {
            setIsPinModalOpen(false);
            setEnteredPin('');
            setPinError('');
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Control parental"
            onClick={(event) => event.stopPropagation()}
            className="w-full max-w-[330px] bg-[#101713] border border-[#2B3731] rounded-[24px] p-5 shadow-2xl text-center animate-in zoom-in-95 duration-200"
          >
            <div className="w-12 h-12 rounded-full bg-[#211716] border border-[#7F1D1D]/50 flex items-center justify-center text-[#EF4444] mx-auto mb-3">
              <ShieldAlert className="w-6 h-6" />
            </div>

            <h3 className="text-base font-extrabold text-white mb-1">
              Control Parental
            </h3>

            <p className="text-xs leading-relaxed text-[#A8ADAB] mb-4">
              Ingresa el PIN de 4 dígitos para desbloquear la categoría +18.
            </p>

            <input
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={4}
              value={enteredPin}
              onChange={(event) => {
                const value = event.target.value.replace(/\D/g, '');
                setEnteredPin(value);
                setPinError('');
              }}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  handleVerifyPin();
                }
              }}
              placeholder="••••"
              className="block w-36 mx-auto text-center tracking-[0.45em] text-xl font-mono font-bold bg-[#151D19] border border-[#34403A] focus:border-[#00D88B] rounded-xl py-3 px-3 text-white outline-none transition-colors"
              autoFocus
            />

            {pinError && (
              <p className="text-[11px] text-[#EF4444] mt-2">
                {pinError}
              </p>
            )}

            <div className="flex gap-2 mt-5">
              <SecondaryButton
                size="sm"
                fullWidth
                onClick={() => {
                  setIsPinModalOpen(false);
                  setEnteredPin('');
                  setPinError('');
                }}
              >
                Cancelar
              </SecondaryButton>

              <PrimaryButton
                size="sm"
                fullWidth
                onClick={handleVerifyPin}
              >
                Desbloquear
              </PrimaryButton>
            </div>

            <p className="mt-3 text-[9px] text-[#66706B]">
              PIN de prueba: 1234
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
