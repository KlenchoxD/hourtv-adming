import React, { useState } from 'react';
import { Play, Plus, Check, Sparkles, ChevronRight } from 'lucide-react';
import { MediaItem, RouteId, TVChannel } from '../types';
import { PosterCard, ContinueWatchingCard } from '../components/common/Cards';
import { PrimaryButton, SecondaryButton } from '../components/common/Buttons';

interface HomeViewProps {
  mediaItems: MediaItem[];
  tvChannels: TVChannel[];
  onSelectMedia: (item: MediaItem) => void;
  onPlayMedia: (item: MediaItem) => void;
  onToggleMyList: (item: MediaItem) => void;
  onNavigate: (route: RouteId) => void;
  onSelectChannel: (channel: TVChannel) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  mediaItems,
  tvChannels,
  onSelectMedia,
  onPlayMedia,
  onToggleMyList,
  onNavigate,
  onSelectChannel
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');

  // Featured Hero Item (default "El último amanecer" or first original)
  const heroItem = mediaItems.find((m) => m.id === 'el-ultimo-amanecer') || mediaItems[0];

  // Continue Watching items (items with progress)
  const continueWatchingItems = mediaItems.filter(
    (m) => m.progressPercentage && m.progressPercentage > 0
  );

  // Originals
  const originals = mediaItems.filter((m) => m.isOriginal);

  // Trending
  const trendingItems = mediaItems.filter((m) => m.isTrending);

  // Movies
  const movies = mediaItems.filter((m) => m.type === 'movie');

  // Series
  const series = mediaItems.filter((m) => m.type === 'series');

  // Filtered catalogue if category is active
  const categoryFilteredItems =
    selectedCategory === 'Todos'
      ? []
      : selectedCategory === 'Originals'
      ? originals
      : selectedCategory === 'Películas'
      ? movies
      : selectedCategory === 'Series'
      ? series
      : selectedCategory === '4K UHD'
      ? mediaItems.filter((m) => m.qualityBadges.includes('4K UHD'))
      : mediaItems.filter((m) => m.genres.includes(selectedCategory));

  const categoryChips = [
    'Todos',
    'Originals',
    'Películas',
    'Series',
    'Ciencia Ficción',
    'Suspenso',
    'Acción',
    '4K UHD'
  ];

  return (
    <div className="flex-1 pb-16 text-[#F5F5F5] select-none animate-screen-enter">
      {/* Category Pills Header Filter */}
      <div className="sticky top-0 z-20 bg-[#080A09]/95 backdrop-blur-md px-4 py-2 border-b border-[#27302C]/40 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {categoryChips.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-120 active:scale-95 min-h-[34px] flex items-center ${
                isSelected
                  ? 'bg-[#00C781] text-[#050505] font-bold shadow-sm'
                  : 'bg-[#151917] text-[#C4C8C6] border border-[#27302C] hover:border-[#38443F]'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* If category selected, show filtered grid view */}
      {selectedCategory !== 'Todos' ? (
        <div className="px-4 py-4 animate-screen-enter">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>{selectedCategory}</span>
              <span className="text-xs text-[#00C781] font-mono font-normal">
                ({categoryFilteredItems.length} títulos)
              </span>
            </h2>
            <button
              type="button"
              onClick={() => setSelectedCategory('Todos')}
              className="text-xs text-[#00C781] font-semibold hover:underline active:scale-95 transition-transform"
            >
              Ver todo el catálogo
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {categoryFilteredItems.map((item) => (
              <PosterCard
                key={item.id}
                item={item}
                size="sm"
                onClick={onSelectMedia}
                onToggleMyList={(i, e) => {
                  e.stopPropagation();
                  onToggleMyList(i);
                }}
                className="w-full min-w-0"
              />
            ))}
          </div>
        </div>
      ) : (
        <>
          {/* Hero Cinematográfico */}
          <section className="relative w-full aspect-[4/5] sm:aspect-[1/1] overflow-hidden bg-[#080A09]">
            {/* Backdrop Image */}
            <img
              src={heroItem.backdropUrl}
              alt={heroItem.title}
              className="w-full h-full object-cover object-center"
            />

            {/* Gradient Masking */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#080A09] via-[#080A09]/60 to-black/30" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#080A09]/80 via-transparent to-transparent" />

            {/* Hero Content Overlay */}
            <div className="absolute inset-0 flex flex-col justify-end px-5 pb-6">

              {/* Title */}
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight mb-2 drop-shadow-md">
                {heroItem.title}
              </h1>

              {/* Genre Pills */}
              <div className="flex items-center gap-2 mb-2 text-xs text-[#C4C8C6] flex-wrap">
                {heroItem.genres.map((g, idx) => (
                  <React.Fragment key={g}>
                    <span>{g}</span>
                    {idx < heroItem.genres.length - 1 && <span className="text-[#27302C]">•</span>}
                  </React.Fragment>
                ))}
              </div>


              {/* Centered Action Buttons */}
              <div className="grid grid-cols-2 gap-3 w-full max-w-sm">
                <PrimaryButton
                  fullWidth
                  onClick={() => onPlayMedia(heroItem)}
                  icon={<Play className="w-4 h-4 fill-current ml-0.5" />}
                  size="md"
                >
                  Reproducir
                </PrimaryButton>

                <SecondaryButton
                  fullWidth
                  onClick={() => onToggleMyList(heroItem)}
                  icon={
                    heroItem.isInMyList ? (
                      <Check className="w-4 h-4 text-[#00C781]" />
                    ) : (
                      <Plus className="w-4 h-4" />
                    )
                  }
                  size="md"
                  className="min-w-0 whitespace-nowrap"
                >
                  Mi Lista
                </SecondaryButton>

              </div>
            </div>
          </section>

          {/* Carrusel: Continuar viendo */}
          {continueWatchingItems.length > 0 && (
            <section className="mt-4 mb-6">
              <div className="flex items-center justify-between px-4 mb-3">
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Continuar viendo</span>

                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('library')}
                  className="text-xs font-semibold text-[#00C781] hover:underline flex items-center"
                >
                  Ver todo <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex gap-3 px-4 overflow-x-auto no-scrollbar pb-2">
                {continueWatchingItems.map((item) => (
                  <ContinueWatchingCard
                    key={item.id}
                    item={item}
                    onClick={onSelectMedia}
                    onPlayDirect={(i, e) => {
                      e.stopPropagation();
                      onPlayMedia(i);
                    }}
                  />
                ))}
              </div>
            </section>
          )}

          
          {/* Carrusel: HourTV Originals */}
          <section className="mb-6">
            <div className="flex items-center justify-between px-4 mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#00C781]" />
                <h2 className="text-base font-bold text-white">HourTV Originals</h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('originals')}
                className="text-xs font-semibold text-[#00C781] hover:underline flex items-center gap-0.5 active:scale-95 transition-transform"
                aria-label="Ver más HourTV Originals"
              >
                <span>Ver más &gt;</span>
              </button>
            </div>

            <div className="flex gap-3 px-4 overflow-x-auto no-scrollbar pb-2">
              {originals.map((item, idx) => (
                <PosterCard
                  key={item.id}
                  item={item}
                  showRanking={idx + 1}
                  size="md"
                  onClick={onSelectMedia}
                  onToggleMyList={(i, e) => {
                    e.stopPropagation();
                    onToggleMyList(i);
                  }}
                />
              ))}
            </div>
          </section>

          {/* Carrusel: Tendencias ahora */}
          <section className="mb-6">
            <div className="flex items-center justify-between px-4 mb-3">
              <h2 className="text-base font-bold text-white">Tendencias ahora</h2>
              <span className="text-xs text-[#00C781] font-semibold">Top Semana</span>
            </div>

            <div className="flex gap-3 px-4 overflow-x-auto no-scrollbar pb-2">
              {trendingItems.map((item) => (
                <PosterCard
                  key={item.id}
                  item={item}
                  size="md"
                  onClick={onSelectMedia}
                  onToggleMyList={(i, e) => {
                    e.stopPropagation();
                    onToggleMyList(i);
                  }}
                />
              ))}
            </div>
          </section>

          {/* Carrusel: Películas recomendadas */}
          <section className="mb-6">
            <div className="flex items-center justify-between px-4 mb-3">
              <h2 className="text-base font-bold text-white">Películas para ti</h2>
              <button
                type="button"
                onClick={() => setSelectedCategory('Películas')}
                className="text-xs font-semibold text-[#00C781] hover:underline"
              >
                Explorar
              </button>
            </div>

            <div className="flex gap-3 px-4 overflow-x-auto no-scrollbar pb-2">
              {movies.map((item) => (
                <PosterCard
                  key={item.id}
                  item={item}
                  size="md"
                  onClick={onSelectMedia}
                  onToggleMyList={(i, e) => {
                    e.stopPropagation();
                    onToggleMyList(i);
                  }}
                />
              ))}
            </div>
          </section>

          {/* Carrusel: Series recomendadas */}
          <section className="mb-6">
            <div className="flex items-center justify-between px-4 mb-3">
              <h2 className="text-base font-bold text-white">Series maratoneables</h2>
              <button
                type="button"
                onClick={() => setSelectedCategory('Series')}
                className="text-xs font-semibold text-[#00C781] hover:underline"
              >
                Explorar
              </button>
            </div>

            <div className="flex gap-3 px-4 overflow-x-auto no-scrollbar pb-2">
              {series.map((item) => (
                <PosterCard
                  key={item.id}
                  item={item}
                  size="md"
                  onClick={onSelectMedia}
                  onToggleMyList={(i, e) => {
                    e.stopPropagation();
                    onToggleMyList(i);
                  }}
                />
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
};
