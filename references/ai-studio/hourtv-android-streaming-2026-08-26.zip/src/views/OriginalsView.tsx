import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ArrowLeft, Sparkles, Filter, Film, Tv } from 'lucide-react';
import { MediaItem } from '../types';
import { PosterCard } from '../components/common/Cards';
import {
  initialVisibleCount,
  nextVisibleCount,
  progressiveSlice
} from '../../searchProgressiveBehavior.mjs';

interface OriginalsViewProps {
  mediaItems: MediaItem[];
  onBack: () => void;
  onSelectMedia: (item: MediaItem) => void;
  onToggleMyList: (item: MediaItem) => void;
}

export const OriginalsView: React.FC<OriginalsViewProps> = ({
  mediaItems,
  onBack,
  onSelectMedia,
  onToggleMyList
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'movie' | 'series' | '4k'>('all');

  // Filter all items that are Originals
  const allOriginals = useMemo(() => {
    return mediaItems.filter((item) => item.isOriginal);
  }, [mediaItems]);

  // Filter by content type if user selects chip
  const filteredOriginals = useMemo(() => {
    return allOriginals.filter((item) => {
      if (activeFilter === 'movie') return item.type === 'movie';
      if (activeFilter === 'series') return item.type === 'series';
      if (activeFilter === '4k') {
        return item.qualityBadges.some((b) => b.toLowerCase().includes('4k'));
      }
      return true;
    });
  }, [allOriginals, activeFilter]);

  // Progressive batching / infinite scroll state
  const [visibleCount, setVisibleCount] = useState(() =>
    Math.max(12, initialVisibleCount(filteredOriginals.length))
  );
  const loadMoreRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setVisibleCount(Math.max(12, initialVisibleCount(filteredOriginals.length)));
  }, [activeFilter, filteredOriginals.length]);

  const visibleItems = useMemo(() => {
    return progressiveSlice(filteredOriginals, visibleCount) as MediaItem[];
  }, [filteredOriginals, visibleCount]);

  const hasMoreItems = visibleItems.length < filteredOriginals.length;

  useEffect(() => {
    const sentinel = loadMoreRef.current;
    if (!sentinel || !hasMoreItems) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        setVisibleCount((current) => nextVisibleCount(current, filteredOriginals.length));
      },
      { rootMargin: '200px 0px' }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasMoreItems, filteredOriginals.length]);

  return (
    <div className="flex-1 pb-16 text-[#F5F5F5] select-none animate-screen-enter">
      {/* Sticky Native Header with Back Button */}
      <div className="sticky top-0 z-30 bg-[#080A09]/95 backdrop-blur-md px-4 pt-3 pb-2.5 border-b border-[#27302C]/60 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 -ml-1.5 rounded-full flex items-center justify-center text-[#C4C8C6] hover:text-white hover:bg-[#151917] active:scale-90 transition-all duration-120 border border-transparent hover:border-[#27302C]"
            aria-label="Volver atrás"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#00C781]" />
            <h1 className="text-lg font-black text-white tracking-tight">
              HourTV Originals
            </h1>
          </div>
        </div>

        <span className="text-xs font-mono font-bold text-[#00C781] bg-[#00C781]/15 px-2.5 py-1 rounded-full border border-[#00C781]/25">
          {filteredOriginals.length} títulos
        </span>
      </div>

      {/* Filter Chips Bar */}
      <div className="px-4 py-2.5 bg-[#101412]/40 border-b border-[#27302C]/30 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {[
          { id: 'all', label: 'Todos' },
          { id: 'movie', label: 'Películas' },
          { id: 'series', label: 'Series' },
          { id: '4k', label: '4K Ultra HD' }
        ].map((f) => {
          const isSelected = activeFilter === f.id;
          return (
            <button
              key={f.id}
              type="button"
              onClick={() => setActiveFilter(f.id as any)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-120 active:scale-95 min-h-[32px] flex items-center ${
                isSelected
                  ? 'bg-[#00C781] text-[#050505] font-bold shadow-sm'
                  : 'bg-[#151917] text-[#C4C8C6] border border-[#27302C] hover:border-[#38443F]'
              }`}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      {/* Vertical Catalog Grid */}
      <div className="px-3.5 py-4">
        <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
          {visibleItems.map((item, idx) => (
            <PosterCard
              key={item.id}
              item={item}
              size="sm"
              showRanking={activeFilter === 'all' && idx < 5 ? idx + 1 : undefined}
              onClick={onSelectMedia}
              onToggleMyList={(i, e) => {
                e.stopPropagation();
                onToggleMyList(i);
              }}
              className="w-full min-w-0"
            />
          ))}
        </div>

        {/* Infinite Scroll Trigger Sentinel */}
        {hasMoreItems && (
          <div
            ref={loadMoreRef}
            className="w-full py-8 flex flex-col items-center justify-center gap-2 text-xs text-[#A8ADAB]"
          >
            <div className="w-5 h-5 border-2 border-[#00C781]/30 border-t-[#00C781] rounded-full animate-spin" />
            <span>Cargando más títulos de HourTV Originals...</span>
          </div>
        )}
      </div>
    </div>
  );
};
