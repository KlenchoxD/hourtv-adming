import { useState, useEffect, useCallback } from 'react';
import { AppUpdateInfo } from '../types';
import { appUpdateService } from '../services/appUpdateService';

export function useAppUpdate() {
  const [updateInfo, setUpdateInfo] = useState<AppUpdateInfo>(() => {
    const installed = appUpdateService.getInstalledVersion();
    const hasUpdate = installed !== '2.6.5';
    return {
      currentVersion: installed,
      latestVersion: '2.6.5',
      buildNumber: hasUpdate ? 8420 : 8402,
      releaseDate: '22 de Agosto, 2026',
      hasUpdate,
      releaseNotes: [
        'Optimización del búfer de reproducción 4K Ultra HD en redes móviles.',
        'Mejora de sincronización en subtítulos automáticos en vivo.',
        'Corrección de latencia en canales de TV en Vivo.',
        'Mayor estabilidad de interfaz y transiciones fluidas.'
      ],
      sizeMB: 28.4,
      status: 'idle'
    };
  });

  const [isChecking, setIsChecking] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateProgress, setUpdateProgress] = useState(0);

  // Check version on startup
  const checkUpdates = useCallback(async (showLoading = false) => {
    if (showLoading) setIsChecking(true);
    try {
      const info = await appUpdateService.checkVersion();
      setUpdateInfo(info);
      return info;
    } finally {
      if (showLoading) setIsChecking(false);
    }
  }, []);

  useEffect(() => {
    checkUpdates(false);
  }, [checkUpdates]);

  const executeUpdate = useCallback(async () => {
    setIsUpdating(true);
    setUpdateProgress(5);
    try {
      const newVersion = await appUpdateService.applyUpdate((p) => {
        setUpdateProgress(p);
      });
      setUpdateInfo((prev) => ({
        ...prev,
        currentVersion: newVersion,
        hasUpdate: false,
        status: 'updated'
      }));
      return newVersion;
    } finally {
      setIsUpdating(false);
    }
  }, []);

  const resetToOldVersion = useCallback(() => {
    appUpdateService.resetToPreviousVersion();
    const installed = appUpdateService.getInstalledVersion();
    setUpdateInfo({
      currentVersion: installed,
      latestVersion: '2.6.5',
      buildNumber: 8420,
      releaseDate: '22 de Agosto, 2026',
      hasUpdate: true,
      releaseNotes: [
        'Optimización del búfer de reproducción 4K Ultra HD en redes móviles.',
        'Mejora de sincronización en subtítulos automáticos en vivo.',
        'Corrección de latencia en canales de TV en Vivo.',
        'Mayor estabilidad de interfaz y transiciones fluidas.'
      ],
      sizeMB: 28.4,
      status: 'idle'
    });
  }, []);

  return {
    updateInfo,
    isChecking,
    isUpdating,
    updateProgress,
    hasPendingUpdate: updateInfo.hasUpdate,
    checkUpdates,
    executeUpdate,
    resetToOldVersion
  };
}
