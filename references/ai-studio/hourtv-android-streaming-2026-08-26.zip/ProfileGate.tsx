import React, { useEffect, useState } from 'react';
import { ArrowLeft, Baby, Check, Pencil, Plus, Trash2 } from 'lucide-react';
import { UserProfile } from './src/types';
import { HourTVLogo } from './src/components/common/HourTVLogo';
import { PROFILE_AVATAR_IDS, ProfileAvatar } from './ProfileAvatar';

export interface ProfileDraft {
  name: string;
  avatarId: string;
  isKids: boolean;
}

interface ProfileGateProps {
  profiles: UserProfile[];
  activeProfileId?: string;
  onSelect: (profile: UserProfile) => void;
  onCreate: (draft: ProfileDraft) => void;
  onUpdate: (profileId: string, draft: ProfileDraft) => void;
  onDelete: (profileId: string) => void;
}

export const ProfileGate: React.FC<ProfileGateProps> = ({
  profiles,
  activeProfileId,
  onSelect,
  onCreate,
  onUpdate,
  onDelete
}) => {
  const forceCreate = profiles.length === 0;
  const [editingProfile, setEditingProfile] = useState<UserProfile | null>(null);
  const [isCreating, setIsCreating] = useState(forceCreate);
  const [isManaging, setIsManaging] = useState(false);
  const [name, setName] = useState('');
  const [avatarId, setAvatarId] = useState('avatar-1');
  const [isKids, setIsKids] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!forceCreate) return;
    setEditingProfile(null);
    setIsCreating(true);
  }, [forceCreate]);

  const openEditor = (profile?: UserProfile) => {
    setEditingProfile(profile ?? null);
    setIsCreating(!profile);
    setName(profile?.name ?? '');
    setAvatarId(profile?.avatarId ?? 'avatar-1');
    setIsKids(profile?.isKids ?? false);
    setError('');
  };

  const closeEditor = () => {
    if (forceCreate) return;
    setEditingProfile(null);
    setIsCreating(false);
    setError('');
  };

  const saveProfile = () => {
    const draft = { name, avatarId, isKids };

    try {
      if (editingProfile) {
        onUpdate(editingProfile.id, draft);
        closeEditor();
      } else {
        onCreate(draft);
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No pudimos guardar el perfil.');
    }
  };

  const removeProfile = () => {
    if (!editingProfile) return;

    try {
      onDelete(editingProfile.id);
      closeEditor();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No pudimos eliminar el perfil.');
    }
  };

  if (isCreating || editingProfile) {
    return (
      <div className="flex-1 min-h-full overflow-y-auto bg-[#080A09] px-5 py-5 text-[#F5F5F5]">
        <div className="mx-auto flex w-full max-w-md flex-col">
          <div className="flex min-h-12 items-center justify-between">
            {!forceCreate ? (
              <button
                type="button"
                onClick={closeEditor}
                className="flex h-12 w-12 items-center justify-center rounded-full text-[#C4C8C6] transition-colors hover:bg-[#151917] hover:text-white"
                aria-label="Volver al selector de perfiles"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            ) : <span className="h-12 w-12" />}
            <HourTVLogo size="sm" />
            <span className="h-12 w-12" />
          </div>

          <div className="pt-4 text-center">
            <h1 className="text-2xl font-black tracking-tight text-white">
              {editingProfile ? 'Editar perfil' : 'Crea tu perfil'}
            </h1>
            <p className="mx-auto mt-1 max-w-xs text-sm leading-5 text-[#A8ADAB]">
              {forceCreate
                ? 'Necesitas un perfil para personalizar tu experiencia en HourTV.'
                : 'Elige cómo quieres que aparezca este perfil.'}
            </p>
          </div>

          <div className="mt-6">
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-[#A8ADAB]">
              Elige un avatar
            </p>
            <div className="grid grid-cols-4 gap-3">
              {PROFILE_AVATAR_IDS.map((candidateId) => {
                const selected = candidateId === avatarId;
                return (
                  <button
                    key={candidateId}
                    type="button"
                    onClick={() => setAvatarId(candidateId)}
                    className="relative flex min-h-16 items-center justify-center rounded-2xl transition-transform active:scale-95"
                    aria-label={`Seleccionar avatar ${candidateId.replace('avatar-', '')}`}
                    aria-pressed={selected}
                  >
                    <ProfileAvatar
                      avatarId={candidateId}
                      name="perfil"
                      size={64}
                      selected={selected}
                    />
                    {selected && (
                      <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-[#00C781] text-[#050505] ring-2 ring-[#080A09]">
                        <Check className="h-3.5 w-3.5" strokeWidth={3} />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <label className="mt-6 block">
            <span className="mb-2 block text-xs font-bold uppercase tracking-[0.16em] text-[#A8ADAB]">
              Nombre
            </span>
            <input
              value={name}
              onChange={(event) => {
                setName(event.target.value.slice(0, 20));
                setError('');
              }}
              maxLength={20}
              autoFocus
              placeholder="Escribe un nombre"
              className="h-12 w-full rounded-xl border border-[#27302C] bg-[#151917] px-4 text-base font-semibold text-white outline-none transition-colors placeholder:text-[#666C69] focus:border-[#00C781] focus:ring-2 focus:ring-[#00C781]/20"
            />
            <span className="mt-1 block text-right text-[11px] font-mono text-[#7F8783]">
              {name.length}/20
            </span>
          </label>

          <button
            type="button"
            onClick={() => setIsKids((current) => !current)}
            className={`mt-3 flex min-h-14 items-center justify-between rounded-xl border px-4 text-left transition-colors ${
              isKids
                ? 'border-[#00C781] bg-[#00C781]/10'
                : 'border-[#27302C] bg-[#101412]'
            }`}
            aria-pressed={isKids}
          >
            <span className="flex items-center gap-3">
              <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${isKids ? 'bg-[#00C781] text-[#050505]' : 'bg-[#151917] text-[#A8ADAB]'}`}>
                <Baby className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-sm font-bold text-white">Perfil infantil</span>
                <span className="block text-xs text-[#A8ADAB]">Contenido apropiado para niños</span>
              </span>
            </span>
            <span className={`relative h-6 w-11 rounded-full transition-colors ${isKids ? 'bg-[#00C781]' : 'bg-[#27302C]'}`}>
              <span className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${isKids ? 'translate-x-6' : 'translate-x-1'}`} />
            </span>
          </button>

          {error && (
            <p role="alert" className="mt-3 rounded-lg bg-[#3A1616] px-3 py-2 text-xs font-semibold text-[#FFB4B4]">
              {error}
            </p>
          )}

          <div className="mt-5 flex gap-3">
            {editingProfile && (
              <button
                type="button"
                onClick={removeProfile}
                className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-[#5A2929] bg-[#241313] text-[#FF8B8B] transition-colors hover:bg-[#321717]"
                aria-label="Eliminar perfil"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            )}
            <button
              type="button"
              onClick={saveProfile}
              className="h-12 flex-1 rounded-xl bg-[#00C781] px-5 text-sm font-black text-[#050505] transition-transform active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45"
              disabled={!name.trim() || !avatarId}
            >
              {editingProfile ? 'Guardar cambios' : 'Crear perfil'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 min-h-full overflow-y-auto bg-[radial-gradient(circle_at_50%_18%,rgba(0,199,129,0.12),transparent_34%),#080A09] px-5 py-6 text-[#F5F5F5]">
      <div className="mx-auto flex min-h-full w-full max-w-md flex-col items-center">
        <HourTVLogo size="md" />
        <div className="mt-9 text-center">
          <h1 className="text-2xl font-black tracking-tight text-white">¿Quién está viendo?</h1>
          <p className="mt-1 text-sm text-[#A8ADAB]">Elige un perfil para entrar a HourTV</p>
        </div>

        <div className="mt-8 grid w-full grid-cols-2 gap-x-5 gap-y-6">
          {profiles.map((profile) => {
            const selected = profile.id === activeProfileId;
            return (
              <button
                key={profile.id}
                type="button"
                onClick={() => isManaging ? openEditor(profile) : onSelect(profile)}
                className="group relative flex min-h-32 flex-col items-center justify-center rounded-2xl px-2 py-3 transition-colors hover:bg-[#101412] active:scale-[0.98]"
              >
                <ProfileAvatar
                  avatarId={profile.avatarId}
                  name={profile.name}
                  size={88}
                  selected={selected && !isManaging}
                />
                {isManaging && (
                  <span className="absolute left-1/2 top-[46px] flex h-10 w-10 -translate-x-1/2 items-center justify-center rounded-full bg-black/75 text-white backdrop-blur-sm">
                    <Pencil className="h-4 w-4" />
                  </span>
                )}
                <span className="mt-3 max-w-full truncate text-sm font-bold text-[#F5F5F5]">
                  {profile.name}
                </span>
                {profile.isKids && (
                  <span className="mt-1 text-[10px] font-bold uppercase tracking-wider text-[#00C781]">Infantil</span>
                )}
              </button>
            );
          })}

          {profiles.length < 5 && (
            <button
              type="button"
              onClick={() => openEditor()}
              className="flex min-h-32 flex-col items-center justify-center rounded-2xl px-2 py-3 text-[#A8ADAB] transition-colors hover:bg-[#101412] hover:text-white active:scale-[0.98]"
            >
              <span className="flex h-[88px] w-[88px] items-center justify-center rounded-2xl border border-dashed border-[#38443F] bg-[#101412]">
                <Plus className="h-7 w-7" />
              </span>
              <span className="mt-3 text-sm font-bold">Añadir perfil</span>
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => setIsManaging((current) => !current)}
          className={`mt-8 min-h-12 rounded-xl border px-5 text-sm font-bold transition-colors ${
            isManaging
              ? 'border-[#00C781] bg-[#00C781]/10 text-[#00C781]'
              : 'border-[#27302C] bg-[#101412] text-[#C4C8C6] hover:border-[#38443F] hover:text-white'
          }`}
        >
          {isManaging ? 'Listo' : 'Administrar perfiles'}
        </button>
      </div>
    </div>
  );
};
