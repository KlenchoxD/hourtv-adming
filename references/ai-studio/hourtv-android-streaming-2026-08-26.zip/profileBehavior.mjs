export const PROFILE_STORAGE_KEY = 'hourtv.profiles.v1';
export const MAX_PROFILES = 5;
export const PROFILE_NAME_MAX_LENGTH = 20;

const normalizeName = (value) => String(value ?? '').trim().slice(0, PROFILE_NAME_MAX_LENGTH);

const normalizeAvatarId = (value) => String(value ?? '').trim();

const assertProfileInput = ({ name, avatarId }) => {
  if (!name) {
    throw new Error('El nombre del perfil es obligatorio.');
  }

  if (!avatarId) {
    throw new Error('Selecciona un avatar para continuar.');
  }
};

const createProfileId = () => {
  const randomPart = globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2);
  return `profile-${randomPart}`;
};

const isStoredProfile = (profile) => (
  profile
  && typeof profile === 'object'
  && typeof profile.id === 'string'
  && normalizeName(profile.name).length > 0
  && normalizeAvatarId(profile.avatarId).length > 0
);

const normalizeStoredProfile = (profile) => ({
  ...profile,
  id: profile.id,
  name: normalizeName(profile.name),
  avatarId: normalizeAvatarId(profile.avatarId),
  isKids: Boolean(profile.isKids),
});

export const loadProfiles = (serialized) => {
  if (!serialized) return [];

  try {
    const parsed = JSON.parse(serialized);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isStoredProfile).map(normalizeStoredProfile).slice(0, MAX_PROFILES);
  } catch {
    return [];
  }
};

export const serializeProfiles = (profiles) => JSON.stringify(
  profiles.filter(isStoredProfile).map(normalizeStoredProfile).slice(0, MAX_PROFILES),
);

export const createProfile = (profiles, input) => {
  if (profiles.length >= MAX_PROFILES) {
    throw new Error('Solo puedes crear hasta cinco perfiles.');
  }

  const normalized = {
    name: normalizeName(input?.name),
    avatarId: normalizeAvatarId(input?.avatarId),
    isKids: Boolean(input?.isKids),
  };
  assertProfileInput(normalized);

  return [
    ...profiles,
    {
      id: createProfileId(),
      ...normalized,
    },
  ];
};

export const updateProfile = (profiles, profileId, updates) => profiles.map((profile) => {
  if (profile.id !== profileId) return profile;

  const normalized = {
    ...profile,
    ...updates,
    name: updates?.name === undefined ? profile.name : normalizeName(updates.name),
    avatarId: updates?.avatarId === undefined
      ? profile.avatarId
      : normalizeAvatarId(updates.avatarId),
    isKids: updates?.isKids === undefined ? profile.isKids : Boolean(updates.isKids),
  };
  assertProfileInput(normalized);
  return normalized;
});

export const deleteProfile = (profiles, profileId) => {
  if (profiles.length <= 1) {
    throw new Error('No puedes eliminar el último perfil.');
  }

  return profiles.filter((profile) => profile.id !== profileId);
};
