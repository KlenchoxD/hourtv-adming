import React from 'react';
import avatarSpriteUrl from './hourtv-profile-avatar-sprite-v1.png';

export const PROFILE_AVATAR_IDS = [
  'avatar-1',
  'avatar-2',
  'avatar-3',
  'avatar-4',
  'avatar-5',
  'avatar-6',
  'avatar-7',
  'avatar-8'
] as const;

const AVATAR_POSITIONS: Record<string, string> = {
  'avatar-1': '0% 0%',
  'avatar-2': '33.333% 0%',
  'avatar-3': '66.667% 0%',
  'avatar-4': '100% 0%',
  'avatar-5': '0% 100%',
  'avatar-6': '33.333% 100%',
  'avatar-7': '66.667% 100%',
  'avatar-8': '100% 100%'
};

interface ProfileAvatarProps {
  avatarId?: string;
  name: string;
  size?: number;
  selected?: boolean;
  className?: string;
}

export const ProfileAvatar: React.FC<ProfileAvatarProps> = ({
  avatarId = 'avatar-1',
  name,
  size = 64,
  selected = false,
  className = ''
}) => (
  <span
    role="img"
    aria-label={`Avatar de ${name}`}
    className={`block shrink-0 overflow-hidden rounded-2xl border bg-[#101412] shadow-lg ${
      selected
        ? 'border-[#00C781] ring-2 ring-[#00C781]/40'
        : 'border-[#27302C]'
    } ${className}`}
    style={{
      width: size,
      height: size,
      backgroundImage: `url(${avatarSpriteUrl})`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: '400% 200%',
      backgroundPosition: AVATAR_POSITIONS[avatarId] ?? AVATAR_POSITIONS['avatar-1']
    }}
  />
);
